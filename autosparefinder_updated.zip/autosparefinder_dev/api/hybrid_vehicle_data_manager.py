import requests
import logging
import json
import os
import pandas as pd
from datetime import datetime, time, timedelta
import pytz
import schedule
import threading
import time as time_module
import sqlite3

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class HybridVehicleDataManager:
    """
    Hybrid data manager that combines API access with local database storage
    for vehicle registration data from the Israeli Ministry of Transport
    """
    
    def __init__(self, db_path="vehicle_data.db"):
        self.base_url = "https://data.gov.il/api/3/action"
        self.resource_id = "053cea08-09bc-40ec-8f7a-156f0677aff3"  # Vehicle registration data resource ID
        self.timeout = 15  # seconds
        self.israel_tz = pytz.timezone('Asia/Jerusalem')
        self.db_path = db_path
        self.download_url = "https://data.gov.il/dataset/053cea08-09bc-40ec-8f7a-156f0677aff3/resource/053cea08-09bc-40ec-8f7a-156f0677aff3/download/vehicles.csv"
        
        # Initialize database
        self._init_database()
        
        # Start scheduler in a separate thread
        self._start_scheduler()
        
        logger.info("Hybrid Vehicle Data Manager initialized")
    
    def _init_database(self):
        """Initialize the SQLite database for vehicle data"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Create vehicles table if it doesn't exist
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS vehicles (
                mispar_rechev TEXT PRIMARY KEY,
                tozeret_cd INTEGER,
                sug_degem INTEGER,
                tozeret_nm TEXT,
                degem_nm TEXT,
                ramat_gimur TEXT,
                ramat_eivzur_betihuty TEXT,
                kvutzat_zihum INTEGER,
                shnat_yitzur INTEGER,
                degem_manoa TEXT,
                mivchan_acharon_dt TEXT,
                tokef_dt TEXT,
                baalut TEXT,
                misgeret TEXT,
                tzeva_rechev TEXT,
                zmig_kidmi TEXT,
                zmig_ahori TEXT,
                sug_delek_nm TEXT,
                horaat_rishum TEXT,
                moed_aliya_lakvish TEXT,
                kinuy_mishari TEXT,
                last_updated TIMESTAMP
            )
            ''')
            
            # Create metadata table to track last update
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS metadata (
                key TEXT PRIMARY KEY,
                value TEXT
            )
            ''')
            
            conn.commit()
            conn.close()
            
            logger.info("Database initialized successfully")
        except Exception as e:
            logger.error(f"Error initializing database: {e}")
    
    def _start_scheduler(self):
        """Start a scheduler to update the database daily at 9:15 AM Israel time"""
        def run_scheduler():
            # Schedule the update job for 9:15 AM (15 minutes after the data is updated)
            schedule.every().day.at("09:15").do(self._update_local_database)
            
            # Check if we need to update now (if last update was before today's 9 AM)
            self._check_initial_update()
            
            while True:
                schedule.run_pending()
                time_module.sleep(60)  # Check every minute
        
        # Start the scheduler in a separate thread
        scheduler_thread = threading.Thread(target=run_scheduler, daemon=True)
        scheduler_thread.start()
        
        logger.info("Scheduler started for daily database updates")
    
    def _check_initial_update(self):
        """Check if we need to update the database immediately"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get the last update timestamp
            cursor.execute("SELECT value FROM metadata WHERE key = 'last_update'")
            result = cursor.fetchone()
            
            conn.close()
            
            now = datetime.now(self.israel_tz)
            today_9am = datetime.combine(now.date(), time(9, 0)).astimezone(self.israel_tz)
            
            # If it's after 9 AM today and the last update was before 9 AM today, update now
            if result:
                last_update = datetime.fromisoformat(result[0])
                if now > today_9am and last_update < today_9am:
                    logger.info("Initial update needed, running now...")
                    self._update_local_database()
            else:
                # No previous update, run it now
                logger.info("No previous update found, running initial update...")
                self._update_local_database()
                
        except Exception as e:
            logger.error(f"Error checking for initial update: {e}")
    
    def _update_local_database(self):
        """Download and update the local database with the latest vehicle data"""
        logger.info("Starting database update...")
        
        try:
            # Download the CSV file
            logger.info(f"Downloading data from {self.download_url}")
            response = requests.get(self.download_url, timeout=300)  # Longer timeout for large file
            response.raise_for_status()
            
            # Save to a temporary file
            temp_file = "temp_vehicles.csv"
            with open(temp_file, 'wb') as f:
                f.write(response.content)
            
            logger.info("Download complete, processing data...")
            
            # Process the CSV file in chunks to avoid memory issues
            conn = sqlite3.connect(self.db_path)
            
            # Create a temporary table for the update
            conn.execute("DROP TABLE IF EXISTS vehicles_temp")
            conn.execute('''
            CREATE TABLE vehicles_temp (
                mispar_rechev TEXT PRIMARY KEY,
                tozeret_cd INTEGER,
                sug_degem INTEGER,
                tozeret_nm TEXT,
                degem_nm TEXT,
                ramat_gimur TEXT,
                ramat_eivzur_betihuty TEXT,
                kvutzat_zihum INTEGER,
                shnat_yitzur INTEGER,
                degem_manoa TEXT,
                mivchan_acharon_dt TEXT,
                tokef_dt TEXT,
                baalut TEXT,
                misgeret TEXT,
                tzeva_rechev TEXT,
                zmig_kidmi TEXT,
                zmig_ahori TEXT,
                sug_delek_nm TEXT,
                horaat_rishum TEXT,
                moed_aliya_lakvish TEXT,
                kinuy_mishari TEXT,
                last_updated TIMESTAMP
            )
            ''')
            
            # Process the CSV in chunks
            chunksize = 100000
            for chunk in pd.read_csv(temp_file, chunksize=chunksize, low_memory=False):
                # Add last_updated column
                chunk['last_updated'] = datetime.now(self.israel_tz).isoformat()
                
                # Insert into temporary table
                chunk.to_sql('vehicles_temp', conn, if_exists='append', index=False)
                
                logger.info(f"Processed {chunksize} records...")
            
            # Replace the main table with the temporary table
            conn.execute("DROP TABLE IF EXISTS vehicles_old")
            conn.execute("ALTER TABLE vehicles RENAME TO vehicles_old")
            conn.execute("ALTER TABLE vehicles_temp RENAME TO vehicles")
            conn.execute("DROP TABLE vehicles_old")
            
            # Update the metadata
            now = datetime.now(self.israel_tz).isoformat()
            conn.execute("INSERT OR REPLACE INTO metadata (key, value) VALUES (?, ?)", 
                        ('last_update', now))
            
            conn.commit()
            conn.close()
            
            # Remove temporary file
            os.remove(temp_file)
            
            logger.info("Database update completed successfully")
            
        except Exception as e:
            logger.error(f"Error updating database: {e}")
    
    def search_vehicle_by_license(self, license_plate, use_api_first=True):
        """
        Search for vehicle details by license plate number
        
        Args:
            license_plate (str): Vehicle license plate number
            use_api_first (bool): Whether to try the API first before falling back to local database
            
        Returns:
            dict: Vehicle details or error message
        """
        if use_api_first:
            # Try the API first
            try:
                api_result = self._search_vehicle_by_license_api(license_plate)
                if "error" not in api_result:
                    return api_result
                logger.info(f"API search failed, falling back to local database: {api_result.get('error')}")
            except Exception as e:
                logger.error(f"API search error, falling back to local database: {e}")
        
        # Fall back to local database
        return self._search_vehicle_by_license_db(license_plate)
    
    def get_vehicle_data(self, license_plate):
        """
        Get vehicle data by license plate (alias for search_vehicle_by_license)
        
        Args:
            license_plate (str): Vehicle license plate number
            
        Returns:
            dict: Vehicle details or error message
        """
        return self.search_vehicle_by_license(license_plate)
    
    def _search_vehicle_by_license_api(self, license_plate):
        """Search for vehicle by license plate using the CKAN API"""
        # Prepare the query
        params = {
            "resource_id": self.resource_id,
            "q": license_plate
        }
        
        # Make the API request
        url = f"{self.base_url}/datastore_search"
        
        try:
            response = requests.get(url, params=params, timeout=self.timeout)
            response.raise_for_status()
            result = response.json()
            
            if not result.get("success", False):
                logger.error(f"Error searching for license plate {license_plate}: {result.get('error')}")
                return {"error": f"API request failed: {result.get('error', 'Unknown error')}"}
            
            # Process the results
            records = result.get("result", {}).get("records", [])
            
            if not records:
                logger.info(f"No vehicle found with license plate {license_plate}")
                return {"error": f"No vehicle found with license plate {license_plate}"}
            
            # Format the vehicle data
            return self._format_vehicle_data(records[0])
            
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            return {"error": f"API request failed: {str(e)}"}
    
    def _search_vehicle_by_license_db(self, license_plate):
        """Search for vehicle by license plate in the local database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Query the database
            cursor.execute("SELECT * FROM vehicles WHERE mispar_rechev = ?", (license_plate,))
            columns = [description[0] for description in cursor.description]
            result = cursor.fetchone()
            
            conn.close()
            
            if not result:
                logger.info(f"No vehicle found in local database with license plate {license_plate}")
                return {"error": f"No vehicle found with license plate {license_plate}"}
            
            # Convert to dictionary
            record = dict(zip(columns, result))
            
            # Format the vehicle data
            return self._format_vehicle_data(record)
            
        except Exception as e:
            logger.error(f"Database search error: {e}")
            return {"error": f"Database search failed: {str(e)}"}
    
    def search_vehicles_by_make_model(self, make=None, model=None, limit=10, use_api_first=True):
        """
        Search for vehicles by make and/or model
        
        Args:
            make (str, optional): Vehicle make
            model (str, optional): Vehicle model
            limit (int, optional): Maximum number of results to return
            use_api_first (bool): Whether to try the API first before falling back to local database
            
        Returns:
            dict: List of vehicles or error message
        """
        if not make and not model:
            return {"error": "At least one of make or model must be provided"}
        
        if use_api_first:
            # Try the API first
            try:
                api_result = self._search_vehicles_by_make_model_api(make, model, limit)
                if "error" not in api_result:
                    return api_result
                logger.info(f"API search failed, falling back to local database: {api_result.get('error')}")
            except Exception as e:
                logger.error(f"API search error, falling back to local database: {e}")
        
        # Fall back to local database
        return self._search_vehicles_by_make_model_db(make, model, limit)
    
    def _search_vehicles_by_make_model_api(self, make, model, limit):
        """Search for vehicles by make and model using the CKAN API"""
        # Prepare the query
        filters = []
        if make:
            filters.append(f"tozeret_nm:{make}")
        if model:
            filters.append(f"degem_nm:{model}")
            
        query = " AND ".join(filters)
        
        params = {
            "resource_id": self.resource_id,
            "q": query,
            "limit": limit
        }
        
        # Make the API request
        url = f"{self.base_url}/datastore_search"
        
        try:
            response = requests.get(url, params=params, timeout=self.timeout)
            response.raise_for_status()
            result = response.json()
            
            if not result.get("success", False):
                logger.error(f"Error searching for vehicles with query {query}: {result.get('error')}")
                return {"error": f"API request failed: {result.get('error', 'Unknown error')}"}
            
            # Process the results
            records = result.get("result", {}).get("records", [])
            
            if not records:
                logger.info(f"No vehicles found with query {query}")
                return {"error": f"No vehicles found with query {query}"}
            
            # Format the vehicle data
            vehicles = [self._format_vehicle_data(record) for record in records]
            
            return {
                "count": len(vehicles),
                "vehicles": vehicles
            }
            
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            return {"error": f"API request failed: {str(e)}"}
    
    def _search_vehicles_by_make_model_db(self, make, model, limit):
        """Search for vehicles by make and model in the local database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Build the query
            query = "SELECT * FROM vehicles WHERE 1=1"
            params = []
            
            if make:
                query += " AND tozeret_nm LIKE ?"
                params.append(f"%{make}%")
            
            if model:
                query += " AND degem_nm LIKE ?"
                params.append(f"%{model}%")
            
            query += f" LIMIT {int(limit)}"
            
            # Execute the query
            cursor.execute(query, params)
            columns = [description[0] for description in cursor.description]
            results = cursor.fetchall()
            
            conn.close()
            
            if not results:
                logger.info(f"No vehicles found in local database with make={make}, model={model}")
                return {"error": f"No vehicles found with make={make}, model={model}"}
            
            # Convert to dictionaries
            records = [dict(zip(columns, result)) for result in results]
            
            # Format the vehicle data
            vehicles = [self._format_vehicle_data(record) for record in records]
            
            return {
                "count": len(vehicles),
                "vehicles": vehicles
            }
            
        except Exception as e:
            logger.error(f"Database search error: {e}")
            return {"error": f"Database search failed: {str(e)}"}
    
    def get_vehicle_compatibility(self, part_id, license_plate=None, make=None, model=None, year=None):
        """
        Check if a part is compatible with a specific vehicle
        
        Args:
            part_id (str): Part identifier
            license_plate (str, optional): Vehicle license plate
            make (str, optional): Vehicle make
            model (str, optional): Vehicle model
            year (int, optional): Vehicle year
            
        Returns:
            dict: Compatibility information or error message
        """
        # Get vehicle details
        vehicle = None
        
        if license_plate:
            result = self.search_vehicle_by_license(license_plate)
            if "error" not in result:
                vehicle = result
        elif make and model:
            # For simplicity, we'll just use the first vehicle that matches
            result = self.search_vehicles_by_make_model(make, model, limit=1)
            if "error" not in result and result.get("count", 0) > 0:
                vehicle = result["vehicles"][0]
        
        if not vehicle:
            return {"error": "Could not find vehicle details"}
        
        # In a real implementation, we would check a parts database for compatibility
        # For this demo, we'll use a simplified compatibility check
        
        # Extract vehicle details
        vehicle_make = vehicle.get("make", "")
        vehicle_model = vehicle.get("model", "")
        vehicle_year = vehicle.get("year", 0)
        
        # Simple compatibility logic based on part_id prefix
        compatibility = {
            "compatible": False,
            "confidence": 0,
            "notes": "",
            "alternatives": []
        }
        
        # Brake pads compatibility
        if part_id.startswith("BP"):
            if "Toyota" in vehicle_make and "Corolla" in vehicle_model:
                compatibility["compatible"] = True
                compatibility["confidence"] = 95
                compatibility["notes"] = "High compatibility with Toyota Corolla models"
            elif "Honda" in vehicle_make:
                compatibility["compatible"] = True
                compatibility["confidence"] = 90
                compatibility["notes"] = "Good compatibility with Honda models"
            else:
                compatibility["compatible"] = False
                compatibility["confidence"] = 60
                compatibility["notes"] = "Limited compatibility data available"
                compatibility["alternatives"] = ["BP1001", "BP1002"]
        
        # Oil filters compatibility
        elif part_id.startswith("OF"):
            if vehicle_year >= 2018:
                compatibility["compatible"] = True
                compatibility["confidence"] = 85
                compatibility["notes"] = "Compatible with newer models from 2018 onwards"
            else:
                compatibility["compatible"] = False
                compatibility["confidence"] = 70
                compatibility["notes"] = "Recommended for models from 2018 onwards"
                compatibility["alternatives"] = ["OF2001", "OF2002"]
        
        # Default case
        else:
            compatibility["compatible"] = "unknown"
            compatibility["confidence"] = 50
            compatibility["notes"] = "Insufficient data to determine compatibility"
        
        # Add vehicle details to the response
        compatibility["vehicle"] = {
            "license_plate": vehicle.get("license_plate", ""),
            "make": vehicle_make,
            "model": vehicle_model,
            "year": vehicle_year
        }
        
        return compatibility
    
    def _format_vehicle_data(self, record):
        """
        Format the raw vehicle record into a standardized vehicle data format
        
        Args:
            record (dict): Raw vehicle record
            
        Returns:
            dict: Formatted vehicle data
        """
        try:
            return {
                "license_plate": record.get("mispar_rechev", ""),
                "make": record.get("tozeret_nm", ""),
                "model": record.get("degem_nm", ""),
                "year": int(record.get("shnat_yitzur", 0)) if record.get("shnat_yitzur") else 0,
                "engine_type": record.get("sug_delek_nm", ""),
                "color": record.get("tzeva_rechev", ""),
                "last_test_date": record.get("mivchan_acharon_dt", ""),
                "ownership_type": record.get("baalut", ""),
                "raw_data": record  # Include the raw data for reference
            }
        except Exception as e:
            logger.error(f"Error formatting vehicle data: {e}")
            return {
                "error": f"Error formatting vehicle data: {str(e)}",
                "raw_data": record
            }

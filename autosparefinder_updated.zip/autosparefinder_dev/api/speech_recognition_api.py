import requests
import logging
import json
from datetime import datetime
import speech_recognition as sr
import os
import tempfile
import wave
import numpy as np

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class SpeechRecognitionAPI:
    """
    Client for speech recognition of car part queries
    """
    
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.language = "he-IL"  # Default to Hebrew
        logger.info("Speech Recognition API client initialized")
    
    def recognize_from_file(self, audio_file_path, language=None):
        """
        Recognize speech from an audio file
        
        Args:
            audio_file_path (str): Path to audio file
            language (str, optional): Language code (e.g., 'he-IL', 'en-US')
            
        Returns:
            dict: Recognition results or error message
        """
        if language:
            self.language = language
            
        try:
            with sr.AudioFile(audio_file_path) as source:
                audio_data = self.recognizer.record(source)
                return self._process_audio(audio_data)
        except Exception as e:
            logger.error(f"Error recognizing speech from file: {e}")
            return {"error": f"Error recognizing speech: {str(e)}"}
    
    def recognize_from_bytes(self, audio_bytes, language=None, sample_rate=16000, channels=1):
        """
        Recognize speech from raw audio bytes
        
        Args:
            audio_bytes (bytes): Raw audio data
            language (str, optional): Language code (e.g., 'he-IL', 'en-US')
            sample_rate (int): Sample rate of the audio
            channels (int): Number of audio channels
            
        Returns:
            dict: Recognition results or error message
        """
        if language:
            self.language = language
            
        try:
            # Create a temporary WAV file
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as temp_file:
                temp_path = temp_file.name
            
            # Convert raw bytes to WAV format
            with wave.open(temp_path, 'wb') as wav_file:
                wav_file.setnchannels(channels)
                wav_file.setsampwidth(2)  # 16-bit
                wav_file.setframerate(sample_rate)
                wav_file.writeframes(audio_bytes)
            
            # Recognize from the temporary file
            result = self.recognize_from_file(temp_path)
            
            # Clean up
            os.remove(temp_path)
            
            return result
            
        except Exception as e:
            logger.error(f"Error recognizing speech from bytes: {e}")
            return {"error": f"Error recognizing speech: {str(e)}"}
    
    def _process_audio(self, audio_data):
        """
        Process audio data and extract car part queries
        
        Args:
            audio_data: Audio data from recognizer
            
        Returns:
            dict: Recognition results
        """
        try:
            # Use Google's speech recognition
            text = self.recognizer.recognize_google(audio_data, language=self.language)
            logger.info(f"Recognized text: {text}")
            
            # Process the text to extract car part queries
            result = self._extract_car_part_queries(text)
            result["full_text"] = text
            
            return result
            
        except sr.UnknownValueError:
            logger.warning("Speech recognition could not understand audio")
            return {
                "recognized": False,
                "error": "Could not understand audio",
                "queries": []
            }
        except sr.RequestError as e:
            logger.error(f"Speech recognition service error: {e}")
            return {
                "recognized": False,
                "error": f"Speech recognition service error: {str(e)}",
                "queries": []
            }
        except Exception as e:
            logger.error(f"Error processing audio: {e}")
            return {
                "recognized": False,
                "error": f"Error processing audio: {str(e)}",
                "queries": []
            }
    
    def _extract_car_part_queries(self, text):
        """
        Extract car part queries from recognized text
        
        Args:
            text (str): Recognized text
            
        Returns:
            dict: Extracted queries and metadata
        """
        # Convert text to lowercase for easier matching
        text_lower = text.lower()
        
        # Define keywords for car parts in Hebrew and English
        car_parts_he = {
            "רפידות בלם": "brake_pads",
            "בלמים": "brakes",
            "מסנן שמן": "oil_filter",
            "מסנן אוויר": "air_filter",
            "מצבר": "battery",
            "צמיגים": "tires",
            "מגבים": "wipers",
            "פנסים": "headlights",
            "מראות": "mirrors",
            "מנוע": "engine"
        }
        
        car_parts_en = {
            "brake pad": "brake_pads",
            "brake": "brakes",
            "oil filter": "oil_filter",
            "air filter": "air_filter",
            "battery": "battery",
            "tire": "tires",
            "wiper": "wipers",
            "headlight": "headlights",
            "mirror": "mirrors",
            "engine": "engine"
        }
        
        # Define car make keywords
        car_makes_he = {
            "טויוטה": "Toyota",
            "הונדה": "Honda",
            "מאזדה": "Mazda",
            "סובארו": "Subaru",
            "מיצובישי": "Mitsubishi",
            "יונדאי": "Hyundai",
            "קיה": "Kia",
            "פורד": "Ford",
            "שברולט": "Chevrolet",
            "פולקסווגן": "Volkswagen",
            "אאודי": "Audi",
            "במוו": "BMW",
            "מרצדס": "Mercedes"
        }
        
        car_makes_en = {
            "toyota": "Toyota",
            "honda": "Honda",
            "mazda": "Mazda",
            "subaru": "Subaru",
            "mitsubishi": "Mitsubishi",
            "hyundai": "Hyundai",
            "kia": "Kia",
            "ford": "Ford",
            "chevrolet": "Chevrolet",
            "volkswagen": "Volkswagen",
            "audi": "Audi",
            "bmw": "BMW",
            "mercedes": "Mercedes"
        }
        
        # Initialize results
        queries = []
        
        # Check for car parts in Hebrew
        for part_name, part_type in car_parts_he.items():
            if part_name in text_lower:
                query = {
                    "type": "part",
                    "part_type": part_type,
                    "part_name": part_name,
                    "confidence": 0.9
                }
                
                # Check for car makes
                for make_name, make in car_makes_he.items():
                    if make_name in text_lower:
                        query["car_make"] = make
                        break
                
                queries.append(query)
        
        # Check for car parts in English
        for part_name, part_type in car_parts_en.items():
            if part_name in text_lower:
                query = {
                    "type": "part",
                    "part_type": part_type,
                    "part_name": part_name,
                    "confidence": 0.9
                }
                
                # Check for car makes
                for make_name, make in car_makes_en.items():
                    if make_name in text_lower:
                        query["car_make"] = make
                        break
                
                queries.append(query)
        
        # Check for general queries
        if "מחיר" in text_lower or "price" in text_lower:
            queries.append({
                "type": "price_inquiry",
                "confidence": 0.8
            })
        
        if "זמינות" in text_lower or "availability" in text_lower:
            queries.append({
                "type": "availability_inquiry",
                "confidence": 0.8
            })
        
        # Return the results
        return {
            "recognized": len(queries) > 0,
            "queries": queries,
            "language": "he" if any(part in text_lower for part in car_parts_he) else "en"
        }

# Create Flask app for API testing
if __name__ == '__main__':
    from flask import Flask, request, jsonify
    
    app = Flask(__name__)
    speech_api = SpeechRecognitionAPI()
    
    @app.route('/api/speech/recognize', methods=['POST'])
    def recognize_speech():
        """API endpoint to recognize speech from an audio file"""
        if 'audio' not in request.files:
            return jsonify({"error": "No audio file provided"})
        
        audio_file = request.files['audio']
        language = request.form.get('language')
        
        # Save the file temporarily
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.wav')
        audio_file.save(temp_file.name)
        temp_file.close()
        
        # Process the file
        result = speech_api.recognize_from_file(temp_file.name, language)
        
        # Clean up
        os.remove(temp_file.name)
        
        return jsonify(result)
    
    app.run(host='0.0.0.0', port=5006, debug=True)

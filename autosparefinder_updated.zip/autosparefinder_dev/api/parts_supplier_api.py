from flask import Flask, request, jsonify
import requests
import logging
import os
import json
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class PartsSupplierAPI:
    """
    Client for interacting with international parts suppliers APIs
    """
    
    def __init__(self):
        # In a production environment, these would be loaded from environment variables
        self.suppliers = {
            "global_parts": {
                "api_key": os.getenv('GLOBAL_PARTS_API_KEY', 'demo_key_gp'),
                "base_url": os.getenv('GLOBAL_PARTS_API_URL', 'https://api.globalparts.example.com/v2'),
                "timeout": 15  # seconds
            },
            "euro_auto": {
                "api_key": os.getenv('EURO_AUTO_API_KEY', 'demo_key_ea'),
                "base_url": os.getenv('EURO_AUTO_API_URL', 'https://api.euroauto.example.com/v1'),
                "timeout": 10  # seconds
            },
            "asia_parts": {
                "api_key": os.getenv('ASIA_PARTS_API_KEY', 'demo_key_ap'),
                "base_url": os.getenv('ASIA_PARTS_API_URL', 'https://api.asiaparts.example.com/v3'),
                "timeout": 12  # seconds
            }
        }
        
        logger.info("Parts Supplier API client initialized")
    
    def search_part(self, query, make=None, model=None, year=None, suppliers=None):
        """
        Search for parts across multiple suppliers
        
        Args:
            query (str): Search query (part name, number, etc.)
            make (str, optional): Vehicle make
            model (str, optional): Vehicle model
            year (int, optional): Vehicle year
            suppliers (list, optional): List of supplier IDs to search. If None, search all.
            
        Returns:
            dict: Search results from all suppliers
        """
        if not query:
            return {"error": "Search query is required"}
            
        # Determine which suppliers to search
        if not suppliers:
            suppliers = list(self.suppliers.keys())
        else:
            # Filter out any invalid supplier IDs
            suppliers = [s for s in suppliers if s in self.suppliers]
            
        if not suppliers:
            return {"error": "No valid suppliers specified"}
            
        results = {}
        
        # Search each supplier
        for supplier_id in suppliers:
            supplier = self.suppliers[supplier_id]
            
            # In a real implementation, this would make actual API calls
            # For demo purposes, we'll simulate responses
            
            # Simulated search results
            supplier_results = self._get_mock_search_results(
                supplier_id, query, make, model, year
            )
            
            results[supplier_id] = supplier_results
            
        return {
            "query": query,
            "filters": {
                "make": make,
                "model": model,
                "year": year
            },
            "results": results
        }
    
    def get_part_details(self, part_id, supplier_id):
        """
        Get detailed information about a specific part
        
        Args:
            part_id (str): Part identifier
            supplier_id (str): Supplier identifier
            
        Returns:
            dict: Part details or error message
        """
        if not part_id or not supplier_id:
            return {"error": "Both part_id and supplier_id are required"}
            
        if supplier_id not in self.suppliers:
            return {"error": f"Invalid supplier: {supplier_id}"}
            
        supplier = self.suppliers[supplier_id]
        
        # In a real implementation, this would make an actual API call
        # For demo purposes, we'll simulate a response
        
        # Simulated part details
        return self._get_mock_part_details(supplier_id, part_id)
    
    def check_availability(self, part_id, supplier_id, quantity=1):
        """
        Check if a part is available from a supplier
        
        Args:
            part_id (str): Part identifier
            supplier_id (str): Supplier identifier
            quantity (int, optional): Quantity needed. Defaults to 1.
            
        Returns:
            dict: Availability information or error message
        """
        if not part_id or not supplier_id:
            return {"error": "Both part_id and supplier_id are required"}
            
        if supplier_id not in self.suppliers:
            return {"error": f"Invalid supplier: {supplier_id}"}
            
        supplier = self.suppliers[supplier_id]
        
        # In a real implementation, this would make an actual API call
        # For demo purposes, we'll simulate a response
        
        # Simulated availability check
        return self._get_mock_availability(supplier_id, part_id, quantity)
    
    def place_order(self, supplier_id, parts, shipping_info, payment_info):
        """
        Place an order with a supplier
        
        Args:
            supplier_id (str): Supplier identifier
            parts (list): List of parts to order, each with part_id and quantity
            shipping_info (dict): Shipping information
            payment_info (dict): Payment information
            
        Returns:
            dict: Order confirmation or error message
        """
        if not supplier_id or not parts or not shipping_info or not payment_info:
            return {"error": "Missing required order information"}
            
        if supplier_id not in self.suppliers:
            return {"error": f"Invalid supplier: {supplier_id}"}
            
        supplier = self.suppliers[supplier_id]
        
        # In a real implementation, this would make an actual API call
        # For demo purposes, we'll simulate a response
        
        # Simulated order placement
        return self._get_mock_order_confirmation(supplier_id, parts, shipping_info)
    
    def _get_mock_search_results(self, supplier_id, query, make=None, model=None, year=None):
        """Generate mock search results for demonstration purposes"""
        
        # Load mock data from JSON file (in a real implementation)
        # Here we'll just create some sample data
        
        results = []
        
        # Brake related queries
        if "brake" in query.lower():
            results.extend([
                {
                    "part_id": f"{supplier_id}_BP1001",
                    "name": "Front Brake Pads",
                    "brand": "StopTech",
                    "price": 45.99,
                    "compatibility": ["Toyota Corolla 2018-2022", "Honda Civic 2016-2021"]
                },
                {
                    "part_id": f"{supplier_id}_BP1002",
                    "name": "Rear Brake Pads",
                    "brand": "Brembo",
                    "price": 52.50,
                    "compatibility": ["Toyota Camry 2017-2022", "Honda Accord 2018-2022"]
                },
                {
                    "part_id": f"{supplier_id}_BR2001",
                    "name": "Brake Rotor",
                    "brand": "ACDelco",
                    "price": 78.99,
                    "compatibility": ["Multiple vehicles"]
                }
            ])
            
        # Oil related queries
        elif "oil" in query.lower():
            results.extend([
                {
                    "part_id": f"{supplier_id}_OF1001",
                    "name": "Oil Filter",
                    "brand": "Bosch",
                    "price": 12.99,
                    "compatibility": ["Multiple vehicles"]
                },
                {
                    "part_id": f"{supplier_id}_OL2001",
                    "name": "Synthetic Oil 5W-30",
                    "brand": "Mobil 1",
                    "price": 32.99,
                    "compatibility": ["Multiple vehicles"]
                },
                {
                    "part_id": f"{supplier_id}_OL2002",
                    "name": "Synthetic Oil 5W-20",
                    "brand": "Castrol",
                    "price": 28.50,
                    "compatibility": ["Multiple vehicles"]
                }
            ])
            
        # Filter by make/model if provided
        if make or model:
            filtered_results = []
            for part in results:
                # Simple filtering logic for demo
                if make and any(make.lower() in compat.lower() for compat in part["compatibility"]):
                    filtered_results.append(part)
                elif model and any(model.lower() in compat.lower() for compat in part["compatibility"]):
                    filtered_results.append(part)
            results = filtered_results if filtered_results else results
            
        # Add supplier-specific variations
        if supplier_id == "global_parts":
            for part in results:
                part["price"] *= 1.05  # Slightly higher prices
                part["shipping_days"] = 5
                part["rating"] = 4.7
        elif supplier_id == "euro_auto":
            for part in results:
                part["price"] *= 1.15  # Premium prices
                part["shipping_days"] = 10
                part["rating"] = 4.9
                part["origin"] = "Europe"
        elif supplier_id == "asia_parts":
            for part in results:
                part["price"] *= 0.9  # Lower prices
                part["shipping_days"] = 15
                part["rating"] = 4.5
                
        return {
            "count": len(results),
            "parts": results
        }
    
    def _get_mock_part_details(self, supplier_id, part_id):
        """Generate mock part details for demonstration purposes"""
        
        # Extract part type from ID
        part_type = ""
        if "BP" in part_id:
            part_type = "Brake Pads"
        elif "BR" in part_id:
            part_type = "Brake Rotor"
        elif "OF" in part_id:
            part_type = "Oil Filter"
        elif "OL" in part_id:
            part_type = "Oil"
        else:
            part_type = "Generic Part"
            
        # Base details
        details = {
            "part_id": part_id,
            "supplier_id": supplier_id,
            "name": f"{part_type} {part_id[-4:]}",
            "description": f"High quality {part_type.lower()} for optimal performance and durability.",
            "specifications": {
                "weight": f"{float(part_id[-2:]) / 10:.1f} kg",
                "dimensions": f"{int(part_id[-4:-2]) * 2} x {int(part_id[-2:])} x {int(part_id[-3:-2]) * 3} cm",
                "material": "Premium materials"
            },
            "compatibility": [
                "Toyota Corolla 2018-2022",
                "Honda Civic 2016-2021",
                "Ford Focus 2017-2020"
            ],
            "warranty": "12 months",
            "return_policy": "30-day money-back guarantee",
            "images": [
                f"https://example.com/parts/{part_id}_1.jpg",
                f"https://example.com/parts/{part_id}_2.jpg"
            ]
        }
        
        # Add supplier-specific details
        if supplier_id == "global_parts":
            details["price"] = float(part_id[-4:]) / 10 + 40
            details["shipping"] = {
                "cost": 12.99,
                "estimated_days": 5
            }
            details["rating"] = 4.7
            details["reviews_count"] = 120
        elif supplier_id == "euro_auto":
            details["price"] = float(part_id[-4:]) / 10 + 50
            details["shipping"] = {
                "cost": 18.99,
                "estimated_days": 10
            }
            details["rating"] = 4.9
            details["reviews_count"] = 85
            details["origin"] = "Germany"
            details["certification"] = "European Quality Standard"
        elif supplier_id == "asia_parts":
            details["price"] = float(part_id[-4:]) / 10 + 30
            details["shipping"] = {
                "cost": 15.99,
                "estimated_days": 15
            }
            details["rating"] = 4.5
            details["reviews_count"] = 200
            details["manufacturer"] = "Asia Motors Ltd."
            
        return details
    
    def _get_mock_availability(self, supplier_id, part_id, quantity):
        """Generate mock availability data for demonstration purposes"""
        
        # Determine availability based on part_id
        # For demo purposes, we'll use the last digit of the part_id
        last_digit = int(part_id[-1])
        
        if last_digit >= 8:  # Out of stock
            return {
                "available": False,
                "stock_count": 0,
                "backorder": True,
                "estimated_restock_date": "2023-12-15",
                "max_order_quantity": 0
            }
        elif last_digit >= 5:  # Limited stock
            stock = last_digit - 3
            return {
                "available": True,
                "stock_count": stock,
                "backorder": False,
                "max_order_quantity": stock,
                "can_fulfill_requested_quantity": stock >= quantity
            }
        else:  # Good stock
            stock = (last_digit + 1) * 10
            return {
                "available": True,
                "stock_count": stock,
                "backorder": False,
                "max_order_quantity": 20,
                "can_fulfill_requested_quantity": True
            }
    
    def _get_mock_order_confirmation(self, supplier_id, parts, shipping_info):
        """Generate mock order confirmation for demonstration purposes"""
        
        # Calculate order total
        total = 0
        items = []
        
        for part in parts:
            part_id = part.get("part_id")
            quantity = part.get("quantity", 1)
            
            # Get mock part details to get price
            part_details = self._get_mock_part_details(supplier_id, part_id)
            price = part_details.get("price", 0)
            
            item_total = price * quantity
            total += item_total
            
            items.append({
                "part_id": part_id,
                "name": part_details.get("name"),
                "quantity": quantity,
                "unit_price": price,
                "total": item_total
            })
            
        # Add shipping cost
        shipping_cost = 15.99
        if supplier_id == "global_parts":
            shipping_cost = 12.99
        elif supplier_id == "euro_auto":
            shipping_cost = 18.99
            
        total += shipping_cost
        
        # Generate order confirmation
        return {
            "order_id": f"ORD-{supplier_id}-{int(total * 100)}",
            "status": "confirmed",
            "date": "2023-11-15T10:30:00Z",
            "items": items,
            "subtotal": total - shipping_cost,
            "shipping_cost": shipping_cost,
            "total": total,
            "shipping_address": shipping_info,
            "estimated_delivery": "2023-11-25",
            "tracking_number": f"TRK{int(total * 10)}",
            "tracking_url": f"https://track.{supplier_id}.example.com/track?number=TRK{int(total * 10)}"
        }

# Create Flask app for API testing
app = Flask(__name__)
parts_api = PartsSupplierAPI()

@app.route('/api/parts/search', methods=['GET'])
def search_parts():
    """API endpoint to search for parts"""
    query = request.args.get('query')
    make = request.args.get('make')
    model = request.args.get('model')
    year = request.args.get('year')
    suppliers = request.args.get('suppliers')
    
    if suppliers:
        suppliers = suppliers.split(',')
    
    result = parts_api.search_part(query, make, model, year, suppliers)
    return jsonify(result)

@app.route('/api/parts/details', methods=['GET'])
def get_part_details():
    """API endpoint to get part details"""
    part_id = request.args.get('part_id')
    supplier_id = request.args.get('supplier_id')
    
    result = parts_api.get_part_details(part_id, supplier_id)
    return jsonify(result)

@app.route('/api/parts/availability', methods=['GET'])
def check_availability():
    """API endpoint to check part availability"""
    part_id = request.args.get('part_id')
    supplier_id = request.args.get('supplier_id')
    quantity = request.args.get('quantity', 1)
    
    try:
        quantity = int(quantity)
    except ValueError:
        return jsonify({"error": "Quantity must be a valid integer"})
    
    result = parts_api.check_availability(part_id, supplier_id, quantity)
    return jsonify(result)

@app.route('/api/parts/order', methods=['POST'])
def place_order():
    """API endpoint to place an order"""
    data = request.json
    
    if not data:
        return jsonify({"error": "No data provided"})
    
    supplier_id = data.get('supplier_id')
    parts = data.get('parts', [])
    shipping_info = data.get('shipping_info', {})
    payment_info = data.get('payment_info', {})
    
    result = parts_api.place_order(supplier_id, parts, shipping_info, payment_info)
    return jsonify(result)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002, debug=True)

import logging
import requests
import json
import os
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class CRMInterface:
    """
    Interface for connecting to CRM systems to manage customer orders and sales
    """
    
    def __init__(self, crm_type="generic", config=None):
        """
        Initialize the CRM interface
        
        Args:
            crm_type (str): Type of CRM system ('generic', 'salesforce', 'zoho', etc.)
            config (dict, optional): Configuration parameters for the CRM connection
        """
        self.crm_type = crm_type.lower()
        self.config = config or {}
        
        # Set default configuration values if not provided
        self.api_base_url = self.config.get('api_base_url', 'https://api.example.com')
        self.api_key = self.config.get('api_key', '')
        self.api_version = self.config.get('api_version', 'v1')
        
        # Initialize connection
        self._initialize_connection()
        
        logger.info(f"CRM Interface initialized for {crm_type} CRM")
    
    def _initialize_connection(self):
        """Initialize connection to the CRM system"""
        # This would typically involve authentication and session setup
        # For now, we'll just set up the headers for API requests
        self.headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.api_key}',
            'Accept': 'application/json'
        }
        
        # Different initialization based on CRM type
        if self.crm_type == 'salesforce':
            # Salesforce-specific initialization
            self._initialize_salesforce()
        elif self.crm_type == 'zoho':
            # Zoho CRM-specific initialization
            self._initialize_zoho()
        else:
            # Generic CRM initialization
            logger.info("Using generic CRM interface")
    
    def _initialize_salesforce(self):
        """Initialize Salesforce-specific connection"""
        # In a real implementation, this would handle Salesforce OAuth flow
        logger.info("Initializing Salesforce connection")
        self.api_base_url = self.config.get('api_base_url', 'https://yourinstance.salesforce.com')
        self.api_version = self.config.get('api_version', 'v52.0')
        
        # Salesforce uses a different authorization header format
        self.headers['Authorization'] = f"Bearer {self.api_key}"
    
    def _initialize_zoho(self):
        """Initialize Zoho CRM-specific connection"""
        # In a real implementation, this would handle Zoho OAuth flow
        logger.info("Initializing Zoho CRM connection")
        self.api_base_url = self.config.get('api_base_url', 'https://www.zohoapis.com/crm')
        self.api_version = self.config.get('api_version', 'v2')
        
        # Zoho uses a different authorization header format
        self.headers['Authorization'] = f"Zoho-oauthtoken {self.api_key}"
    
    def _make_request(self, method, endpoint, data=None, params=None):
        """
        Make an HTTP request to the CRM API
        
        Args:
            method (str): HTTP method ('GET', 'POST', 'PUT', 'DELETE')
            endpoint (str): API endpoint
            data (dict, optional): Request body data
            params (dict, optional): Query parameters
            
        Returns:
            dict: Response data or error message
        """
        try:
            url = f"{self.api_base_url}/{self.api_version}/{endpoint}"
            
            response = requests.request(
                method=method,
                url=url,
                headers=self.headers,
                json=data if data else None,
                params=params if params else None
            )
            
            # Check if the request was successful
            response.raise_for_status()
            
            # Parse the response
            if response.content:
                return response.json()
            return {'status': 'success'}
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Error making CRM API request: {e}")
            return {'error': str(e)}
    
    def create_customer(self, customer_data):
        """
        Create a new customer in the CRM
        
        Args:
            customer_data (dict): Customer information
            
        Returns:
            dict: Created customer data or error message
        """
        try:
            # Map generic customer data to CRM-specific format
            crm_data = self._map_customer_data(customer_data)
            
            # Determine the endpoint based on CRM type
            if self.crm_type == 'salesforce':
                endpoint = 'sobjects/Contact'
            elif self.crm_type == 'zoho':
                endpoint = 'Contacts'
            else:
                endpoint = 'customers'
            
            # Make the API request
            response = self._make_request('POST', endpoint, data=crm_data)
            
            if 'error' in response:
                logger.error(f"Error creating customer: {response['error']}")
                return response
            
            logger.info(f"Customer created successfully: {response}")
            return response
            
        except Exception as e:
            logger.error(f"Error creating customer: {e}")
            return {'error': str(e)}
    
    def _map_customer_data(self, customer_data):
        """
        Map generic customer data to CRM-specific format
        
        Args:
            customer_data (dict): Generic customer data
            
        Returns:
            dict: CRM-specific customer data
        """
        # Extract common fields
        name = customer_data.get('name', '')
        email = customer_data.get('email', '')
        phone = customer_data.get('phone', '')
        address = customer_data.get('address', '')
        
        # Split name into first and last name if provided as full name
        first_name = customer_data.get('first_name', '')
        last_name = customer_data.get('last_name', '')
        
        if not (first_name and last_name) and ' ' in name:
            name_parts = name.split(' ', 1)
            first_name = name_parts[0]
            last_name = name_parts[1] if len(name_parts) > 1 else ''
        
        # Map to CRM-specific format
        if self.crm_type == 'salesforce':
            return {
                'FirstName': first_name,
                'LastName': last_name or 'Unknown',  # LastName is required in Salesforce
                'Email': email,
                'Phone': phone,
                'MailingStreet': address
            }
        elif self.crm_type == 'zoho':
            return {
                'data': [{
                    'First_Name': first_name,
                    'Last_Name': last_name or 'Unknown',  # Last_Name is required in Zoho
                    'Email': email,
                    'Phone': phone,
                    'Mailing_Street': address
                }]
            }
        else:
            # Generic format
            return {
                'first_name': first_name,
                'last_name': last_name,
                'email': email,
                'phone': phone,
                'address': address
            }
    
    def get_customer(self, customer_id):
        """
        Get customer information from the CRM
        
        Args:
            customer_id (str): Customer ID
            
        Returns:
            dict: Customer data or error message
        """
        try:
            # Determine the endpoint based on CRM type
            if self.crm_type == 'salesforce':
                endpoint = f'sobjects/Contact/{customer_id}'
            elif self.crm_type == 'zoho':
                endpoint = f'Contacts/{customer_id}'
            else:
                endpoint = f'customers/{customer_id}'
            
            # Make the API request
            response = self._make_request('GET', endpoint)
            
            if 'error' in response:
                logger.error(f"Error getting customer: {response['error']}")
                return response
            
            # Map CRM-specific response to generic format
            customer_data = self._map_crm_customer_data(response)
            
            logger.info(f"Retrieved customer: {customer_id}")
            return customer_data
            
        except Exception as e:
            logger.error(f"Error getting customer: {e}")
            return {'error': str(e)}
    
    def _map_crm_customer_data(self, crm_data):
        """
        Map CRM-specific customer data to generic format
        
        Args:
            crm_data (dict): CRM-specific customer data
            
        Returns:
            dict: Generic customer data
        """
        # Extract data based on CRM type
        if self.crm_type == 'salesforce':
            return {
                'id': crm_data.get('Id', ''),
                'first_name': crm_data.get('FirstName', ''),
                'last_name': crm_data.get('LastName', ''),
                'email': crm_data.get('Email', ''),
                'phone': crm_data.get('Phone', ''),
                'address': crm_data.get('MailingStreet', '')
            }
        elif self.crm_type == 'zoho':
            # Zoho typically returns data in a nested structure
            data = crm_data.get('data', [{}])[0]
            return {
                'id': data.get('id', ''),
                'first_name': data.get('First_Name', ''),
                'last_name': data.get('Last_Name', ''),
                'email': data.get('Email', ''),
                'phone': data.get('Phone', ''),
                'address': data.get('Mailing_Street', '')
            }
        else:
            # Generic format, assume the data is already in the right format
            return crm_data
    
    def search_customers(self, query):
        """
        Search for customers in the CRM
        
        Args:
            query (str): Search query
            
        Returns:
            list: List of matching customers
        """
        try:
            # Determine the endpoint and parameters based on CRM type
            if self.crm_type == 'salesforce':
                # Salesforce uses SOQL for queries
                soql_query = f"SELECT Id, FirstName, LastName, Email, Phone FROM Contact WHERE Name LIKE '%{query}%' OR Email LIKE '%{query}%'"
                endpoint = 'query'
                params = {'q': soql_query}
            elif self.crm_type == 'zoho':
                endpoint = 'Contacts/search'
                params = {'criteria': f"(First_Name:starts_with:{query}OR Last_Name:starts_with:{query})"}
            else:
                endpoint = 'customers/search'
                params = {'query': query}
            
            # Make the API request
            response = self._make_request('GET', endpoint, params=params)
            
            if 'error' in response:
                logger.error(f"Error searching customers: {response['error']}")
                return []
            
            # Extract and map the results
            customers = []
            
            if self.crm_type == 'salesforce':
                records = response.get('records', [])
                for record in records:
                    customers.append(self._map_crm_customer_data(record))
            elif self.crm_type == 'zoho':
                data = response.get('data', [])
                for item in data:
                    customers.append(self._map_crm_customer_data({'data': [item]}))
            else:
                # Generic format, assume the data is already in the right format
                customers = response.get('customers', [])
            
            logger.info(f"Found {len(customers)} customers matching '{query}'")
            return customers
            
        except Exception as e:
            logger.error(f"Error searching customers: {e}")
            return []
    
    def create_order(self, order_data):
        """
        Create a new order in the CRM
        
        Args:
            order_data (dict): Order information
            
        Returns:
            dict: Created order data or error message
        """
        try:
            # Map generic order data to CRM-specific format
            crm_data = self._map_order_data(order_data)
            
            # Determine the endpoint based on CRM type
            if self.crm_type == 'salesforce':
                endpoint = 'sobjects/Order'
            elif self.crm_type == 'zoho':
                endpoint = 'Sales_Orders'
            else:
                endpoint = 'orders'
            
            # Make the API request
            response = self._make_request('POST', endpoint, data=crm_data)
            
            if 'error' in response:
                logger.error(f"Error creating order: {response['error']}")
                return response
            
            logger.info(f"Order created successfully: {response}")
            return response
            
        except Exception as e:
            logger.error(f"Error creating order: {e}")
            return {'error': str(e)}
    
    def _map_order_data(self, order_data):
        """
        Map generic order data to CRM-specific format
        
        Args:
            order_data (dict): Generic order data
            
        Returns:
            dict: CRM-specific order data
        """
        # Extract common fields
        customer_id = order_data.get('customer_id', '')
        order_date = order_data.get('order_date', datetime.now().isoformat())
        status = order_data.get('status', 'New')
        total_amount = order_data.get('total_amount', 0)
        items = order_data.get('items', [])
        
        # Map to CRM-specific format
        if self.crm_type == 'salesforce':
            return {
                'AccountId': customer_id,  # In Salesforce, orders are linked to Accounts
                'EffectiveDate': order_date,
                'Status': status,
                'TotalAmount': total_amount
                # Items would typically be added as related records after creating the order
            }
        elif self.crm_type == 'zoho':
            return {
                'data': [{
                    'Customer_ID': customer_id,
                    'Order_Date': order_date,
                    'Status': status,
                    'Grand_Total': total_amount,
                    'Product_Details': items  # Zoho might have a different structure for line items
                }]
            }
        else:
            # Generic format
            return {
                'customer_id': customer_id,
                'order_date': order_date,
                'status': status,
                'total_amount': total_amount,
                'items': items
            }
    
    def get_order(self, order_id):
        """
        Get order information from the CRM
        
        Args:
            order_id (str): Order ID
            
        Returns:
            dict: Order data or error message
        """
        try:
            # Determine the endpoint based on CRM type
            if self.crm_type == 'salesforce':
                endpoint = f'sobjects/Order/{order_id}'
            elif self.crm_type == 'zoho':
                endpoint = f'Sales_Orders/{order_id}'
            else:
                endpoint = f'orders/{order_id}'
            
            # Make the API request
            response = self._make_request('GET', endpoint)
            
            if 'error' in response:
                logger.error(f"Error getting order: {response['error']}")
                return response
            
            # Map CRM-specific response to generic format
            order_data = self._map_crm_order_data(response)
            
            # For a complete order, we might need to make additional requests for line items
            if self.crm_type == 'salesforce':
                # Get order items in a separate request
                items_endpoint = f'query?q=SELECT Id, Product2Id, Quantity, UnitPrice FROM OrderItem WHERE OrderId=\'{order_id}\''
                items_response = self._make_request('GET', items_endpoint)
                
                if 'records' in items_response:
                    order_data['items'] = items_response['records']
            
            logger.info(f"Retrieved order: {order_id}")
            return order_data
            
        except Exception as e:
            logger.error(f"Error getting order: {e}")
            return {'error': str(e)}
    
    def _map_crm_order_data(self, crm_data):
        """
        Map CRM-specific order data to generic format
        
        Args:
            crm_data (dict): CRM-specific order data
            
        Returns:
            dict: Generic order data
        """
        # Extract data based on CRM type
        if self.crm_type == 'salesforce':
            return {
                'id': crm_data.get('Id', ''),
                'customer_id': crm_data.get('AccountId', ''),
                'order_date': crm_data.get('EffectiveDate', ''),
                'status': crm_data.get('Status', ''),
                'total_amount': crm_data.get('TotalAmount', 0),
                'items': []  # Items are fetched separately in Salesforce
            }
        elif self.crm_type == 'zoho':
            # Zoho typically returns data in a nested structure
            data = crm_data.get('data', [{}])[0]
            return {
                'id': data.get('id', ''),
                'customer_id': data.get('Customer_ID', ''),
                'order_date': data.get('Order_Date', ''),
                'status': data.get('Status', ''),
                'total_amount': data.get('Grand_Total', 0),
                'items': data.get('Product_Details', [])
            }
        else:
            # Generic format, assume the data is already in the right format
            return crm_data
    
    def update_order_status(self, order_id, status):
        """
        Update the status of an order in the CRM
        
        Args:
            order_id (str): Order ID
            status (str): New status
            
        Returns:
            dict: Response data or error message
        """
        try:
            # Determine the endpoint and data based on CRM type
            if self.crm_type == 'salesforce':
                endpoint = f'sobjects/Order/{order_id}'
                data = {'Status': status}
            elif self.crm_type == 'zoho':
                endpoint = f'Sales_Orders/{order_id}'
                data = {'data': [{'Status': status}]}
            else:
                endpoint = f'orders/{order_id}'
                data = {'status': status}
            
            # Make the API request
            response = self._make_request('PATCH', endpoint, data=data)
            
            if 'error' in response:
                logger.error(f"Error updating order status: {response['error']}")
                return response
            
            logger.info(f"Updated order {order_id} status to {status}")
            return {'status': 'success', 'message': f"Order {order_id} status updated to {status}"}
            
        except Exception as e:
            logger.error(f"Error updating order status: {e}")
            return {'error': str(e)}
    
    def get_customer_orders(self, customer_id):
        """
        Get all orders for a specific customer
        
        Args:
            customer_id (str): Customer ID
            
        Returns:
            list: List of orders
        """
        try:
            # Determine the endpoint and parameters based on CRM type
            if self.crm_type == 'salesforce':
                # Salesforce uses SOQL for queries
                soql_query = f"SELECT Id, AccountId, EffectiveDate, Status, TotalAmount FROM Order WHERE AccountId = '{customer_id}'"
                endpoint = 'query'
                params = {'q': soql_query}
            elif self.crm_type == 'zoho':
                endpoint = 'Sales_Orders/search'
                params = {'criteria': f"Customer_ID:equals:{customer_id}"}
            else:
                endpoint = f'customers/{customer_id}/orders'
                params = {}
            
            # Make the API request
            response = self._make_request('GET', endpoint, params=params)
            
            if 'error' in response:
                logger.error(f"Error getting customer orders: {response['error']}")
                return []
            
            # Extract and map the results
            orders = []
            
            if self.crm_type == 'salesforce':
                records = response.get('records', [])
                for record in records:
                    orders.append(self._map_crm_order_data(record))
            elif self.crm_type == 'zoho':
                data = response.get('data', [])
                for item in data:
                    orders.append(self._map_crm_order_data({'data': [item]}))
            else:
                # Generic format, assume the data is already in the right format
                orders = response.get('orders', [])
            
            logger.info(f"Found {len(orders)} orders for customer {customer_id}")
            return orders
            
        except Exception as e:
            logger.error(f"Error getting customer orders: {e}")
            return []
    
    def create_mock_data(self):
        """Create mock data for testing when not connected to a real CRM"""
        # This method would typically not be used in production
        # It's included here for testing and demonstration purposes
        
        logger.info("Creating mock CRM data for testing")
        
        # Mock customers
        self.mock_customers = [
            {
                'id': 'C001',
                'first_name': 'John',
                'last_name': 'Doe',
                'email': 'john.doe@example.com',
                'phone': '555-123-4567',
                'address': '123 Main St, Anytown, CA 12345'
            },
            {
                'id': 'C002',
                'first_name': 'Jane',
                'last_name': 'Smith',
                'email': 'jane.smith@example.com',
                'phone': '555-987-6543',
                'address': '456 Oak Ave, Somewhere, NY 67890'
            }
        ]
        
        # Mock orders
        self.mock_orders = [
            {
                'id': 'O001',
                'customer_id': 'C001',
                'order_date': '2023-05-15T10:30:00',
                'status': 'Completed',
                'total_amount': 129.99,
                'items': [
                    {
                        'id': 'I001',
                        'product_id': 'BP1001',
                        'name': 'Premium Brake Pad Set',
                        'quantity': 1,
                        'unit_price': 89.99
                    },
                    {
                        'id': 'I002',
                        'product_id': 'OF2001',
                        'name': 'Premium Oil Filter',
                        'quantity': 2,
                        'unit_price': 19.99
                    }
                ]
            },
            {
                'id': 'O002',
                'customer_id': 'C002',
                'order_date': '2023-05-16T14:45:00',
                'status': 'Processing',
                'total_amount': 45.97,
                'items': [
                    {
                        'id': 'I003',
                        'product_id': 'AF3001',
                        'name': 'Premium Air Filter',
                        'quantity': 1,
                        'unit_price': 19.99
                    },
                    {
                        'id': 'I004',
                        'product_id': 'OF2001',
                        'name': 'Premium Oil Filter',
                        'quantity': 1,
                        'unit_price': 12.99
                    },
                    {
                        'id': 'I005',
                        'product_id': 'WF4001',
                        'name': 'Windshield Wiper Fluid',
                        'quantity': 1,
                        'unit_price': 12.99
                    }
                ]
            }
        ]
        
        return {
            'customers': self.mock_customers,
            'orders': self.mock_orders
        }

# Example usage
if __name__ == '__main__':
    # Create a CRM interface
    crm = CRMInterface(crm_type='generic')
    
    # Create mock data for testing
    mock_data = crm.create_mock_data()
    
    # Print the mock data
    print(json.dumps(mock_data, indent=2))

import requests
import logging
import json
from datetime import datetime, time
import pytz

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class CKANVehicleAPI:
    """
    Client for interacting with the Israeli Ministry of Transport CKAN API
    for vehicle registration data
    """
    
    def __init__(self):
        self.base_url = "https://data.gov.il/api/3/action"
        self.resource_id = "053cea08-09bc-40ec-8f7a-156f0677aff3"  # Vehicle registration data resource ID
        self.timeout = 15  # seconds
        self.cache = {}
        self.cache_timestamp = None
        self.israel_tz = pytz.timezone('Asia/Jerusalem')
        
        logger.info("CKAN Vehicle API client initialized")
    
    def _is_cache_valid(self):
        """Check if the cache is still valid (before 9 AM refresh)"""
        if not self.cache_timestamp:
            return False
            
        now = datetime.now(self.israel_tz)
        refresh_time = time(9, 0)  # 9 AM
        
        # If it's after 9 AM today and our cache is from before 9 AM today, cache is invalid
        cache_date = self.cache_timestamp.date()
        if now.time() >= refresh_time and cache_date == now.date() and self.cache_timestamp.time() < refresh_time:
            return False
            
        # If it's a different day and after 9 AM, cache is invalid
        if cache_date < now.date() and now.time() >= refresh_time:
            return False
            
        return True
    
    def _make_api_request(self, endpoint, params=None):
        """Make a request to the CKAN API"""
        url = f"{self.base_url}/{endpoint}"
        
        try:
            response = requests.get(url, params=params, timeout=self.timeout)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            return {"success": False, "error": str(e)}
    
    def search_vehicle_by_license(self, license_plate):
        """
        Search for vehicle details by license plate number
        
        Args:
            license_plate (str): Vehicle license plate number
            
        Returns:
            dict: Vehicle details or error message
        """
        # Check if we need to refresh the cache
        if not self._is_cache_valid():
            self.cache = {}
            self.cache_timestamp = datetime.now(self.israel_tz)
            logger.info("Cache invalidated due to daily refresh time")
        
        # Check if we have this license plate in cache
        if license_plate in self.cache:
            logger.info(f"Returning cached data for license plate {license_plate}")
            return self.cache[license_plate]
        
        # Prepare the query
        params = {
            "resource_id": self.resource_id,
            "q": license_plate
        }
        
        # Make the API request
        result = self._make_api_request("datastore_search", params)
        
        if not result.get("success", False):
            logger.error(f"Error searching for license plate {license_plate}: {result.get('error')}")
            return {"error": f"API request failed: {result.get('error', 'Unknown error')}"}
        
        # Process the results
        records = result.get("result", {}).get("records", [])
        
        if not records:
            logger.info(f"No vehicle found with license plate {license_plate}")
            return {"error": f"No vehicle found with license plate {license_plate}"}
        
        # Format the vehicle data
        vehicle_data = self._format_vehicle_data(records[0])
        
        # Cache the result
        self.cache[license_plate] = vehicle_data
        
        return vehicle_data
    
    def get_vehicle_data(self, make, model, year):
        """
        Get vehicle data by make, model, and year
        
        Args:
            make (str): Vehicle make
            model (str): Vehicle model
            year (str): Vehicle year
            
        Returns:
            dict: Vehicle data or error message
        """
        # Prepare the query
        filters = []
        if make:
            filters.append(f"tozeret_nm:{make}")
        if model:
            filters.append(f"degem_nm:{model}")
        if year:
            filters.append(f"shnat_yitzur:{year}")
            
        query = " AND ".join(filters)
        
        params = {
            "resource_id": self.resource_id,
            "q": query,
            "limit": 1
        }
        
        # Make the API request
        result = self._make_api_request("datastore_search", params)
        
        if not result.get("success", False):
            logger.error(f"Error searching for vehicle with query {query}: {result.get('error')}")
            return {"error": f"API request failed: {result.get('error', 'Unknown error')}"}
        
        # Process the results
        records = result.get("result", {}).get("records", [])
        
        if not records:
            logger.info(f"No vehicle found with query {query}")
            return {"error": f"No vehicle found with query {query}"}
        
        # Format the vehicle data
        vehicle_data = self._format_vehicle_data(records[0])
        
        return vehicle_data
    
    def search_vehicles_by_make_model(self, make=None, model=None, limit=10):
        """
        Search for vehicles by make and/or model
        
        Args:
            make (str, optional): Vehicle make
            model (str, optional): Vehicle model
            limit (int, optional): Maximum number of results to return
            
        Returns:
            dict: List of vehicles or error message
        """
        if not make and not model:
            return {"error": "At least one of make or model must be provided"}
        
        # Prepare the query
        filters = []
        if make:
            filters.append(f"tozeret_nm:{make}")
        if model:
            filters.append(f"degem_nm:{model}")
            
        query = " AND ".join(filters)
        
        params = {
            "resource_id": self.resource_id,
            "q": query,
            "limit": limit
        }
        
        # Make the API request
        result = self._make_api_request("datastore_search", params)
        
        if not result.get("success", False):
            logger.error(f"Error searching for vehicles with query {query}: {result.get('error')}")
            return {"error": f"API request failed: {result.get('error', 'Unknown error')}"}
        
        # Process the results
        records = result.get("result", {}).get("records", [])
        
        if not records:
            logger.info(f"No vehicles found with query {query}")
            return {"error": f"No vehicles found with query {query}"}
        
        # Format the vehicle data
        vehicles = [self._format_vehicle_data(record) for record in records]
        
        return {
            "count": len(vehicles),
            "vehicles": vehicles
        }
    
    def get_vehicle_compatibility(self, part_id, license_plate=None, make=None, model=None, year=None):
        """
        Check if a part is compatible with a specific vehicle
        
        Args:
            part_id (str): Part identifier
            license_plate (str, optional): Vehicle license plate
            make (str, optional): Vehicle make
            model (str, optional): Vehicle model
            year (int, optional): Vehicle year
            
        Returns:
            dict: Compatibility information or error message
        """
        # Get vehicle details
        vehicle = None
        
        if license_plate:
            result = self.search_vehicle_by_license(license_plate)
            if "error" not in result:
                vehicle = result
        elif make and model:
            # For simplicity, we'll just use the first vehicle that matches
            result = self.search_vehicles_by_make_model(make, model, limit=1)
            if "error" not in result and result.get("count", 0) > 0:
                vehicle = result["vehicles"][0]
        
        if not vehicle:
            return {"error": "Could not find vehicle details"}
        
        # In a real implementation, we would check a parts database for compatibility
        # For this demo, we'll use a simplified compatibility check
        
        # Extract vehicle details
        vehicle_make = vehicle.get("make", "")
        vehicle_model = vehicle.get("model", "")
        vehicle_year = vehicle.get("year", 0)
        
        # Simple compatibility logic based on part_id prefix
        compatibility = {
            "compatible": False,
            "confidence": 0,
            "notes": "",
            "alternatives": []
        }
        
        # Brake pads compatibility
        if part_id.startswith("BP"):
            if "Toyota" in vehicle_make and "Corolla" in vehicle_model:
                compatibility["compatible"] = True
                compatibility["confidence"] = 95
                compatibility["notes"] = "High compatibility with Toyota Corolla models"
            elif "Honda" in vehicle_make:
                compatibility["compatible"] = True
                compatibility["confidence"] = 90
                compatibility["notes"] = "Good compatibility with Honda models"
            else:
                compatibility["compatible"] = False
                compatibility["confidence"] = 60
                compatibility["notes"] = "Limited compatibility data available"
                compatibility["alternatives"] = ["BP1001", "BP1002"]
        
        # Oil filters compatibility
        elif part_id.startswith("OF"):
            if vehicle_year >= 2018:
                compatibility["compatible"] = True
                compatibility["confidence"] = 85
                compatibility["notes"] = "Compatible with newer models from 2018 onwards"
            else:
                compatibility["compatible"] = False
                compatibility["confidence"] = 70
                compatibility["notes"] = "Recommended for models from 2018 onwards"
                compatibility["alternatives"] = ["OF2001", "OF2002"]
        
        # Default case
        else:
            compatibility["compatible"] = "unknown"
            compatibility["confidence"] = 50
            compatibility["notes"] = "Insufficient data to determine compatibility"
        
        # Add vehicle details to the response
        compatibility["vehicle"] = {
            "license_plate": vehicle.get("license_plate", ""),
            "make": vehicle_make,
            "model": vehicle_model,
            "year": vehicle_year
        }
        
        return compatibility
    
    def _format_vehicle_data(self, record):
        """
        Format the raw CKAN API response into a standardized vehicle data format
        
        Args:
            record (dict): Raw vehicle record from CKAN API
            
        Returns:
            dict: Formatted vehicle data
        """
        # Map CKAN field names to our standardized format
        # Field mapping based on the screenshots provided
        try:
            return {
                "license_plate": record.get("mispar_rechev", ""),
                "make": record.get("tozeret_nm", ""),
                "model": record.get("degem_nm", ""),
                "year": int(record.get("shnat_yitzur", 0)) if record.get("shnat_yitzur") else 0,
                "engine_type": record.get("sug_delek_nm", ""),
                "color": record.get("tzeva_rechev", ""),
                "last_test_date": record.get("mivchan_acharon_dt", ""),
                "ownership_type": record.get("baalut", ""),
                "raw_data": record  # Include the raw data for reference
            }
        except Exception as e:
            logger.error(f"Error formatting vehicle data: {e}")
            return {
                "error": f"Error formatting vehicle data: {str(e)}",
                "raw_data": record
            }

# Create Flask app for API testing
if __name__ == '__main__':
    import flask
    from flask import Flask, request, jsonify
    
    app = Flask(__name__)
    vehicle_api = CKANVehicleAPI()
    
    @app.route('/api/vehicle/license/<license_plate>', methods=['GET'])
    def get_vehicle_by_license(license_plate):
        """API endpoint to get vehicle details by license plate"""
        result = vehicle_api.search_vehicle_by_license(license_plate)
        return jsonify(result)
    
    @app.route('/api/vehicle/search', methods=['GET'])
    def search_vehicles():
        """API endpoint to search for vehicles by make and model"""
        make = request.args.get('make')
        model = request.args.get('model')
        limit = request.args.get('limit', 10)
        
        try:
            limit = int(limit)
        except ValueError:
            return jsonify({"error": "Limit must be a valid integer"})
        
        result = vehicle_api.search_vehicles_by_make_model(make, model, limit)
        return jsonify(result)
    
    @app.route('/api/vehicle/compatibility', methods=['GET'])
    def check_compatibility():
        """API endpoint to check part compatibility with a vehicle"""
        part_id = request.args.get('part_id')
        license_plate = request.args.get('license_plate')
        make = request.args.get('make')
        model = request.args.get('model')
        year = request.args.get('year')
        
        if not part_id:
            return jsonify({"error": "Part ID is required"})
            
        if not license_plate and not (make and model):
            return jsonify({"error": "Either license_plate or make and model must be provided"})
            
        if year:
            try:
                year = int(year)
            except ValueError:
                return jsonify({"error": "Year must be a valid integer"})
        
        result = vehicle_api.get_vehicle_compatibility(part_id, license_plate, make, model, year)
        return jsonify(result)
    
    app.run(host='0.0.0.0', port=5003, debug=True)

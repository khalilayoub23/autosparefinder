import requests
import logging
import json
from datetime import datetime
import os
from PIL import Image
import io
import base64
import numpy as np
import cv2

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ImageRecognitionAPI:
    """
    Client for image recognition of car parts
    """
    
    def __init__(self):
        self.models_dir = os.path.join(os.path.dirname(__file__), '../models')
        self.ensure_models_exist()
        logger.info("Image Recognition API client initialized")
    
    def ensure_models_exist(self):
        """Ensure that the required models exist"""
        os.makedirs(self.models_dir, exist_ok=True)
        # In a real implementation, we would download models if they don't exist
        # For this demo, we'll just log a message
        logger.info(f"Models directory checked: {self.models_dir}")
    
    def recognize_part(self, image_data=None, image_path=None):
        """
        Recognize a car part from an image
        
        Args:
            image_data (bytes, optional): Raw image data
            image_path (str, optional): Path to image file
            
        Returns:
            dict: Recognition results or error message
        """
        try:
            # Load the image
            if image_data:
                image = Image.open(io.BytesIO(image_data))
            elif image_path:
                image = Image.open(image_path)
            else:
                return {"error": "Either image_data or image_path must be provided"}
            
            # Convert to OpenCV format for processing
            img_array = np.array(image)
            if len(img_array.shape) == 3 and img_array.shape[2] == 4:  # RGBA
                img_array = cv2.cvtColor(img_array, cv2.COLOR_RGBA2RGB)
            
            # In a real implementation, we would use a trained model for recognition
            # For this demo, we'll use a simple color-based heuristic
            
            # Convert to HSV for better color segmentation
            hsv = cv2.cvtColor(img_array, cv2.COLOR_RGB2HSV)
            
            # Define color ranges for common car parts
            # These are very simplified and would not work well in practice
            
            # Brake pad - typically dark gray/black
            lower_brake = np.array([0, 0, 0])
            upper_brake = np.array([180, 50, 100])
            brake_mask = cv2.inRange(hsv, lower_brake, upper_brake)
            brake_pixels = cv2.countNonZero(brake_mask)
            
            # Oil filter - typically yellow/orange
            lower_oil = np.array([10, 100, 100])
            upper_oil = np.array([30, 255, 255])
            oil_mask = cv2.inRange(hsv, lower_oil, upper_oil)
            oil_pixels = cv2.countNonZero(oil_mask)
            
            # Air filter - typically white/light gray
            lower_air = np.array([0, 0, 150])
            upper_air = np.array([180, 30, 255])
            air_mask = cv2.inRange(hsv, lower_air, upper_air)
            air_pixels = cv2.countNonZero(air_mask)
            
            # Determine the most likely part based on color distribution
            total_pixels = img_array.shape[0] * img_array.shape[1]
            brake_ratio = brake_pixels / total_pixels
            oil_ratio = oil_pixels / total_pixels
            air_ratio = air_pixels / total_pixels
            
            # Create the result
            result = {
                "recognized": True,
                "confidence": 0,
                "part_type": "",
                "possible_matches": []
            }
            
            # Simple decision logic
            if brake_ratio > 0.3 and brake_ratio > oil_ratio and brake_ratio > air_ratio:
                result["part_type"] = "brake_pad"
                result["confidence"] = min(brake_ratio * 100, 95)
                result["possible_matches"] = [
                    {"id": "BP1001", "name": "Premium Brake Pad", "confidence": result["confidence"]},
                    {"id": "BP1002", "name": "Standard Brake Pad", "confidence": result["confidence"] - 10}
                ]
            elif oil_ratio > 0.2 and oil_ratio > brake_ratio and oil_ratio > air_ratio:
                result["part_type"] = "oil_filter"
                result["confidence"] = min(oil_ratio * 100, 95)
                result["possible_matches"] = [
                    {"id": "OF2001", "name": "Premium Oil Filter", "confidence": result["confidence"]},
                    {"id": "OF2002", "name": "Standard Oil Filter", "confidence": result["confidence"] - 10}
                ]
            elif air_ratio > 0.2 and air_ratio > brake_ratio and air_ratio > oil_ratio:
                result["part_type"] = "air_filter"
                result["confidence"] = min(air_ratio * 100, 95)
                result["possible_matches"] = [
                    {"id": "AF3001", "name": "Premium Air Filter", "confidence": result["confidence"]},
                    {"id": "AF3002", "name": "Standard Air Filter", "confidence": result["confidence"] - 10}
                ]
            else:
                result["recognized"] = False
                result["confidence"] = 0
                result["part_type"] = "unknown"
                result["possible_matches"] = []
            
            return result
            
        except Exception as e:
            logger.error(f"Error recognizing part: {e}")
            return {"error": f"Error recognizing part: {str(e)}"}
    
    def recognize_part_from_base64(self, base64_image):
        """
        Recognize a car part from a base64-encoded image
        
        Args:
            base64_image (str): Base64-encoded image data
            
        Returns:
            dict: Recognition results or error message
        """
        try:
            # Decode the base64 image
            image_data = base64.b64decode(base64_image)
            return self.recognize_part(image_data=image_data)
        except Exception as e:
            logger.error(f"Error decoding base64 image: {e}")
            return {"error": f"Error decoding base64 image: {str(e)}"}

# Create Flask app for API testing
if __name__ == '__main__':
    from flask import Flask, request, jsonify
    
    app = Flask(__name__)
    recognition_api = ImageRecognitionAPI()
    
    @app.route('/api/recognize', methods=['POST'])
    def recognize_part():
        """API endpoint to recognize a car part from an image"""
        if 'image' not in request.files:
            return jsonify({"error": "No image provided"})
        
        image_file = request.files['image']
        result = recognition_api.recognize_part(image_data=image_file.read())
        return jsonify(result)
    
    @app.route('/api/recognize/base64', methods=['POST'])
    def recognize_part_base64():
        """API endpoint to recognize a car part from a base64-encoded image"""
        data = request.json
        if not data or 'image' not in data:
            return jsonify({"error": "No base64 image provided"})
        
        result = recognition_api.recognize_part_from_base64(data['image'])
        return jsonify(result)
    
    app.run(host='0.0.0.0', port=5005, debug=True)

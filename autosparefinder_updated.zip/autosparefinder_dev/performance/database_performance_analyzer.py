import logging
import time
import sqlite3
import json
import os
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("database_performance_analysis.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("DB_PERFORMANCE_ANALYZER")

class DatabasePerformanceAnalyzer:
    """
    A tool for analyzing and optimizing database performance in the AutoSpareFinder system,
    with special focus on the new EV-related data and queries.
    """
    
    def __init__(self, db_path=None):
        """Initialize the analyzer with the path to the database"""
        self.db_path = db_path or os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "database", "parts_catalog.db"
        )
        self.results_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "performance_analysis"
        )
        Path(self.results_dir).mkdir(exist_ok=True)
        
        self.conn = None
        self.queries_to_analyze = {
            "ev_parts_by_manufacturer": """
                SELECT * FROM parts 
                WHERE type = 'electric' 
                AND manufacturer_id = ?
                ORDER BY catalog_number
            """,
            "ev_battery_compatibility": """
                SELECT p.*, vc.notes as compatibility_notes 
                FROM parts p
                JOIN vehicle_compatibility vc ON p.id = vc.part_id
                WHERE p.type = 'electric'
                AND vc.manufacturer_id = ?
                AND vc.model = ?
            """,
            "ev_charging_components": """
                SELECT * FROM parts
                WHERE description LIKE '%charger%' OR description LIKE '%charging%'
                ORDER BY manufacturer_id, catalog_number
            """,
            "ev_parts_search": """
                SELECT * FROM parts
                WHERE type = 'electric'
                AND (
                    description LIKE ? 
                    OR catalog_number LIKE ?
                )
                ORDER BY manufacturer_id, catalog_number
            """,
            "ev_manufacturer_models": """
                SELECT DISTINCT model 
                FROM vehicle_compatibility vc
                JOIN parts p ON vc.part_id = p.id
                WHERE vc.manufacturer_id = ?
                AND p.type = 'electric'
                ORDER BY model
            """
        }
        
        # Define optimized versions of the queries
        self.optimized_queries = {
            "ev_parts_by_manufacturer": """
                SELECT id, catalog_number, description, price, currency 
                FROM parts 
                WHERE type = 'electric' 
                AND manufacturer_id = ?
                ORDER BY catalog_number
            """,
            "ev_battery_compatibility": """
                SELECT p.id, p.catalog_number, p.description, p.price, vc.notes as compatibility_notes 
                FROM parts p
                JOIN vehicle_compatibility vc ON p.id = vc.part_id
                WHERE p.type = 'electric'
                AND vc.manufacturer_id = ?
                AND vc.model = ?
            """,
            "ev_charging_components": """
                SELECT id, catalog_number, description, manufacturer_id, price
                FROM parts
                WHERE description LIKE '%charger%' OR description LIKE '%charging%'
                ORDER BY manufacturer_id, catalog_number
            """,
            "ev_parts_search": """
                SELECT id, catalog_number, description, manufacturer_id, price
                FROM parts
                WHERE type = 'electric'
                AND (
                    description LIKE ? 
                    OR catalog_number LIKE ?
                )
                ORDER BY manufacturer_id, catalog_number
                LIMIT 100
            """,
            "ev_manufacturer_models": """
                SELECT DISTINCT model 
                FROM vehicle_compatibility vc
                JOIN parts p ON vc.part_id = p.id
                WHERE vc.manufacturer_id = ?
                AND p.type = 'electric'
                ORDER BY model
            """
        }
        
        # Define indexes to create
        self.indexes_to_create = [
            "CREATE INDEX IF NOT EXISTS idx_parts_type ON parts(type)",
            "CREATE INDEX IF NOT EXISTS idx_parts_manufacturer_id ON parts(manufacturer_id)",
            "CREATE INDEX IF NOT EXISTS idx_parts_catalog_number ON parts(catalog_number)",
            "CREATE INDEX IF NOT EXISTS idx_parts_description ON parts(description)",
            "CREATE INDEX IF NOT EXISTS idx_vehicle_compatibility_manufacturer_id ON vehicle_compatibility(manufacturer_id)",
            "CREATE INDEX IF NOT EXISTS idx_vehicle_compatibility_model ON vehicle_compatibility(model)",
            "CREATE INDEX IF NOT EXISTS idx_vehicle_compatibility_part_id ON vehicle_compatibility(part_id)",
            "CREATE INDEX IF NOT EXISTS idx_manufacturers_name ON manufacturers(name)"
        ]
        
        # Test parameters
        self.test_params = {
            "ev_parts_by_manufacturer": [(1,), (2,), (3,), (4,), (5,)],
            "ev_battery_compatibility": [
                (1, "Model 3"), 
                (2, "R1T"), 
                (3, "Air"), 
                (4, "Seal U"),
                (5, "Polestar 2")
            ],
            "ev_charging_components": [()],
            "ev_parts_search": [
                ("%battery%", "%battery%"),
                ("%motor%", "%motor%"),
                ("%charger%", "%charger%"),
                ("%inverter%", "%inverter%"),
                ("%cooling%", "%cooling%")
            ],
            "ev_manufacturer_models": [(1,), (2,), (3,), (4,), (5,)]
        }
    
    def connect(self):
        """Connect to the database"""
        try:
            self.conn = sqlite3.connect(self.db_path)
            self.conn.row_factory = sqlite3.Row
            logger.info(f"Connected to database at {self.db_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to database: {e}")
            return False
    
    def close(self):
        """Close the database connection"""
        if self.conn:
            self.conn.close()
            logger.info("Database connection closed")
    
    def analyze_query_performance(self, query_name, query, params, iterations=10):
        """Analyze the performance of a specific query"""
        if not self.conn:
            logger.error("No database connection")
            return None
        
        cursor = self.conn.cursor()
        execution_times = []
        
        try:
            # Warm up
            for param in params:
                cursor.execute(query, param)
                cursor.fetchall()
            
            # Measure performance
            for param in params:
                for _ in range(iterations):
                    start_time = time.time()
                    cursor.execute(query, param)
                    results = cursor.fetchall()
                    end_time = time.time()
                    execution_times.append(end_time - start_time)
                    
            avg_time = sum(execution_times) / len(execution_times)
            result_count = len(results)
            
            logger.info(f"Query '{query_name}' - Avg execution time: {avg_time:.6f}s, Results: {result_count}")
            
            return {
                "query_name": query_name,
                "avg_execution_time": avg_time,
                "min_execution_time": min(execution_times),
                "max_execution_time": max(execution_times),
                "result_count": result_count,
                "iterations": iterations * len(params)
            }
        except Exception as e:
            logger.error(f"Error analyzing query '{query_name}': {e}")
            return None
    
    def create_indexes(self):
        """Create indexes to optimize query performance"""
        if not self.conn:
            logger.error("No database connection")
            return False
        
        cursor = self.conn.cursor()
        
        try:
            for index_sql in self.indexes_to_create:
                start_time = time.time()
                cursor.execute(index_sql)
                end_time = time.time()
                logger.info(f"Created index: {index_sql} in {end_time - start_time:.6f}s")
            
            self.conn.commit()
            logger.info("All indexes created successfully")
            return True
        except Exception as e:
            logger.error(f"Error creating indexes: {e}")
            return False
    
    def analyze_all_queries(self):
        """Analyze performance of all defined queries"""
        if not self.connect():
            return False
        
        results = {
            "original": {},
            "optimized": {}
        }
        
        # Analyze original queries
        logger.info("Analyzing original queries...")
        for query_name, query in self.queries_to_analyze.items():
            params = self.test_params[query_name]
            result = self.analyze_query_performance(query_name, query, params)
            if result:
                results["original"][query_name] = result
        
        # Create indexes
        logger.info("Creating indexes...")
        self.create_indexes()
        
        # Analyze optimized queries
        logger.info("Analyzing optimized queries...")
        for query_name, query in self.optimized_queries.items():
            params = self.test_params[query_name]
            result = self.analyze_query_performance(query_name, query, params)
            if result:
                results["optimized"][query_name] = result
        
        self.close()
        
        # Save results
        self.save_results(results)
        
        return results
    
    def save_results(self, results):
        """Save analysis results to a file"""
        results_file = os.path.join(self.results_dir, "query_performance_results.json")
        
        try:
            with open(results_file, 'w') as f:
                json.dump(results, f, indent=2)
            logger.info(f"Results saved to {results_file}")
            
            # Generate markdown report
            self.generate_markdown_report(results)
            
            return True
        except Exception as e:
            logger.error(f"Error saving results: {e}")
            return False
    
    def generate_markdown_report(self, results):
        """Generate a markdown report from the analysis results"""
        report_file = os.path.join(self.results_dir, "database_performance_report.md")
        
        try:
            with open(report_file, 'w') as f:
                f.write("# דוח ביצועי מסד נתונים - AutoSpareFinder EV\n\n")
                f.write("## סיכום ביצועים\n\n")
                
                f.write("| שם השאילתה | זמן ממוצע (מקורי) | זמן ממוצע (מותאם) | שיפור |\n")
                f.write("|------------|-------------------|-------------------|-------|\n")
                
                for query_name in results["original"]:
                    if query_name in results["optimized"]:
                        orig_time = results["original"][query_name]["avg_execution_time"]
                        opt_time = results["optimized"][query_name]["avg_execution_time"]
                        improvement = ((orig_time - opt_time) / orig_time) * 100
                        
                        f.write(f"| {query_name} | {orig_time:.6f}s | {opt_time:.6f}s | {improvement:.2f}% |\n")
                
                f.write("\n## פרטי שאילתות\n\n")
                
                for query_name in results["original"]:
                    f.write(f"### {query_name}\n\n")
                    
                    f.write("#### שאילתה מקורית\n")
                    f.write("```sql\n")
                    f.write(self.queries_to_analyze[query_name])
                    f.write("\n```\n\n")
                    
                    f.write("#### שאילתה מותאמת\n")
                    f.write("```sql\n")
                    f.write(self.optimized_queries[query_name])
                    f.write("\n```\n\n")
                    
                    orig_result = results["original"][query_name]
                    opt_result = results["optimized"][query_name]
                    
                    f.write("#### ביצועים\n\n")
                    f.write(f"- **זמן ממוצע (מקורי)**: {orig_result['avg_execution_time']:.6f}s\n")
                    f.write(f"- **זמן ממוצע (מותאם)**: {opt_result['avg_execution_time']:.6f}s\n")
                    f.write(f"- **זמן מינימלי (מקורי)**: {orig_result['min_execution_time']:.6f}s\n")
                    f.write(f"- **זמן מינימלי (מותאם)**: {opt_result['min_execution_time']:.6f}s\n")
                    f.write(f"- **זמן מקסימלי (מקורי)**: {orig_result['max_execution_time']:.6f}s\n")
                    f.write(f"- **זמן מקסימלי (מותאם)**: {opt_result['max_execution_time']:.6f}s\n")
                    f.write(f"- **מספר תוצאות**: {orig_result['result_count']}\n")
                    f.write(f"- **מספר איטרציות**: {orig_result['iterations']}\n\n")
                
                f.write("## אינדקסים שנוצרו\n\n")
                for index_sql in self.indexes_to_create:
                    f.write(f"- `{index_sql}`\n")
                
                f.write("\n## המלצות נוספות\n\n")
                f.write("1. **שימוש במטמון (Cache)**: יישום מנגנון מטמון לשאילתות נפוצות כמו רשימת דגמים לפי יצרן\n")
                f.write("2. **פיצול טבלאות**: שקול פיצול טבלת החלקים לטבלאות נפרדות לפי סוג רכב (חשמלי, היברידי, בנזין)\n")
                f.write("3. **שימוש בטבלאות זמניות**: לשאילתות מורכבות, שקול שימוש בטבלאות זמניות לאחסון תוצאות ביניים\n")
                f.write("4. **עדכון סטטיסטיקות**: הרץ `ANALYZE` באופן תקופתי לעדכון סטטיסטיקות המסד\n")
                f.write("5. **שדרוג לגרסת SQLite חדשה יותר**: שקול שדרוג לגרסה העדכנית ביותר של SQLite לניצול שיפורי ביצועים\n")
            
            logger.info(f"Markdown report generated at {report_file}")
            return True
        except Exception as e:
            logger.error(f"Error generating markdown report: {e}")
            return False

if __name__ == "__main__":
    analyzer = DatabasePerformanceAnalyzer()
    results = analyzer.analyze_all_queries()
    print("Analysis complete. Check the logs and results directory for details.")

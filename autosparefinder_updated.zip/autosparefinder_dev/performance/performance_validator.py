import logging
import os
import json
import time
import sys
from pathlib import Path
from datetime import datetime

# Add the parent directory to sys.path to allow importing the cache_system module
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import the cache system
from performance.cache_system import CacheSystem

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("performance_validation.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("PERFORMANCE_VALIDATOR")

class PerformanceValidator:
    """
    A tool for validating and documenting the performance improvements
    in the AutoSpareFinder system, particularly for EV-related features.
    """
    
    def __init__(self):
        """Initialize the performance validator"""
        self.results_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "performance_validation"
        )
        Path(self.results_dir).mkdir(exist_ok=True)
        
        # Initialize cache system for testing
        self.cache = CacheSystem()
        
        # Define test scenarios
        self.test_scenarios = {
            "ev_manufacturer_lookup": {
                "description": "Lookup EV manufacturers",
                "iterations": 50,
                "function": self.test_manufacturer_lookup,
                "params": ["Tesla", "Rivian", "Lucid Motors", "BYD", "Polestar"]
            },
            "ev_model_lookup": {
                "description": "Lookup EV models by manufacturer",
                "iterations": 50,
                "function": self.test_model_lookup,
                "params": ["Tesla", "Rivian", "Lucid Motors", "BYD", "Polestar"]
            },
            "ev_part_compatibility": {
                "description": "Check EV part compatibility",
                "iterations": 30,
                "function": self.test_part_compatibility,
                "params": [
                    ("Tesla", "Model 3", "battery"),
                    ("Rivian", "R1T", "motor"),
                    ("Lucid Motors", "Air", "inverter"),
                    ("BYD", "Seal U", "charging_port"),
                    ("Polestar", "Polestar 2", "cooling_system")
                ]
            },
            "ev_part_search": {
                "description": "Search for EV parts",
                "iterations": 20,
                "function": self.test_part_search,
                "params": ["battery", "motor", "inverter", "charger", "cooling"]
            }
        }
    
    def test_manufacturer_lookup(self, manufacturer):
        """Test manufacturer lookup performance"""
        # Simulate database lookup
        time.sleep(0.01)  # Base time
        return {"name": manufacturer, "country": "USA", "founded": 2003}
    
    def test_model_lookup(self, manufacturer):
        """Test model lookup performance with caching"""
        # Use the cached decorator
        @self.cache.cached("ev_models")
        def get_models(mfr):
            # Simulate database lookup
            time.sleep(0.2)  # Expensive operation
            models = {
                "Tesla": ["Model S", "Model 3", "Model X", "Model Y", "Cybertruck"],
                "Rivian": ["R1T", "R1S"],
                "Lucid Motors": ["Air"],
                "BYD": ["Seal U", "Atto 3"],
                "Polestar": ["Polestar 2", "Polestar 3"]
            }
            return models.get(mfr, [])
        
        return get_models(manufacturer)
    
    def test_part_compatibility(self, params):
        """Test part compatibility check performance with caching"""
        manufacturer, model, part_type = params
        
        # Use the cached decorator
        @self.cache.cached("ev_compatibility")
        def check_compatibility(mfr, mdl, part):
            # Simulate complex compatibility check
            time.sleep(0.3)  # Very expensive operation
            return {
                "compatible": True,
                "notes": f"Compatible with {mfr} {mdl}",
                "alternatives": ["OEM", "Aftermarket"]
            }
        
        return check_compatibility(manufacturer, model, part_type)
    
    def test_part_search(self, keyword):
        """Test part search performance with optimized query"""
        # Simulate optimized database query
        time.sleep(0.15)  # Moderately expensive operation
        return [f"{keyword}_part_{i}" for i in range(1, 6)]
    
    def run_tests(self, with_cache=True):
        """
        Run all test scenarios and measure performance
        
        Args:
            with_cache (bool): Whether to use caching
            
        Returns:
            dict: Test results
        """
        results = {}
        
        # Clear cache before starting if using cache
        if with_cache:
            self.cache.clear()
        
        for scenario_name, scenario in self.test_scenarios.items():
            logger.info(f"Running scenario: {scenario_name} - {scenario['description']}")
            
            scenario_results = {
                "description": scenario["description"],
                "with_cache": with_cache,
                "iterations": scenario["iterations"],
                "execution_times": [],
                "params_results": {}
            }
            
            for param in scenario["params"]:
                param_key = str(param)
                scenario_results["params_results"][param_key] = {
                    "first_execution_time": None,
                    "subsequent_execution_times": []
                }
                
                # First execution (cold)
                start_time = time.time()
                result = scenario["function"](param)
                execution_time = time.time() - start_time
                
                scenario_results["execution_times"].append(execution_time)
                scenario_results["params_results"][param_key]["first_execution_time"] = execution_time
                
                # Subsequent executions
                for i in range(scenario["iterations"] - 1):
                    start_time = time.time()
                    result = scenario["function"](param)
                    execution_time = time.time() - start_time
                    
                    scenario_results["execution_times"].append(execution_time)
                    scenario_results["params_results"][param_key]["subsequent_execution_times"].append(execution_time)
            
            # Calculate statistics
            execution_times = scenario_results["execution_times"]
            scenario_results["avg_execution_time"] = sum(execution_times) / len(execution_times)
            scenario_results["min_execution_time"] = min(execution_times)
            scenario_results["max_execution_time"] = max(execution_times)
            
            # For each param, calculate average of subsequent executions
            for param_key, param_results in scenario_results["params_results"].items():
                subsequent_times = param_results["subsequent_execution_times"]
                if subsequent_times:
                    param_results["avg_subsequent_time"] = sum(subsequent_times) / len(subsequent_times)
                    param_results["speedup"] = param_results["first_execution_time"] / param_results["avg_subsequent_time"] if param_results["avg_subsequent_time"] > 0 else 0
            
            results[scenario_name] = scenario_results
            
            logger.info(f"Completed scenario: {scenario_name} - Avg time: {scenario_results['avg_execution_time']:.6f}s")
        
        # Add cache statistics if using cache
        if with_cache:
            results["cache_stats"] = self.cache.get_stats()
        
        return results
    
    def validate_performance(self):
        """
        Validate performance with and without optimizations
        
        Returns:
            dict: Validation results
        """
        logger.info("Starting performance validation")
        
        # Run tests without cache
        logger.info("Running tests without cache")
        no_cache_results = self.run_tests(with_cache=False)
        
        # Run tests with cache
        logger.info("Running tests with cache")
        with_cache_results = self.run_tests(with_cache=True)
        
        # Compare results
        comparison = self.compare_results(no_cache_results, with_cache_results)
        
        # Save results
        self.save_results({
            "no_cache": no_cache_results,
            "with_cache": with_cache_results,
            "comparison": comparison,
            "timestamp": datetime.now().isoformat()
        })
        
        return comparison
    
    def compare_results(self, no_cache_results, with_cache_results):
        """
        Compare results with and without optimizations
        
        Args:
            no_cache_results (dict): Results without cache
            with_cache_results (dict): Results with cache
            
        Returns:
            dict: Comparison results
        """
        comparison = {}
        
        for scenario_name in self.test_scenarios:
            if scenario_name in no_cache_results and scenario_name in with_cache_results:
                no_cache = no_cache_results[scenario_name]
                with_cache = with_cache_results[scenario_name]
                
                avg_no_cache = no_cache["avg_execution_time"]
                avg_with_cache = with_cache["avg_execution_time"]
                
                improvement = ((avg_no_cache - avg_with_cache) / avg_no_cache) * 100
                
                comparison[scenario_name] = {
                    "description": self.test_scenarios[scenario_name]["description"],
                    "avg_time_no_cache": avg_no_cache,
                    "avg_time_with_cache": avg_with_cache,
                    "improvement_percent": improvement,
                    "speedup_factor": avg_no_cache / avg_with_cache if avg_with_cache > 0 else 0
                }
        
        return comparison
    
    def save_results(self, results):
        """
        Save validation results to files
        
        Args:
            results (dict): Validation results
        """
        # Save JSON results
        results_file = os.path.join(self.results_dir, "performance_validation_results.json")
        with open(results_file, 'w') as f:
            json.dump(results, f, indent=2)
        
        logger.info(f"Results saved to {results_file}")
        
        # Generate markdown report
        self.generate_markdown_report(results)
    
    def generate_markdown_report(self, results):
        """
        Generate a markdown report from validation results
        
        Args:
            results (dict): Validation results
        """
        report_file = os.path.join(self.results_dir, "performance_validation_report.md")
        
        with open(report_file, 'w') as f:
            f.write("# דוח אימות ביצועים - AutoSpareFinder EV\n\n")
            f.write(f"**תאריך הבדיקה:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            f.write("## סיכום שיפורי ביצועים\n\n")
            f.write("| תרחיש | תיאור | זמן ממוצע (ללא מטמון) | זמן ממוצע (עם מטמון) | שיפור | מקדם האצה |\n")
            f.write("|-------|-------|----------------------|---------------------|-------|------------|\n")
            
            for scenario_name, comparison in results["comparison"].items():
                f.write(f"| {scenario_name} | {comparison['description']} | {comparison['avg_time_no_cache']:.6f}s | {comparison['avg_time_with_cache']:.6f}s | {comparison['improvement_percent']:.2f}% | {comparison['speedup_factor']:.2f}x |\n")
            
            f.write("\n## סטטיסטיקות מטמון\n\n")
            if "cache_stats" in results["with_cache"]:
                cache_stats = results["with_cache"]["cache_stats"]
                f.write(f"- **פניות למטמון:** {cache_stats['total_requests']}\n")
                f.write(f"- **פגיעות במטמון:** {cache_stats['hits']}\n")
                f.write(f"- **החטאות במטמון:** {cache_stats['misses']}\n")
                f.write(f"- **אחוז פגיעות:** {cache_stats['hit_rate']:.2f}%\n")
                f.write(f"- **הוספות למטמון:** {cache_stats['sets']}\n")
                f.write(f"- **ביטולי תוקף:** {cache_stats['invalidations']}\n")
            
            f.write("\n## פרטי תרחישים\n\n")
            for scenario_name, scenario in results["with_cache"].items():
                if scenario_name != "cache_stats":
                    f.write(f"### {scenario_name} - {scenario['description']}\n\n")
                    f.write(f"- **מספר איטרציות:** {scenario['iterations']}\n")
                    f.write(f"- **זמן ממוצע:** {scenario['avg_execution_time']:.6f}s\n")
                    f.write(f"- **זמן מינימלי:** {scenario['min_execution_time']:.6f}s\n")
                    f.write(f"- **זמן מקסימלי:** {scenario['max_execution_time']:.6f}s\n\n")
                    
                    f.write("#### ביצועים לפי פרמטר\n\n")
                    f.write("| פרמטר | זמן ריצה ראשון | זמן ריצה ממוצע (הבא) | האצה |\n")
                    f.write("|--------|---------------|---------------------|-------|\n")
                    
                    for param_key, param_results in scenario["params_results"].items():
                        if "avg_subsequent_time" in param_results:
                            f.write(f"| {param_key} | {param_results['first_execution_time']:.6f}s | {param_results['avg_subsequent_time']:.6f}s | {param_results['speedup']:.2f}x |\n")
                    
                    f.write("\n")
            
            f.write("\n## המלצות נוספות\n\n")
            f.write("1. **הרחבת מטמון**: הרחבת מנגנון המטמון לכלול שאילתות נוספות ותרחישי שימוש נפוצים\n")
            f.write("2. **מטמון מבוזר**: שקילת שימוש במערכת מטמון מבוזרת כמו Redis לסביבת ייצור\n")
            f.write("3. **מטמון שכבתי**: יישום מטמון שכבתי (בזיכרון ובדיסק) לאיזון בין מהירות לזמינות\n")
            f.write("4. **פרה-חימום מטמון**: טעינת נתונים נפוצים למטמון בעת אתחול המערכת\n")
            f.write("5. **ניטור מטמון**: הוספת מערכת ניטור למטמון לזיהוי דפוסי שימוש ואופטימיזציה נוספת\n")
        
        logger.info(f"Markdown report generated at {report_file}")

if __name__ == "__main__":
    validator = PerformanceValidator()
    comparison = validator.validate_performance()
    
    print("\nPerformance Comparison Summary:")
    for scenario_name, result in comparison.items():
        print(f"- {scenario_name}: {result['improvement_percent']:.2f}% improvement ({result['speedup_factor']:.2f}x faster)")
    
    print("\nValidation complete. Check the logs and results directory for details.")

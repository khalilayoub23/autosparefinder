import logging
import time
import json
import os
import hashlib
from pathlib import Path
from functools import wraps
from datetime import datetime, timedelta

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("cache_system.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger("CACHE_SYSTEM")

class CacheSystem:
    """
    A caching system for AutoSpareFinder to improve response times for frequently accessed data,
    particularly for EV-related queries.
    """
    
    def __init__(self, cache_dir=None, default_ttl=3600):
        """
        Initialize the cache system
        
        Args:
            cache_dir (str): Directory to store cache files
            default_ttl (int): Default time-to-live for cache entries in seconds (default: 1 hour)
        """
        self.cache_dir = cache_dir or os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "cache"
        )
        Path(self.cache_dir).mkdir(exist_ok=True)
        self.default_ttl = default_ttl
        
        # Statistics tracking
        self.stats = {
            "hits": 0,
            "misses": 0,
            "sets": 0,
            "invalidations": 0
        }
        
        logger.info(f"Cache system initialized with cache directory: {self.cache_dir}")
    
    def _get_cache_key(self, prefix, args, kwargs):
        """Generate a unique cache key based on function arguments"""
        key_parts = [prefix]
        
        # Add positional arguments
        for arg in args:
            key_parts.append(str(arg))
        
        # Add keyword arguments (sorted to ensure consistency)
        for k in sorted(kwargs.keys()):
            key_parts.append(f"{k}:{kwargs[k]}")
        
        # Create a hash of the key parts
        key_str = "_".join(key_parts)
        return hashlib.md5(key_str.encode()).hexdigest()
    
    def _get_cache_path(self, key):
        """Get the file path for a cache key"""
        return os.path.join(self.cache_dir, f"{key}.json")
    
    def get(self, key):
        """
        Retrieve a value from the cache
        
        Args:
            key (str): Cache key
            
        Returns:
            The cached value or None if not found or expired
        """
        cache_path = self._get_cache_path(key)
        
        if not os.path.exists(cache_path):
            self.stats["misses"] += 1
            return None
        
        try:
            with open(cache_path, 'r') as f:
                cache_data = json.load(f)
            
            # Check if the cache entry has expired
            expires_at = datetime.fromisoformat(cache_data["expires_at"])
            if expires_at < datetime.now():
                logger.debug(f"Cache entry expired for key: {key}")
                os.remove(cache_path)
                self.stats["misses"] += 1
                return None
            
            logger.debug(f"Cache hit for key: {key}")
            self.stats["hits"] += 1
            return cache_data["value"]
            
        except Exception as e:
            logger.error(f"Error reading cache for key {key}: {e}")
            self.stats["misses"] += 1
            return None
    
    def set(self, key, value, ttl=None):
        """
        Store a value in the cache
        
        Args:
            key (str): Cache key
            value: Value to store (must be JSON serializable)
            ttl (int): Time-to-live in seconds, or None to use default
            
        Returns:
            bool: True if successful, False otherwise
        """
        if ttl is None:
            ttl = self.default_ttl
        
        expires_at = datetime.now() + timedelta(seconds=ttl)
        
        cache_data = {
            "value": value,
            "created_at": datetime.now().isoformat(),
            "expires_at": expires_at.isoformat(),
            "ttl": ttl
        }
        
        try:
            cache_path = self._get_cache_path(key)
            with open(cache_path, 'w') as f:
                json.dump(cache_data, f)
            
            logger.debug(f"Cache set for key: {key}, expires at: {expires_at}")
            self.stats["sets"] += 1
            return True
            
        except Exception as e:
            logger.error(f"Error setting cache for key {key}: {e}")
            return False
    
    def invalidate(self, key):
        """
        Remove a specific entry from the cache
        
        Args:
            key (str): Cache key to invalidate
            
        Returns:
            bool: True if successful, False otherwise
        """
        cache_path = self._get_cache_path(key)
        
        if os.path.exists(cache_path):
            try:
                os.remove(cache_path)
                logger.debug(f"Cache invalidated for key: {key}")
                self.stats["invalidations"] += 1
                return True
            except Exception as e:
                logger.error(f"Error invalidating cache for key {key}: {e}")
                return False
        
        return False
    
    def invalidate_pattern(self, pattern):
        """
        Remove all cache entries matching a pattern
        
        Args:
            pattern (str): Pattern to match against cache keys
            
        Returns:
            int: Number of entries invalidated
        """
        count = 0
        for filename in os.listdir(self.cache_dir):
            if pattern in filename and filename.endswith('.json'):
                try:
                    os.remove(os.path.join(self.cache_dir, filename))
                    count += 1
                    self.stats["invalidations"] += 1
                except Exception as e:
                    logger.error(f"Error invalidating cache file {filename}: {e}")
        
        logger.debug(f"Invalidated {count} cache entries matching pattern: {pattern}")
        return count
    
    def clear(self):
        """
        Clear all cache entries
        
        Returns:
            int: Number of entries cleared
        """
        count = 0
        for filename in os.listdir(self.cache_dir):
            if filename.endswith('.json'):
                try:
                    os.remove(os.path.join(self.cache_dir, filename))
                    count += 1
                    self.stats["invalidations"] += 1
                except Exception as e:
                    logger.error(f"Error clearing cache file {filename}: {e}")
        
        logger.info(f"Cleared {count} cache entries")
        return count
    
    def get_stats(self):
        """
        Get cache statistics
        
        Returns:
            dict: Cache statistics
        """
        # Calculate hit rate
        total_requests = self.stats["hits"] + self.stats["misses"]
        hit_rate = (self.stats["hits"] / total_requests) * 100 if total_requests > 0 else 0
        
        return {
            **self.stats,
            "hit_rate": hit_rate,
            "total_requests": total_requests
        }
    
    def cached(self, prefix, ttl=None):
        """
        Decorator for caching function results
        
        Args:
            prefix (str): Prefix for the cache key
            ttl (int): Time-to-live in seconds, or None to use default
            
        Returns:
            Decorated function
        """
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                # Generate cache key
                cache_key = self._get_cache_key(prefix, args, kwargs)
                
                # Try to get from cache
                cached_result = self.get(cache_key)
                if cached_result is not None:
                    return cached_result
                
                # Call the original function
                result = func(*args, **kwargs)
                
                # Store in cache
                self.set(cache_key, result, ttl)
                
                return result
            return wrapper
        return decorator

# Example usage
if __name__ == "__main__":
    # Create cache system
    cache = CacheSystem()
    
    # Example function with caching
    @cache.cached("ev_models")
    def get_ev_models_by_manufacturer(manufacturer):
        # This would normally be a database query
        print(f"Fetching EV models for {manufacturer} (expensive operation)")
        time.sleep(1)  # Simulate expensive operation
        
        models = {
            "Tesla": ["Model S", "Model 3", "Model X", "Model Y", "Cybertruck"],
            "Rivian": ["R1T", "R1S"],
            "Lucid Motors": ["Air"],
            "BYD": ["Seal U", "Atto 3"],
            "Polestar": ["Polestar 2", "Polestar 3"]
        }
        
        return models.get(manufacturer, [])
    
    # Test the cached function
    print("First call (should be slow):")
    start = time.time()
    models = get_ev_models_by_manufacturer("Tesla")
    print(f"Models: {models}")
    print(f"Time taken: {time.time() - start:.4f}s")
    
    print("\nSecond call (should be fast, from cache):")
    start = time.time()
    models = get_ev_models_by_manufacturer("Tesla")
    print(f"Models: {models}")
    print(f"Time taken: {time.time() - start:.4f}s")
    
    print("\nDifferent manufacturer (should be slow):")
    start = time.time()
    models = get_ev_models_by_manufacturer("Rivian")
    print(f"Models: {models}")
    print(f"Time taken: {time.time() - start:.4f}s")
    
    # Print cache statistics
    print("\nCache statistics:")
    print(json.dumps(cache.get_stats(), indent=2))

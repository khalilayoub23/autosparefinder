# דוח ביצועי מסד נתונים - AutoSpareFinder EV

## סיכום ביצועים

| שם השאילתה | זמן ממוצע (מקורי) | זמן ממוצע (מותאם) | שיפור |
|------------|-------------------|-------------------|-------|
| ev_parts_by_manufacturer | 0.000270s | 0.000021s | 92.29% |
| ev_battery_compatibility | 0.000007s | 0.000007s | 4.01% |
| ev_charging_components | 0.000653s | 0.000649s | 0.70% |
| ev_parts_search | 0.000266s | 0.000032s | 87.88% |
| ev_manufacturer_models | 0.000007s | 0.000007s | -2.59% |

## פרטי שאילתות

### ev_parts_by_manufacturer

#### שאילתה מקורית
```sql

                SELECT * FROM parts 
                WHERE type = 'electric' 
                AND manufacturer_id = ?
                ORDER BY catalog_number
            
```

#### שאילתה מותאמת
```sql

                SELECT id, catalog_number, description, price, currency 
                FROM parts 
                WHERE type = 'electric' 
                AND manufacturer_id = ?
                ORDER BY catalog_number
            
```

#### ביצועים

- **זמן ממוצע (מקורי)**: 0.000270s
- **זמן ממוצע (מותאם)**: 0.000021s
- **זמן מינימלי (מקורי)**: 0.000195s
- **זמן מינימלי (מותאם)**: 0.000007s
- **זמן מקסימלי (מקורי)**: 0.000601s
- **זמן מקסימלי (מותאם)**: 0.000090s
- **מספר תוצאות**: 0
- **מספר איטרציות**: 50

### ev_battery_compatibility

#### שאילתה מקורית
```sql

                SELECT p.*, vc.notes as compatibility_notes 
                FROM parts p
                JOIN vehicle_compatibility vc ON p.id = vc.part_id
                WHERE p.type = 'electric'
                AND vc.manufacturer_id = ?
                AND vc.model = ?
            
```

#### שאילתה מותאמת
```sql

                SELECT p.id, p.catalog_number, p.description, p.price, vc.notes as compatibility_notes 
                FROM parts p
                JOIN vehicle_compatibility vc ON p.id = vc.part_id
                WHERE p.type = 'electric'
                AND vc.manufacturer_id = ?
                AND vc.model = ?
            
```

#### ביצועים

- **זמן ממוצע (מקורי)**: 0.000007s
- **זמן ממוצע (מותאם)**: 0.000007s
- **זמן מינימלי (מקורי)**: 0.000007s
- **זמן מינימלי (מותאם)**: 0.000006s
- **זמן מקסימלי (מקורי)**: 0.000008s
- **זמן מקסימלי (מותאם)**: 0.000014s
- **מספר תוצאות**: 0
- **מספר איטרציות**: 50

### ev_charging_components

#### שאילתה מקורית
```sql

                SELECT * FROM parts
                WHERE description LIKE '%charger%' OR description LIKE '%charging%'
                ORDER BY manufacturer_id, catalog_number
            
```

#### שאילתה מותאמת
```sql

                SELECT id, catalog_number, description, manufacturer_id, price
                FROM parts
                WHERE description LIKE '%charger%' OR description LIKE '%charging%'
                ORDER BY manufacturer_id, catalog_number
            
```

#### ביצועים

- **זמן ממוצע (מקורי)**: 0.000653s
- **זמן ממוצע (מותאם)**: 0.000649s
- **זמן מינימלי (מקורי)**: 0.000535s
- **זמן מינימלי (מותאם)**: 0.000640s
- **זמן מקסימלי (מקורי)**: 0.000858s
- **זמן מקסימלי (מותאם)**: 0.000663s
- **מספר תוצאות**: 0
- **מספר איטרציות**: 10

### ev_parts_search

#### שאילתה מקורית
```sql

                SELECT * FROM parts
                WHERE type = 'electric'
                AND (
                    description LIKE ? 
                    OR catalog_number LIKE ?
                )
                ORDER BY manufacturer_id, catalog_number
            
```

#### שאילתה מותאמת
```sql

                SELECT id, catalog_number, description, manufacturer_id, price
                FROM parts
                WHERE type = 'electric'
                AND (
                    description LIKE ? 
                    OR catalog_number LIKE ?
                )
                ORDER BY manufacturer_id, catalog_number
                LIMIT 100
            
```

#### ביצועים

- **זמן ממוצע (מקורי)**: 0.000266s
- **זמן ממוצע (מותאם)**: 0.000032s
- **זמן מינימלי (מקורי)**: 0.000221s
- **זמן מינימלי (מותאם)**: 0.000030s
- **זמן מקסימלי (מקורי)**: 0.000696s
- **זמן מקסימלי (מותאם)**: 0.000050s
- **מספר תוצאות**: 0
- **מספר איטרציות**: 50

### ev_manufacturer_models

#### שאילתה מקורית
```sql

                SELECT DISTINCT model 
                FROM vehicle_compatibility vc
                JOIN parts p ON vc.part_id = p.id
                WHERE vc.manufacturer_id = ?
                AND p.type = 'electric'
                ORDER BY model
            
```

#### שאילתה מותאמת
```sql

                SELECT DISTINCT model 
                FROM vehicle_compatibility vc
                JOIN parts p ON vc.part_id = p.id
                WHERE vc.manufacturer_id = ?
                AND p.type = 'electric'
                ORDER BY model
            
```

#### ביצועים

- **זמן ממוצע (מקורי)**: 0.000007s
- **זמן ממוצע (מותאם)**: 0.000007s
- **זמן מינימלי (מקורי)**: 0.000006s
- **זמן מינימלי (מותאם)**: 0.000007s
- **זמן מקסימלי (מקורי)**: 0.000019s
- **זמן מקסימלי (מותאם)**: 0.000014s
- **מספר תוצאות**: 0
- **מספר איטרציות**: 50

## אינדקסים שנוצרו

- `CREATE INDEX IF NOT EXISTS idx_parts_type ON parts(type)`
- `CREATE INDEX IF NOT EXISTS idx_parts_manufacturer_id ON parts(manufacturer_id)`
- `CREATE INDEX IF NOT EXISTS idx_parts_catalog_number ON parts(catalog_number)`
- `CREATE INDEX IF NOT EXISTS idx_parts_description ON parts(description)`
- `CREATE INDEX IF NOT EXISTS idx_vehicle_compatibility_manufacturer_id ON vehicle_compatibility(manufacturer_id)`
- `CREATE INDEX IF NOT EXISTS idx_vehicle_compatibility_model ON vehicle_compatibility(model)`
- `CREATE INDEX IF NOT EXISTS idx_vehicle_compatibility_part_id ON vehicle_compatibility(part_id)`
- `CREATE INDEX IF NOT EXISTS idx_manufacturers_name ON manufacturers(name)`

## המלצות נוספות

1. **שימוש במטמון (Cache)**: יישום מנגנון מטמון לשאילתות נפוצות כמו רשימת דגמים לפי יצרן
2. **פיצול טבלאות**: שקול פיצול טבלת החלקים לטבלאות נפרדות לפי סוג רכב (חשמלי, היברידי, בנזין)
3. **שימוש בטבלאות זמניות**: לשאילתות מורכבות, שקול שימוש בטבלאות זמניות לאחסון תוצאות ביניים
4. **עדכון סטטיסטיקות**: הרץ `ANALYZE` באופן תקופתי לעדכון סטטיסטיקות המסד
5. **שדרוג לגרסת SQLite חדשה יותר**: שקול שדרוג לגרסה העדכנית ביותר של SQLite לניצול שיפורי ביצועים

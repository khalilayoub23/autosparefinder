/**
 * Data protection and encryption utilities for AutoSpareFinder system
 * 
 * This module provides functions for encrypting and decrypting sensitive data,
 * implementing data protection measures, and managing secure storage.
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// Encryption algorithm and key settings
const ENCRYPTION_ALGORITHM = 'aes-256-gcm';
const KEY_LENGTH = 32; // 256 bits
const IV_LENGTH = 16; // 128 bits
const AUTH_TAG_LENGTH = 16; // 128 bits
const SALT_LENGTH = 64;
const KEY_ITERATIONS = 100000;
const KEY_DIGEST = 'sha512';

/**
 * Generate a secure encryption key
 * @returns {Buffer} - Encryption key
 */
function generateEncryptionKey() {
    return crypto.randomBytes(KEY_LENGTH);
}

/**
 * Derive an encryption key from a password
 * @param {string} password - Password to derive key from
 * @param {Buffer} salt - Salt for key derivation
 * @returns {Buffer} - Derived key
 */
function deriveKeyFromPassword(password, salt) {
    return crypto.pbkdf2Sync(
        password,
        salt,
        KEY_ITERATIONS,
        KEY_LENGTH,
        KEY_DIGEST
    );
}

/**
 * Encrypt data using AES-256-GCM
 * @param {string|Buffer} data - Data to encrypt
 * @param {Buffer} key - Encryption key
 * @param {Object} options - Additional options
 * @returns {Object} - Encrypted data with IV and auth tag
 */
function encrypt(data, key, options = {}) {
    // Convert string data to buffer if needed
    const dataBuffer = Buffer.isBuffer(data) ? data : Buffer.from(data, 'utf8');
    
    // Generate random initialization vector
    const iv = crypto.randomBytes(IV_LENGTH);
    
    // Create cipher
    const cipher = crypto.createCipheriv(ENCRYPTION_ALGORITHM, key, iv);
    
    // Set AAD if provided (Additional Authenticated Data)
    if (options.aad) {
        cipher.setAAD(Buffer.isBuffer(options.aad) ? options.aad : Buffer.from(options.aad, 'utf8'));
    }
    
    // Encrypt data
    const encryptedData = Buffer.concat([
        cipher.update(dataBuffer),
        cipher.final()
    ]);
    
    // Get authentication tag
    const authTag = cipher.getAuthTag();
    
    return {
        encryptedData,
        iv,
        authTag,
        algorithm: ENCRYPTION_ALGORITHM
    };
}

/**
 * Decrypt data using AES-256-GCM
 * @param {Buffer} encryptedData - Encrypted data
 * @param {Buffer} key - Encryption key
 * @param {Buffer} iv - Initialization vector
 * @param {Buffer} authTag - Authentication tag
 * @param {Object} options - Additional options
 * @returns {Buffer} - Decrypted data
 */
function decrypt(encryptedData, key, iv, authTag, options = {}) {
    // Create decipher
    const decipher = crypto.createDecipheriv(ENCRYPTION_ALGORITHM, key, iv);
    
    // Set authentication tag
    decipher.setAuthTag(authTag);
    
    // Set AAD if provided (Additional Authenticated Data)
    if (options.aad) {
        decipher.setAAD(Buffer.isBuffer(options.aad) ? options.aad : Buffer.from(options.aad, 'utf8'));
    }
    
    // Decrypt data
    const decryptedData = Buffer.concat([
        decipher.update(encryptedData),
        decipher.final()
    ]);
    
    return decryptedData;
}

/**
 * Encrypt a file
 * @param {string} inputPath - Path to input file
 * @param {string} outputPath - Path to output file
 * @param {Buffer} key - Encryption key
 * @param {Object} options - Additional options
 * @returns {Promise<Object>} - Encryption metadata
 */
async function encryptFile(inputPath, outputPath, key, options = {}) {
    return new Promise((resolve, reject) => {
        try {
            // Generate random initialization vector
            const iv = crypto.randomBytes(IV_LENGTH);
            
            // Create cipher
            const cipher = crypto.createCipheriv(ENCRYPTION_ALGORITHM, key, iv);
            
            // Set AAD if provided
            if (options.aad) {
                cipher.setAAD(Buffer.isBuffer(options.aad) ? options.aad : Buffer.from(options.aad, 'utf8'));
            }
            
            // Create read and write streams
            const readStream = fs.createReadStream(inputPath);
            const writeStream = fs.createWriteStream(outputPath);
            
            // Write IV to output file
            writeStream.write(iv);
            
            // Pipe data through cipher
            readStream.pipe(cipher).pipe(writeStream);
            
            writeStream.on('finish', () => {
                // Get authentication tag
                const authTag = cipher.getAuthTag();
                
                // Append auth tag to file
                fs.appendFileSync(outputPath, authTag);
                
                resolve({
                    iv,
                    authTag,
                    algorithm: ENCRYPTION_ALGORITHM
                });
            });
            
            readStream.on('error', reject);
            writeStream.on('error', reject);
            cipher.on('error', reject);
        } catch (error) {
            reject(error);
        }
    });
}

/**
 * Decrypt a file
 * @param {string} inputPath - Path to encrypted file
 * @param {string} outputPath - Path to output decrypted file
 * @param {Buffer} key - Encryption key
 * @param {Object} options - Additional options
 * @returns {Promise<void>}
 */
async function decryptFile(inputPath, outputPath, key, options = {}) {
    return new Promise((resolve, reject) => {
        try {
            // Get file stats
            const stats = fs.statSync(inputPath);
            const fileSize = stats.size;
            
            // File must be at least IV_LENGTH + AUTH_TAG_LENGTH bytes
            if (fileSize < IV_LENGTH + AUTH_TAG_LENGTH) {
                return reject(new Error('Invalid encrypted file'));
            }
            
            // Read IV and auth tag from file
            const fd = fs.openSync(inputPath, 'r');
            const iv = Buffer.alloc(IV_LENGTH);
            fs.readSync(fd, iv, 0, IV_LENGTH, 0);
            
            const authTag = Buffer.alloc(AUTH_TAG_LENGTH);
            fs.readSync(fd, authTag, 0, AUTH_TAG_LENGTH, fileSize - AUTH_TAG_LENGTH);
            fs.closeSync(fd);
            
            // Create decipher
            const decipher = crypto.createDecipheriv(ENCRYPTION_ALGORITHM, key, iv);
            decipher.setAuthTag(authTag);
            
            // Set AAD if provided
            if (options.aad) {
                decipher.setAAD(Buffer.isBuffer(options.aad) ? options.aad : Buffer.from(options.aad, 'utf8'));
            }
            
            // Create read and write streams
            const readStream = fs.createReadStream(inputPath, {
                start: IV_LENGTH,
                end: fileSize - AUTH_TAG_LENGTH - 1
            });
            const writeStream = fs.createWriteStream(outputPath);
            
            // Pipe data through decipher
            readStream.pipe(decipher).pipe(writeStream);
            
            writeStream.on('finish', resolve);
            readStream.on('error', reject);
            writeStream.on('error', reject);
            decipher.on('error', reject);
        } catch (error) {
            reject(error);
        }
    });
}

/**
 * Encrypt sensitive data for storage
 * @param {Object} data - Data to encrypt
 * @param {string} masterKey - Master encryption key
 * @returns {Object} - Encrypted data object
 */
function encryptSensitiveData(data, masterKey) {
    // Generate a data key for this specific data
    const dataKey = generateEncryptionKey();
    
    // Encrypt the data with the data key
    const { encryptedData, iv, authTag } = encrypt(JSON.stringify(data), dataKey);
    
    // Encrypt the data key with the master key
    const { encryptedData: encryptedDataKey, iv: keyIv, authTag: keyAuthTag } = encrypt(dataKey, Buffer.from(masterKey, 'hex'));
    
    return {
        encryptedData: encryptedData.toString('base64'),
        iv: iv.toString('base64'),
        authTag: authTag.toString('base64'),
        encryptedDataKey: encryptedDataKey.toString('base64'),
        keyIv: keyIv.toString('base64'),
        keyAuthTag: keyAuthTag.toString('base64')
    };
}

/**
 * Decrypt sensitive data from storage
 * @param {Object} encryptedObject - Encrypted data object
 * @param {string} masterKey - Master encryption key
 * @returns {Object} - Decrypted data
 */
function decryptSensitiveData(encryptedObject, masterKey) {
    // Decrypt the data key
    const dataKey = decrypt(
        Buffer.from(encryptedObject.encryptedDataKey, 'base64'),
        Buffer.from(masterKey, 'hex'),
        Buffer.from(encryptedObject.keyIv, 'base64'),
        Buffer.from(encryptedObject.keyAuthTag, 'base64')
    );
    
    // Decrypt the data with the data key
    const decryptedData = decrypt(
        Buffer.from(encryptedObject.encryptedData, 'base64'),
        dataKey,
        Buffer.from(encryptedObject.iv, 'base64'),
        Buffer.from(encryptedObject.authTag, 'base64')
    );
    
    return JSON.parse(decryptedData.toString('utf8'));
}

/**
 * Hash sensitive data for comparison (not for passwords)
 * @param {string} data - Data to hash
 * @returns {string} - Hashed data
 */
function hashData(data) {
    return crypto
        .createHash('sha256')
        .update(data)
        .digest('hex');
}

/**
 * Generate a secure random password
 * @param {number} length - Password length
 * @param {Object} options - Password generation options
 * @returns {string} - Generated password
 */
function generateSecurePassword(length = 16, options = {}) {
    const defaults = {
        lowercase: true,
        uppercase: true,
        numbers: true,
        symbols: true
    };
    
    const config = { ...defaults, ...options };
    
    let chars = '';
    if (config.lowercase) chars += 'abcdefghijklmnopqrstuvwxyz';
    if (config.uppercase) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (config.numbers) chars += '0123456789';
    if (config.symbols) chars += '!@#$%^&*()_+-=[]{}|;:,.<>?';
    
    let password = '';
    const randomBytes = crypto.randomBytes(length);
    
    for (let i = 0; i < length; i++) {
        password += chars[randomBytes[i] % chars.length];
    }
    
    return password;
}

/**
 * Securely compare two strings in constant time
 * @param {string} a - First string
 * @param {string} b - Second string
 * @returns {boolean} - True if strings are equal
 */
function secureCompare(a, b) {
    return crypto.timingSafeEqual(
        Buffer.from(a),
        Buffer.from(b)
    );
}

/**
 * Mask sensitive data in logs and outputs
 * @param {Object} data - Data object
 * @param {string[]} sensitiveFields - List of sensitive field names
 * @returns {Object} - Data with masked sensitive fields
 */
function maskSensitiveData(data, sensitiveFields) {
    const maskedData = { ...data };
    
    for (const field of sensitiveFields) {
        if (maskedData[field]) {
            if (typeof maskedData[field] === 'string') {
                const length = maskedData[field].length;
                if (length <= 4) {
                    maskedData[field] = '****';
                } else {
                    maskedData[field] = maskedData[field].substring(0, 2) + 
                        '*'.repeat(length - 4) + 
                        maskedData[field].substring(length - 2);
                }
            } else {
                maskedData[field] = '****';
            }
        }
    }
    
    return maskedData;
}

/**
 * Sanitize file paths to prevent path traversal attacks
 * @param {string} filePath - File path to sanitize
 * @param {string} basePath - Base directory path
 * @returns {string} - Sanitized file path
 */
function sanitizeFilePath(filePath, basePath) {
    // Normalize the path to resolve .. and . segments
    const normalizedPath = path.normalize(filePath);
    
    // Join with base path to ensure it's within the allowed directory
    const fullPath = path.join(basePath, normalizedPath);
    
    // Check if the path is still within the base directory
    if (!fullPath.startsWith(basePath)) {
        throw new Error('Path traversal attempt detected');
    }
    
    return fullPath;
}

/**
 * Create a secure temporary file
 * @param {string} prefix - File name prefix
 * @param {Object} options - Options for temporary file
 * @returns {Object} - Temporary file information
 */
function createSecureTempFile(prefix, options = {}) {
    const tempDir = options.tempDir || os.tmpdir();
    const randomSuffix = crypto.randomBytes(16).toString('hex');
    const fileName = `${prefix}_${randomSuffix}`;
    const filePath = path.join(tempDir, fileName);
    
    // Create empty file with secure permissions
    fs.writeFileSync(filePath, '', { mode: 0o600 });
    
    return {
        path: filePath,
        name: fileName,
        remove: () => {
            try {
                fs.unlinkSync(filePath);
                return true;
            } catch (error) {
                console.error(`Failed to remove temp file ${filePath}:`, error);
                return false;
            }
        }
    };
}

module.exports = {
    generateEncryptionKey,
    deriveKeyFromPassword,
    encrypt,
    decrypt,
    encryptFile,
    decryptFile,
    encryptSensitiveData,
    decryptSensitiveData,
    hashData,
    generateSecurePassword,
    secureCompare,
    maskSensitiveData,
    sanitizeFilePath,
    createSecureTempFile
};

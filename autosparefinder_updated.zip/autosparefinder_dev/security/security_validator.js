/**
 * Security validation and testing utilities for AutoSpareFinder system
 * 
 * This module provides functions for validating security implementations,
 * testing for vulnerabilities, and ensuring system integrity.
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

/**
 * Validate security configuration
 * @param {Object} config - Security configuration to validate
 * @returns {Object} - Validation results with issues and recommendations
 */
function validateSecurityConfig(config) {
    const issues = [];
    const recommendations = [];
    
    // Check HTTPS configuration
    if (!config.https || !config.https.enabled) {
        issues.push('HTTPS is not enabled');
        recommendations.push('Enable HTTPS for all production environments');
    } else {
        if (!config.https.hsts) {
            recommendations.push('Enable HTTP Strict Transport Security (HSTS)');
        }
    }
    
    // Check authentication settings
    if (!config.auth) {
        issues.push('Authentication configuration is missing');
    } else {
        if (!config.auth.passwordPolicy || !config.auth.passwordPolicy.minLength || config.auth.passwordPolicy.minLength < 10) {
            issues.push('Password policy is weak or missing');
            recommendations.push('Enforce strong password policy with minimum length of 10 characters');
        }
        
        if (!config.auth.mfa || !config.auth.mfa.enabled) {
            recommendations.push('Enable Multi-Factor Authentication for sensitive operations');
        }
        
        if (!config.auth.sessionTimeout || config.auth.sessionTimeout > 24 * 60 * 60) {
            recommendations.push('Set session timeout to a maximum of 24 hours');
        }
    }
    
    // Check rate limiting
    if (!config.rateLimit || !config.rateLimit.enabled) {
        issues.push('Rate limiting is not configured');
        recommendations.push('Enable rate limiting to prevent brute force attacks');
    }
    
    // Check CSP
    if (!config.csp || !config.csp.enabled) {
        issues.push('Content Security Policy is not configured');
        recommendations.push('Enable Content Security Policy to prevent XSS attacks');
    }
    
    // Check data protection
    if (!config.dataProtection || !config.dataProtection.encryption !== 'aes-256-gcm') {
        issues.push('Data encryption is not properly configured');
        recommendations.push('Use AES-256-GCM for encrypting sensitive data');
    }
    
    return {
        valid: issues.length === 0,
        issues,
        recommendations
    };
}

/**
 * Test for common security vulnerabilities
 * @param {string} baseUrl - Base URL of the application
 * @param {Object} options - Test options
 * @returns {Promise<Object>} - Test results
 */
async function testSecurityVulnerabilities(baseUrl, options = {}) {
    const results = {
        xss: { tested: false, vulnerable: false, details: [] },
        sqli: { tested: false, vulnerable: false, details: [] },
        csrf: { tested: false, vulnerable: false, details: [] },
        openRedirect: { tested: false, vulnerable: false, details: [] },
        headers: { tested: false, vulnerable: false, details: [] }
    };
    
    // Test security headers
    if (options.testHeaders !== false) {
        try {
            results.headers.tested = true;
            
            const { stdout } = await execPromise(`curl -s -I ${baseUrl}`);
            const headers = stdout.split('\n').reduce((acc, line) => {
                const parts = line.split(':');
                if (parts.length >= 2) {
                    const key = parts[0].trim().toLowerCase();
                    const value = parts.slice(1).join(':').trim();
                    acc[key] = value;
                }
                return acc;
            }, {});
            
            // Check for important security headers
            const requiredHeaders = [
                { name: 'x-content-type-options', value: 'nosniff' },
                { name: 'x-frame-options', values: ['deny', 'sameorigin'] },
                { name: 'x-xss-protection', value: '1; mode=block' },
                { name: 'content-security-policy', required: false },
                { name: 'strict-transport-security', required: false }
            ];
            
            for (const header of requiredHeaders) {
                const headerValue = headers[header.name];
                
                if (!headerValue && header.required !== false) {
                    results.headers.vulnerable = true;
                    results.headers.details.push(`Missing required header: ${header.name}`);
                } else if (headerValue) {
                    if (header.value && headerValue !== header.value) {
                        results.headers.vulnerable = true;
                        results.headers.details.push(`Invalid value for ${header.name}: ${headerValue}`);
                    } else if (header.values && !header.values.includes(headerValue)) {
                        results.headers.vulnerable = true;
                        results.headers.details.push(`Invalid value for ${header.name}: ${headerValue}`);
                    }
                }
            }
            
            if (!results.headers.vulnerable) {
                results.headers.details.push('All required security headers are properly configured');
            }
        } catch (error) {
            results.headers.error = error.message;
        }
    }
    
    // Note: The following tests are placeholders and would need to be implemented
    // with actual HTTP requests and response analysis in a real application
    
    // Test for XSS vulnerabilities
    if (options.testXss !== false) {
        results.xss.tested = true;
        results.xss.details.push('XSS testing requires manual implementation');
    }
    
    // Test for SQL injection vulnerabilities
    if (options.testSqli !== false) {
        results.sqli.tested = true;
        results.sqli.details.push('SQL injection testing requires manual implementation');
    }
    
    // Test for CSRF vulnerabilities
    if (options.testCsrf !== false) {
        results.csrf.tested = true;
        results.csrf.details.push('CSRF testing requires manual implementation');
    }
    
    // Test for open redirect vulnerabilities
    if (options.testOpenRedirect !== false) {
        results.openRedirect.tested = true;
        results.openRedirect.details.push('Open redirect testing requires manual implementation');
    }
    
    return results;
}

/**
 * Validate file integrity using checksums
 * @param {string} filePath - Path to the file
 * @param {string} expectedHash - Expected hash value
 * @param {string} algorithm - Hash algorithm to use
 * @returns {Promise<boolean>} - True if file integrity is valid
 */
async function validateFileIntegrity(filePath, expectedHash, algorithm = 'sha256') {
    return new Promise((resolve, reject) => {
        try {
            const hash = crypto.createHash(algorithm);
            const stream = fs.createReadStream(filePath);
            
            stream.on('data', (data) => {
                hash.update(data);
            });
            
            stream.on('end', () => {
                const fileHash = hash.digest('hex');
                resolve(fileHash === expectedHash);
            });
            
            stream.on('error', reject);
        } catch (error) {
            reject(error);
        }
    });
}

/**
 * Generate integrity manifest for a directory
 * @param {string} directory - Directory path
 * @param {string} algorithm - Hash algorithm to use
 * @returns {Promise<Object>} - Integrity manifest with file hashes
 */
async function generateIntegrityManifest(directory, algorithm = 'sha256') {
    const manifest = {
        algorithm,
        generatedAt: new Date().toISOString(),
        files: {}
    };
    
    async function processDirectory(dir) {
        const entries = fs.readdirSync(dir, { withFileTypes: true });
        
        for (const entry of entries) {
            const fullPath = path.join(dir, entry.name);
            
            if (entry.isDirectory()) {
                await processDirectory(fullPath);
            } else if (entry.isFile()) {
                const relativePath = path.relative(directory, fullPath);
                const hash = await hashFile(fullPath, algorithm);
                manifest.files[relativePath] = hash;
            }
        }
    }
    
    await processDirectory(directory);
    return manifest;
}

/**
 * Verify integrity of files against a manifest
 * @param {string} directory - Directory path
 * @param {Object} manifest - Integrity manifest
 * @returns {Promise<Object>} - Verification results
 */
async function verifyIntegrityManifest(directory, manifest) {
    const results = {
        algorithm: manifest.algorithm,
        verifiedAt: new Date().toISOString(),
        valid: true,
        modifiedFiles: [],
        missingFiles: [],
        newFiles: []
    };
    
    // Check for modified and missing files
    for (const [relativePath, expectedHash] of Object.entries(manifest.files)) {
        const fullPath = path.join(directory, relativePath);
        
        if (!fs.existsSync(fullPath)) {
            results.valid = false;
            results.missingFiles.push(relativePath);
            continue;
        }
        
        const actualHash = await hashFile(fullPath, manifest.algorithm);
        if (actualHash !== expectedHash) {
            results.valid = false;
            results.modifiedFiles.push(relativePath);
        }
    }
    
    // Check for new files
    async function findNewFiles(dir) {
        const entries = fs.readdirSync(dir, { withFileTypes: true });
        
        for (const entry of entries) {
            const fullPath = path.join(dir, entry.name);
            
            if (entry.isDirectory()) {
                await findNewFiles(fullPath);
            } else if (entry.isFile()) {
                const relativePath = path.relative(directory, fullPath);
                if (!(relativePath in manifest.files)) {
                    results.newFiles.push(relativePath);
                }
            }
        }
    }
    
    await findNewFiles(directory);
    if (results.newFiles.length > 0) {
        results.valid = false;
    }
    
    return results;
}

/**
 * Hash a file using the specified algorithm
 * @param {string} filePath - Path to the file
 * @param {string} algorithm - Hash algorithm to use
 * @returns {Promise<string>} - File hash
 */
async function hashFile(filePath, algorithm = 'sha256') {
    return new Promise((resolve, reject) => {
        try {
            const hash = crypto.createHash(algorithm);
            const stream = fs.createReadStream(filePath);
            
            stream.on('data', (data) => {
                hash.update(data);
            });
            
            stream.on('end', () => {
                resolve(hash.digest('hex'));
            });
            
            stream.on('error', reject);
        } catch (error) {
            reject(error);
        }
    });
}

/**
 * Validate accessibility compliance
 * @param {string} htmlContent - HTML content to validate
 * @returns {Promise<Object>} - Validation results
 */
async function validateAccessibility(htmlContent) {
    // This is a placeholder for actual accessibility validation
    // In a real implementation, this would use a library like axe-core
    
    const issues = [];
    
    // Check for basic accessibility issues
    if (!htmlContent.includes('lang=')) {
        issues.push('Missing lang attribute on html element');
    }
    
    if (!htmlContent.includes('aria-')) {
        issues.push('No ARIA attributes found, may indicate accessibility issues');
    }
    
    if (!htmlContent.includes('alt=')) {
        issues.push('No alt attributes found, images may be inaccessible');
    }
    
    return {
        valid: issues.length === 0,
        issues,
        standard: 'WCAG 2.1 AA (simulated)'
    };
}

/**
 * Validate security of dependencies
 * @param {string} packageJsonPath - Path to package.json file
 * @returns {Promise<Object>} - Validation results
 */
async function validateDependencies(packageJsonPath) {
    try {
        // This is a placeholder for actual dependency validation
        // In a real implementation, this would use a tool like npm audit
        
        const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
        const dependencies = { ...packageJson.dependencies, ...packageJson.devDependencies };
        
        return {
            valid: true,
            dependenciesChecked: Object.keys(dependencies).length,
            vulnerabilities: [],
            message: 'Dependency validation requires npm audit or similar tool'
        };
    } catch (error) {
        return {
            valid: false,
            error: error.message
        };
    }
}

/**
 * Test password strength
 * @param {string} password - Password to test
 * @returns {Object} - Password strength assessment
 */
function testPasswordStrength(password) {
    const result = {
        score: 0,
        feedback: [],
        isStrong: false
    };
    
    // Check length
    if (password.length < 8) {
        result.feedback.push('Password is too short (minimum 8 characters)');
    } else if (password.length >= 12) {
        result.score += 2;
    } else {
        result.score += 1;
    }
    
    // Check for uppercase letters
    if (/[A-Z]/.test(password)) {
        result.score += 1;
    } else {
        result.feedback.push('Password should include uppercase letters');
    }
    
    // Check for lowercase letters
    if (/[a-z]/.test(password)) {
        result.score += 1;
    } else {
        result.feedback.push('Password should include lowercase letters');
    }
    
    // Check for numbers
    if (/\d/.test(password)) {
        result.score += 1;
    } else {
        result.feedback.push('Password should include numbers');
    }
    
    // Check for special characters
    if (/[^A-Za-z0-9]/.test(password)) {
        result.score += 1;
    } else {
        result.feedback.push('Password should include special characters');
    }
    
    // Check for repeating characters
    if (/(.)\1{2,}/.test(password)) {
        result.score -= 1;
        result.feedback.push('Password contains repeating characters');
    }
    
    // Check for sequential characters
    const sequences = ['abcdefghijklmnopqrstuvwxyz', '01234567890', 'qwertyuiop', 'asdfghjkl', 'zxcvbnm'];
    for (const seq of sequences) {
        for (let i = 0; i < seq.length - 2; i++) {
            const fragment = seq.substring(i, i + 3);
            if (password.toLowerCase().includes(fragment)) {
                result.score -= 1;
                result.feedback.push('Password contains sequential characters');
                break;
            }
        }
    }
    
    // Check for common passwords
    const commonPasswords = ['password', '123456', 'qwerty', 'admin', 'welcome', 'letmein'];
    if (commonPasswords.includes(password.toLowerCase())) {
        result.score = 0;
        result.feedback.push('Password is commonly used and easily guessable');
    }
    
    // Determine strength
    if (result.score >= 4) {
        result.strength = 'strong';
        result.isStrong = true;
    } else if (result.score >= 3) {
        result.strength = 'moderate';
    } else {
        result.strength = 'weak';
    }
    
    return result;
}

module.exports = {
    validateSecurityConfig,
    testSecurityVulnerabilities,
    validateFileIntegrity,
    generateIntegrityManifest,
    verifyIntegrityManifest,
    hashFile,
    validateAccessibility,
    validateDependencies,
    testPasswordStrength
};

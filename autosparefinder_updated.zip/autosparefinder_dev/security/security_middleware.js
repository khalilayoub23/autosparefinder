/**
 * Security middleware for AutoSpareFinder system
 * 
 * This module provides security middleware functions for protecting the AutoSpareFinder
 * web application against common security threats.
 */

const crypto = require('crypto');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const xss = require('xss-clean');
const hpp = require('hpp');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const mongoSanitize = require('express-mongo-sanitize');
const { body, validationResult } = require('express-validator');

/**
 * Configure and return all security middleware for Express application
 * @param {Object} app - Express application instance
 * @param {Object} config - Configuration options
 * @returns {Object} app - Express application with security middleware
 */
function setupSecurityMiddleware(app, config = {}) {
    // Set security HTTP headers using Helmet
    app.use(helmet());
    
    // Enable Cross-Origin Resource Sharing (CORS)
    const corsOptions = config.cors || {
        origin: config.allowedOrigins || '*',
        methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
        allowedHeaders: ['Content-Type', 'Authorization'],
        credentials: true,
        maxAge: 86400 // 24 hours
    };
    app.use(cors(corsOptions));
    
    // Parse cookies
    app.use(cookieParser(config.cookieSecret || process.env.COOKIE_SECRET));
    
    // Rate limiting to prevent brute force and DoS attacks
    const limiter = rateLimit({
        windowMs: config.rateLimitWindowMs || 15 * 60 * 1000, // 15 minutes by default
        max: config.rateLimitMax || 100, // limit each IP to 100 requests per windowMs
        message: 'Too many requests from this IP, please try again later',
        standardHeaders: true,
        legacyHeaders: false
    });
    app.use('/api/', limiter); // Apply rate limiting to API routes
    
    // Data sanitization against NoSQL query injection
    app.use(mongoSanitize());
    
    // Data sanitization against XSS
    app.use(xss());
    
    // Prevent parameter pollution
    app.use(hpp({
        whitelist: config.hppWhitelist || [] // parameters that are allowed to be duplicated
    }));
    
    // Content Security Policy
    if (!config.disableCSP) {
        app.use(helmet.contentSecurityPolicy({
            directives: {
                defaultSrc: ["'self'"],
                scriptSrc: ["'self'", "https://cdn.jsdelivr.net"],
                styleSrc: ["'self'", "https://cdn.jsdelivr.net", "'unsafe-inline'"],
                imgSrc: ["'self'", "data:", "https://cdn.jsdelivr.net"],
                connectSrc: ["'self'"],
                fontSrc: ["'self'", "https://cdn.jsdelivr.net"],
                objectSrc: ["'none'"],
                mediaSrc: ["'self'"],
                frameSrc: ["'none'"]
            }
        }));
    }
    
    // Set secure cookies
    app.use((req, res, next) => {
        res.cookie = (name, value, options = {}) => {
            const secureOptions = {
                httpOnly: true,
                secure: process.env.NODE_ENV === 'production',
                sameSite: 'strict',
                ...options
            };
            return res.cookie(name, value, secureOptions);
        };
        next();
    });
    
    // Add security headers
    app.use((req, res, next) => {
        // Prevent browsers from detecting the MIME type
        res.setHeader('X-Content-Type-Options', 'nosniff');
        // Prevent clickjacking
        res.setHeader('X-Frame-Options', 'DENY');
        // Enable the XSS filter in browsers
        res.setHeader('X-XSS-Protection', '1; mode=block');
        // Prevent loading from other domains
        res.setHeader('Referrer-Policy', 'same-origin');
        next();
    });
    
    return app;
}

/**
 * Generate a secure random token
 * @param {number} length - Length of the token
 * @returns {string} - Secure random token
 */
function generateSecureToken(length = 32) {
    return crypto.randomBytes(length).toString('hex');
}

/**
 * Hash a password using bcrypt
 * @param {string} password - Plain text password
 * @returns {Promise<string>} - Hashed password
 */
async function hashPassword(password) {
    const bcrypt = require('bcrypt');
    const saltRounds = 12;
    return await bcrypt.hash(password, saltRounds);
}

/**
 * Verify a password against a hash
 * @param {string} password - Plain text password
 * @param {string} hash - Hashed password
 * @returns {Promise<boolean>} - True if password matches hash
 */
async function verifyPassword(password, hash) {
    const bcrypt = require('bcrypt');
    return await bcrypt.compare(password, hash);
}

/**
 * Create validation rules for user input
 * @returns {Object} - Validation rules for different types of input
 */
function validationRules() {
    return {
        // User registration validation
        registerUser: [
            body('username')
                .trim()
                .isLength({ min: 3, max: 30 })
                .withMessage('Username must be between 3 and 30 characters')
                .matches(/^[a-zA-Z0-9_]+$/)
                .withMessage('Username can only contain letters, numbers and underscores'),
            body('email')
                .trim()
                .isEmail()
                .withMessage('Please provide a valid email address')
                .normalizeEmail(),
            body('password')
                .isLength({ min: 10 })
                .withMessage('Password must be at least 10 characters long')
                .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
                .withMessage('Password must contain at least one uppercase letter, one lowercase letter, one number and one special character')
        ],
        
        // Login validation
        loginUser: [
            body('email')
                .trim()
                .isEmail()
                .withMessage('Please provide a valid email address')
                .normalizeEmail(),
            body('password')
                .notEmpty()
                .withMessage('Password is required')
        ],
        
        // Part search validation
        searchParts: [
            body('query')
                .trim()
                .escape()
                .isLength({ min: 2 })
                .withMessage('Search query must be at least 2 characters long')
        ],
        
        // Order validation
        createOrder: [
            body('parts')
                .isArray()
                .withMessage('Parts must be an array')
                .notEmpty()
                .withMessage('At least one part is required'),
            body('parts.*.id')
                .isString()
                .withMessage('Part ID must be a string')
                .notEmpty()
                .withMessage('Part ID is required'),
            body('parts.*.quantity')
                .isInt({ min: 1 })
                .withMessage('Quantity must be a positive integer'),
            body('shippingAddress')
                .notEmpty()
                .withMessage('Shipping address is required'),
            body('paymentMethod')
                .notEmpty()
                .withMessage('Payment method is required')
        ]
    };
}

/**
 * Validate request based on defined rules
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next middleware function
 * @returns {void}
 */
function validate(req, res, next) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ 
            status: 'error',
            message: 'Validation failed',
            errors: errors.array() 
        });
    }
    next();
}

/**
 * Create a JWT token
 * @param {Object} payload - Data to encode in the token
 * @param {string} secret - Secret key for signing
 * @param {Object} options - JWT options
 * @returns {string} - JWT token
 */
function createJWT(payload, secret = process.env.JWT_SECRET, options = {}) {
    const jwt = require('jsonwebtoken');
    const defaultOptions = {
        expiresIn: '1h'
    };
    return jwt.sign(payload, secret, { ...defaultOptions, ...options });
}

/**
 * Verify a JWT token
 * @param {string} token - JWT token to verify
 * @param {string} secret - Secret key for verification
 * @returns {Object|null} - Decoded token payload or null if invalid
 */
function verifyJWT(token, secret = process.env.JWT_SECRET) {
    const jwt = require('jsonwebtoken');
    try {
        return jwt.verify(token, secret);
    } catch (error) {
        return null;
    }
}

/**
 * Middleware to authenticate requests using JWT
 * @param {Object} options - Authentication options
 * @returns {Function} - Express middleware function
 */
function authenticateJWT(options = {}) {
    return (req, res, next) => {
        // Get token from authorization header or cookie
        const authHeader = req.headers.authorization;
        const token = authHeader && authHeader.split(' ')[1] || req.cookies.token;
        
        if (!token) {
            return res.status(401).json({
                status: 'error',
                message: 'Authentication required'
            });
        }
        
        const decoded = verifyJWT(token);
        if (!decoded) {
            return res.status(401).json({
                status: 'error',
                message: 'Invalid or expired token'
            });
        }
        
        // Attach user info to request
        req.user = decoded;
        next();
    };
}

/**
 * Middleware to check user roles and permissions
 * @param {string|string[]} roles - Required role(s) to access the resource
 * @returns {Function} - Express middleware function
 */
function authorizeRoles(roles) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({
                status: 'error',
                message: 'Authentication required'
            });
        }
        
        const userRoles = req.user.roles || [];
        const requiredRoles = Array.isArray(roles) ? roles : [roles];
        
        const hasPermission = requiredRoles.some(role => userRoles.includes(role));
        
        if (!hasPermission) {
            return res.status(403).json({
                status: 'error',
                message: 'You do not have permission to access this resource'
            });
        }
        
        next();
    };
}

/**
 * Middleware to prevent CSRF attacks
 * @returns {Function} - Express middleware function
 */
function csrfProtection() {
    const csrf = require('csurf');
    return csrf({ cookie: true });
}

/**
 * Generate a nonce for CSP
 * @returns {string} - Random nonce
 */
function generateNonce() {
    return crypto.randomBytes(16).toString('base64');
}

/**
 * Sanitize user input to prevent XSS
 * @param {string} input - User input to sanitize
 * @returns {string} - Sanitized input
 */
function sanitizeInput(input) {
    const xss = require('xss');
    return xss(input);
}

module.exports = {
    setupSecurityMiddleware,
    generateSecureToken,
    hashPassword,
    verifyPassword,
    validationRules,
    validate,
    createJWT,
    verifyJWT,
    authenticateJWT,
    authorizeRoles,
    csrfProtection,
    generateNonce,
    sanitizeInput
};

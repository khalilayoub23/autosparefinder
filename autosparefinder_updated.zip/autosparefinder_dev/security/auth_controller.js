/**
 * Authentication controller for AutoSpareFinder system
 * 
 * This module provides authentication-related functionality including
 * user registration, login, password reset, and session management.
 */

const { 
    hashPassword, 
    verifyPassword, 
    createJWT, 
    generateSecureToken,
    sanitizeInput
} = require('./security_middleware');

/**
 * User registration handler
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
async function registerUser(req, res) {
    try {
        const { username, email, password, fullName } = req.body;
        
        // Sanitize inputs
        const sanitizedUsername = sanitizeInput(username);
        const sanitizedEmail = sanitizeInput(email);
        const sanitizedFullName = sanitizeInput(fullName);
        
        // Check if user already exists
        const existingUser = await req.db.collection('users').findOne({ 
            $or: [{ email: sanitizedEmail }, { username: sanitizedUsername }] 
        });
        
        if (existingUser) {
            return res.status(400).json({
                status: 'error',
                message: 'User with this email or username already exists'
            });
        }
        
        // Hash password
        const hashedPassword = await hashPassword(password);
        
        // Create verification token
        const verificationToken = generateSecureToken();
        const verificationExpires = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
        
        // Create new user
        const newUser = {
            username: sanitizedUsername,
            email: sanitizedEmail,
            password: hashedPassword,
            fullName: sanitizedFullName,
            roles: ['customer'],
            isVerified: false,
            verificationToken,
            verificationExpires,
            createdAt: new Date(),
            updatedAt: new Date(),
            lastLogin: null
        };
        
        // Save user to database
        const result = await req.db.collection('users').insertOne(newUser);
        
        // Send verification email
        await sendVerificationEmail(sanitizedEmail, verificationToken);
        
        // Return success response (without sensitive data)
        return res.status(201).json({
            status: 'success',
            message: 'User registered successfully. Please check your email to verify your account.',
            data: {
                id: result.insertedId,
                username: sanitizedUsername,
                email: sanitizedEmail,
                fullName: sanitizedFullName,
                roles: ['customer'],
                isVerified: false
            }
        });
    } catch (error) {
        console.error('Registration error:', error);
        return res.status(500).json({
            status: 'error',
            message: 'An error occurred during registration'
        });
    }
}

/**
 * User login handler
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
async function loginUser(req, res) {
    try {
        const { email, password } = req.body;
        
        // Sanitize inputs
        const sanitizedEmail = sanitizeInput(email);
        
        // Find user by email
        const user = await req.db.collection('users').findOne({ email: sanitizedEmail });
        
        // Check if user exists
        if (!user) {
            return res.status(401).json({
                status: 'error',
                message: 'Invalid email or password'
            });
        }
        
        // Check if user is verified
        if (!user.isVerified) {
            return res.status(401).json({
                status: 'error',
                message: 'Please verify your email before logging in'
            });
        }
        
        // Verify password
        const isPasswordValid = await verifyPassword(password, user.password);
        
        if (!isPasswordValid) {
            // Log failed login attempt
            await logSecurityEvent({
                type: 'failed_login',
                userId: user._id,
                email: user.email,
                ipAddress: req.ip,
                userAgent: req.headers['user-agent'],
                timestamp: new Date()
            }, req);
            
            return res.status(401).json({
                status: 'error',
                message: 'Invalid email or password'
            });
        }
        
        // Update last login timestamp
        await req.db.collection('users').updateOne(
            { _id: user._id },
            { $set: { lastLogin: new Date(), updatedAt: new Date() } }
        );
        
        // Generate JWT token
        const token = createJWT({
            id: user._id,
            username: user.username,
            email: user.email,
            roles: user.roles
        });
        
        // Log successful login
        await logSecurityEvent({
            type: 'successful_login',
            userId: user._id,
            email: user.email,
            ipAddress: req.ip,
            userAgent: req.headers['user-agent'],
            timestamp: new Date()
        }, req);
        
        // Set secure cookie with token
        res.cookie('token', token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 24 * 60 * 60 * 1000 // 24 hours
        });
        
        // Return success response with token
        return res.status(200).json({
            status: 'success',
            message: 'Login successful',
            data: {
                token,
                user: {
                    id: user._id,
                    username: user.username,
                    email: user.email,
                    fullName: user.fullName,
                    roles: user.roles
                }
            }
        });
    } catch (error) {
        console.error('Login error:', error);
        return res.status(500).json({
            status: 'error',
            message: 'An error occurred during login'
        });
    }
}

/**
 * Email verification handler
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
async function verifyEmail(req, res) {
    try {
        const { token } = req.params;
        
        // Find user by verification token
        const user = await req.db.collection('users').findOne({
            verificationToken: token,
            verificationExpires: { $gt: new Date() }
        });
        
        if (!user) {
            return res.status(400).json({
                status: 'error',
                message: 'Invalid or expired verification token'
            });
        }
        
        // Update user verification status
        await req.db.collection('users').updateOne(
            { _id: user._id },
            { 
                $set: { 
                    isVerified: true,
                    updatedAt: new Date()
                },
                $unset: { 
                    verificationToken: "",
                    verificationExpires: ""
                }
            }
        );
        
        // Log verification event
        await logSecurityEvent({
            type: 'email_verified',
            userId: user._id,
            email: user.email,
            timestamp: new Date()
        }, req);
        
        return res.status(200).json({
            status: 'success',
            message: 'Email verified successfully. You can now log in.'
        });
    } catch (error) {
        console.error('Email verification error:', error);
        return res.status(500).json({
            status: 'error',
            message: 'An error occurred during email verification'
        });
    }
}

/**
 * Forgot password handler
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
async function forgotPassword(req, res) {
    try {
        const { email } = req.body;
        
        // Sanitize input
        const sanitizedEmail = sanitizeInput(email);
        
        // Find user by email
        const user = await req.db.collection('users').findOne({ email: sanitizedEmail });
        
        // Always return success even if user not found (security best practice)
        if (!user) {
            return res.status(200).json({
                status: 'success',
                message: 'If your email is registered, you will receive a password reset link'
            });
        }
        
        // Generate reset token
        const resetToken = generateSecureToken();
        const resetExpires = new Date(Date.now() + 1 * 60 * 60 * 1000); // 1 hour
        
        // Hash token for storage
        const hashedToken = require('crypto')
            .createHash('sha256')
            .update(resetToken)
            .digest('hex');
        
        // Update user with reset token
        await req.db.collection('users').updateOne(
            { _id: user._id },
            { 
                $set: { 
                    passwordResetToken: hashedToken,
                    passwordResetExpires: resetExpires,
                    updatedAt: new Date()
                }
            }
        );
        
        // Send password reset email
        await sendPasswordResetEmail(user.email, resetToken);
        
        // Log password reset request
        await logSecurityEvent({
            type: 'password_reset_requested',
            userId: user._id,
            email: user.email,
            ipAddress: req.ip,
            timestamp: new Date()
        }, req);
        
        return res.status(200).json({
            status: 'success',
            message: 'If your email is registered, you will receive a password reset link'
        });
    } catch (error) {
        console.error('Forgot password error:', error);
        return res.status(500).json({
            status: 'error',
            message: 'An error occurred while processing your request'
        });
    }
}

/**
 * Reset password handler
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
async function resetPassword(req, res) {
    try {
        const { token } = req.params;
        const { password } = req.body;
        
        // Hash token for comparison
        const hashedToken = require('crypto')
            .createHash('sha256')
            .update(token)
            .digest('hex');
        
        // Find user by reset token
        const user = await req.db.collection('users').findOne({
            passwordResetToken: hashedToken,
            passwordResetExpires: { $gt: new Date() }
        });
        
        if (!user) {
            return res.status(400).json({
                status: 'error',
                message: 'Invalid or expired password reset token'
            });
        }
        
        // Hash new password
        const hashedPassword = await hashPassword(password);
        
        // Update user password
        await req.db.collection('users').updateOne(
            { _id: user._id },
            { 
                $set: { 
                    password: hashedPassword,
                    updatedAt: new Date()
                },
                $unset: { 
                    passwordResetToken: "",
                    passwordResetExpires: ""
                }
            }
        );
        
        // Log password reset completion
        await logSecurityEvent({
            type: 'password_reset_completed',
            userId: user._id,
            email: user.email,
            ipAddress: req.ip,
            timestamp: new Date()
        }, req);
        
        return res.status(200).json({
            status: 'success',
            message: 'Password reset successful. You can now log in with your new password.'
        });
    } catch (error) {
        console.error('Reset password error:', error);
        return res.status(500).json({
            status: 'error',
            message: 'An error occurred while resetting your password'
        });
    }
}

/**
 * Logout handler
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {void}
 */
function logoutUser(req, res) {
    try {
        // Clear token cookie
        res.clearCookie('token');
        
        // Log logout event if user is authenticated
        if (req.user) {
            logSecurityEvent({
                type: 'logout',
                userId: req.user.id,
                email: req.user.email,
                ipAddress: req.ip,
                timestamp: new Date()
            }, req).catch(console.error);
        }
        
        return res.status(200).json({
            status: 'success',
            message: 'Logout successful'
        });
    } catch (error) {
        console.error('Logout error:', error);
        return res.status(500).json({
            status: 'error',
            message: 'An error occurred during logout'
        });
    }
}

/**
 * Change password handler
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
async function changePassword(req, res) {
    try {
        const { currentPassword, newPassword } = req.body;
        const userId = req.user.id;
        
        // Find user by ID
        const user = await req.db.collection('users').findOne({ _id: userId });
        
        if (!user) {
            return res.status(404).json({
                status: 'error',
                message: 'User not found'
            });
        }
        
        // Verify current password
        const isPasswordValid = await verifyPassword(currentPassword, user.password);
        
        if (!isPasswordValid) {
            return res.status(401).json({
                status: 'error',
                message: 'Current password is incorrect'
            });
        }
        
        // Hash new password
        const hashedPassword = await hashPassword(newPassword);
        
        // Update user password
        await req.db.collection('users').updateOne(
            { _id: user._id },
            { 
                $set: { 
                    password: hashedPassword,
                    updatedAt: new Date()
                }
            }
        );
        
        // Log password change
        await logSecurityEvent({
            type: 'password_changed',
            userId: user._id,
            email: user.email,
            ipAddress: req.ip,
            timestamp: new Date()
        }, req);
        
        return res.status(200).json({
            status: 'success',
            message: 'Password changed successfully'
        });
    } catch (error) {
        console.error('Change password error:', error);
        return res.status(500).json({
            status: 'error',
            message: 'An error occurred while changing your password'
        });
    }
}

/**
 * Get current user profile
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
async function getCurrentUser(req, res) {
    try {
        const userId = req.user.id;
        
        // Find user by ID
        const user = await req.db.collection('users').findOne({ _id: userId });
        
        if (!user) {
            return res.status(404).json({
                status: 'error',
                message: 'User not found'
            });
        }
        
        // Return user data without sensitive information
        return res.status(200).json({
            status: 'success',
            data: {
                id: user._id,
                username: user.username,
                email: user.email,
                fullName: user.fullName,
                roles: user.roles,
                createdAt: user.createdAt,
                lastLogin: user.lastLogin
            }
        });
    } catch (error) {
        console.error('Get current user error:', error);
        return res.status(500).json({
            status: 'error',
            message: 'An error occurred while fetching user profile'
        });
    }
}

/**
 * Update user profile
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @returns {Promise<void>}
 */
async function updateUserProfile(req, res) {
    try {
        const userId = req.user.id;
        const { fullName, phoneNumber, address } = req.body;
        
        // Sanitize inputs
        const sanitizedFullName = sanitizeInput(fullName);
        const sanitizedPhoneNumber = sanitizeInput(phoneNumber);
        const sanitizedAddress = sanitizeInput(address);
        
        // Find user by ID
        const user = await req.db.collection('users').findOne({ _id: userId });
        
        if (!user) {
            return res.status(404).json({
                status: 'error',
                message: 'User not found'
            });
        }
        
        // Update user profile
        const updateData = {
            updatedAt: new Date()
        };
        
        if (sanitizedFullName) updateData.fullName = sanitizedFullName;
        if (sanitizedPhoneNumber) updateData.phoneNumber = sanitizedPhoneNumber;
        if (sanitizedAddress) updateData.address = sanitizedAddress;
        
        await req.db.collection('users').updateOne(
            { _id: user._id },
            { $set: updateData }
        );
        
        // Get updated user
        const updatedUser = await req.db.collection('users').findOne({ _id: userId });
        
        // Return updated user data
        return res.status(200).json({
            status: 'success',
            message: 'Profile updated successfully',
            data: {
                id: updatedUser._id,
                username: updatedUser.username,
                email: updatedUser.email,
                fullName: updatedUser.fullName,
                phoneNumber: updatedUser.phoneNumber,
                address: updatedUser.address,
                roles: updatedUser.roles
            }
        });
    } catch (error) {
        console.error('Update profile error:', error);
        return res.status(500).json({
            status: 'error',
            message: 'An error occurred while updating your profile'
        });
    }
}

/**
 * Send verification email
 * @param {string} email - User email
 * @param {string} token - Verification token
 * @returns {Promise<void>}
 */
async function sendVerificationEmail(email, token) {
    // Implementation depends on email service being used
    // This is a placeholder for the actual implementation
    console.log(`Sending verification email to ${email} with token ${token}`);
    
    // Example implementation with nodemailer
    // const transporter = nodemailer.createTransport({...});
    // await transporter.sendMail({
    //     from: 'noreply@autosparefinder.com',
    //     to: email,
    //     subject: 'Verify your AutoSpareFinder account',
    //     html: `<p>Please click the link below to verify your account:</p>
    //            <p><a href="${process.env.FRONTEND_URL}/verify-email/${token}">Verify Email</a></p>`
    // });
}

/**
 * Send password reset email
 * @param {string} email - User email
 * @param {string} token - Reset token
 * @returns {Promise<void>}
 */
async function sendPasswordResetEmail(email, token) {
    // Implementation depends on email service being used
    // This is a placeholder for the actual implementation
    console.log(`Sending password reset email to ${email} with token ${token}`);
    
    // Example implementation with nodemailer
    // const transporter = nodemailer.createTransport({...});
    // await transporter.sendMail({
    //     from: 'noreply@autosparefinder.com',
    //     to: email,
    //     subject: 'Reset your AutoSpareFinder password',
    //     html: `<p>Please click the link below to reset your password:</p>
    //            <p><a href="${process.env.FRONTEND_URL}/reset-password/${token}">Reset Password</a></p>
    //            <p>This link will expire in 1 hour.</p>`
    // });
}

/**
 * Log security event
 * @param {Object} event - Security event details
 * @param {Object} req - Express request object
 * @returns {Promise<void>}
 */
async function logSecurityEvent(event, req) {
    try {
        await req.db.collection('security_logs').insertOne(event);
    } catch (error) {
        console.error('Error logging security event:', error);
    }
}

module.exports = {
    registerUser,
    loginUser,
    verifyEmail,
    forgotPassword,
    resetPassword,
    logoutUser,
    changePassword,
    getCurrentUser,
    updateUserProfile
};

import streamlit as st
from agents.sales_agent import SalesAgent
from PIL import Image
import os

def main():
    # Load and display logo
    logo_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static", "images", "logo.jpg")
    if os.path.exists(logo_path):
        logo = Image.open(logo_path)
        st.image(logo, width=200)
    
    st.title("AutoSpare - Sales Assistant")
    st.markdown("### Find the right parts for your vehicle")

    # Initialize Sales Agent
    sales_agent = SalesAgent("AutoSpare Assistant")

    # Create the chat interface with improved styling
    st.markdown("---")
    st.markdown("#### Chat with our AI Assistant")
    
    # Initialize chat history
    if "messages" not in st.session_state:
        st.session_state.messages = []

    # Display chat history
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    # Accept user input
    user_input = st.chat_input("How can I help you find parts for your vehicle?")

    if user_input:
        # Add user message to chat history
        st.session_state.messages.append({"role": "user", "content": user_input})
        
        # Display user message
        with st.chat_message("user"):
            st.markdown(user_input)
        
        # Get response from agent
        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                response = sales_agent.respond(user_input)
                st.markdown(response)
        
        # Add assistant response to chat history
        st.session_state.messages.append({"role": "assistant", "content": response})

if __name__ == "__main__":
    main()

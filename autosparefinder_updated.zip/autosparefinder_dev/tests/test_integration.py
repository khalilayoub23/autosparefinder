import unittest
import os
import sys
import json
from datetime import datetime

# Add project root to path
sys.path.append('/home/ubuntu/autosparefinder_dev')

# Import system components
from agents.agent_factory import AgentFactory
from agents.quality_control_agent import QualityControlAgent
from agents.monitoring_agent import MonitoringAgent
from agents.sales_agent import SalesAgent
from agents.order_agent import OrderAgent
from agents.technical_support_agent import TechnicalSupportAgent
from database.parts_catalog_db import PartsCatalogDatabase
from database.parts_catalog_importer import PartsCatalogImporter
from database.catalog_api_integration import CatalogAPIIntegration
from database.order_management_system import OrderManagementSystem
from api.crm_interface import CRMInterface
from api.hybrid_vehicle_data_manager import HybridVehicleDataManager
from system_integration_manager import SystemIntegrationManager

class TestAgentIntegration(unittest.TestCase):
    """Test integration between different agent types"""
    
    def setUp(self):
        """Set up test environment"""
        self.agent_factory = AgentFactory()
        
        # Create test agents
        self.quality_agent = self.agent_factory.create_agent('quality_control', name='Ido_Test')
        self.monitoring_agent = self.agent_factory.create_agent('monitoring', name='Shira_Test')
        self.sales_agent = self.agent_factory.create_agent('sales', name='Sales_Test')
        self.order_agent = self.agent_factory.create_agent('order', name='Order_Test')
        self.tech_agent = self.agent_factory.create_agent('technical_support', name='Tech_Test')
    
    def test_agent_creation(self):
        """Test that all agents are created correctly"""
        self.assertIsInstance(self.quality_agent, QualityControlAgent)
        self.assertIsInstance(self.monitoring_agent, MonitoringAgent)
        self.assertIsInstance(self.sales_agent, SalesAgent)
        self.assertIsInstance(self.order_agent, OrderAgent)
        self.assertIsInstance(self.tech_agent, TechnicalSupportAgent)
    
    def test_agent_info(self):
        """Test that agent info is correctly returned"""
        for agent in [self.quality_agent, self.monitoring_agent, self.sales_agent, 
                     self.order_agent, self.tech_agent]:
            info = agent.get_info()
            self.assertIn('agent_id', info)
            self.assertIn('name', info)
            self.assertIn('status', info)
    
    def test_agent_state_persistence(self):
        """Test that agent state can be saved and loaded"""
        # Update agent state
        self.order_agent.update_status('testing')
        
        # Save state to temporary file
        state_file = '/tmp/agent_state_test.json'
        self.order_agent.save_state(state_file)
        
        # Create a new agent
        new_agent = self.agent_factory.create_agent('order', name='Order_Test_New')
        
        # Load state
        new_agent.load_state(state_file)
        
        # Check that state was loaded correctly
        self.assertEqual(new_agent.status, 'testing')
        
        # Clean up
        if os.path.exists(state_file):
            os.remove(state_file)
    
    def test_quality_control_process(self):
        """Test quality control agent processing"""
        result = self.quality_agent.process({
            'part_id': 'TEST001',
            'quality_parameters': {
                'dimensions': {'length': 10, 'width': 5, 'height': 2},
                'material': 'steel',
                'finish': 'chrome'
            }
        })
        
        self.assertIn('status', result)
        self.assertIn('quality_score', result)
        self.assertIn('issues', result)
    
    def test_technical_support_compatibility(self):
        """Test technical support agent compatibility check"""
        result = self.tech_agent.process({
            'request_type': 'compatibility_check',
            'part_id': 'TEST001',
            'vehicle_make': 'Toyota',
            'vehicle_model': 'Corolla',
            'vehicle_year': '2020'
        })
        
        self.assertIn('status', result)
        self.assertIn('compatible', result)
        self.assertIn('confidence', result)
    
    def test_order_creation(self):
        """Test order agent order creation"""
        result = self.order_agent.process({
            'request_type': 'create_order',
            'parts': [{'part_id': 'TEST001', 'quantity': 1}],
            'customer_id': 'CUST001',
            'shipping_address': {
                'name': 'Test Customer',
                'street': '123 Test St',
                'city': 'Test City',
                'postal_code': '12345'
            }
        })
        
        self.assertIn('status', result)
        self.assertEqual(result['status'], 'success')
        self.assertIn('order_id', result)


class TestCatalogIntegration(unittest.TestCase):
    """Test integration with parts catalog components"""
    
    def setUp(self):
        """Set up test environment"""
        # Use temporary database for testing
        self.db_path = '/tmp/test_catalog.db'
        self.catalog_db = PartsCatalogDatabase(self.db_path)
        
        # Create test data directory
        self.test_data_dir = '/tmp/test_catalog_data'
        os.makedirs(self.test_data_dir, exist_ok=True)
        
        # Create test importer
        self.importer = PartsCatalogImporter(self.db_path)
        
        # Create test API integration
        self.api_integration = CatalogAPIIntegration({
            'cache_dir': os.path.join(self.test_data_dir, 'api_cache')
        })
    
    def tearDown(self):
        """Clean up test environment"""
        # Remove test database if it exists
        if os.path.exists(self.db_path):
            os.remove(self.db_path)
        
        # Remove test data directory
        import shutil
        if os.path.exists(self.test_data_dir):
            shutil.rmtree(self.test_data_dir)
    
    def test_add_part(self):
        """Test adding a part to the catalog"""
        part_data = {
            'part_id': 'TEST001',
            'catalog_number': 'CAT001',
            'name': 'Test Part',
            'description': 'A test part for unit testing',
            'category': 'Test',
            'manufacturer': 'Test Manufacturer'
        }
        
        part_id = self.catalog_db.add_part(part_data)
        self.assertEqual(part_id, 'TEST001')
        
        # Retrieve the part
        part = self.catalog_db.get_part('TEST001')
        self.assertEqual(part['name'], 'Test Part')
    
    def test_search_parts(self):
        """Test searching for parts"""
        # Add test parts
        for i in range(5):
            self.catalog_db.add_part({
                'part_id': f'TEST{i:03d}',
                'catalog_number': f'CAT{i:03d}',
                'name': f'Test Part {i}',
                'description': f'A test part number {i}',
                'category': 'Test',
                'manufacturer': 'Test Manufacturer'
            })
        
        # Search by name
        results = self.catalog_db.search_parts('Test Part 3')
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['part_id'], 'TEST003')
        
        # Search by category
        results = self.catalog_db.search_parts('', category='Test')
        self.assertEqual(len(results), 5)
    
    def test_json_import(self):
        """Test importing parts from JSON"""
        # Create test JSON file
        json_path = os.path.join(self.test_data_dir, 'test_parts.json')
        with open(json_path, 'w') as f:
            json.dump([
                {
                    'part_id': 'JSON001',
                    'catalog_number': 'JCAT001',
                    'name': 'JSON Test Part 1',
                    'description': 'A test part imported from JSON',
                    'category': 'Test',
                    'manufacturer': 'Test Manufacturer'
                },
                {
                    'part_id': 'JSON002',
                    'catalog_number': 'JCAT002',
                    'name': 'JSON Test Part 2',
                    'description': 'Another test part imported from JSON',
                    'category': 'Test',
                    'manufacturer': 'Test Manufacturer'
                }
            ], f)
        
        # Import the JSON file
        result = self.importer.import_from_json(json_path)
        
        self.assertEqual(result['status'], 'success')
        self.assertEqual(result['imported_count'], 2)
        
        # Verify the parts were imported
        part = self.catalog_db.get_part('JSON001')
        self.assertEqual(part['name'], 'JSON Test Part 1')
        
        part = self.catalog_db.get_part('JSON002')
        self.assertEqual(part['name'], 'JSON Test Part 2')


class TestOrderManagementIntegration(unittest.TestCase):
    """Test integration with order management system"""
    
    def setUp(self):
        """Set up test environment"""
        # Create mock CRM interface
        self.crm_interface = MockCRMInterface()
        
        # Create order management system with mock CRM
        self.order_system = OrderManagementSystem({
            'crm_interface': self.crm_interface,
            'supplier_apis': {
                'test_supplier': {
                    'name': 'Test Supplier',
                    'api_key': 'test_key',
                    'order_url': 'http://example.com/api/orders',
                    'status_url': 'http://example.com/api/orders/status',
                    'status_update_url': 'http://example.com/api/orders/update'
                }
            }
        })
    
    def test_create_order(self):
        """Test creating an order"""
        result = self.order_system.create_order({
            'customer_id': 'CUST001',
            'parts': [
                {'part_id': 'TEST001', 'catalog_number': 'CAT001', 'quantity': 1, 'price': 100},
                {'part_id': 'TEST002', 'catalog_number': 'CAT002', 'quantity': 2, 'price': 50}
            ],
            'shipping_address': {
                'name': 'Test Customer',
                'street': '123 Test St',
                'city': 'Test City',
                'postal_code': '12345'
            }
        })
        
        self.assertEqual(result['status'], 'success')
        self.assertIn('order_id', result)
        self.assertIn('crm_order_id', result)
        
        # Verify order was created in CRM
        self.assertEqual(len(self.crm_interface.orders), 1)
        self.assertEqual(self.crm_interface.orders[0]['customer_id'], 'CUST001')
    
    def test_get_order(self):
        """Test retrieving an order"""
        # Create an order first
        create_result = self.order_system.create_order({
            'customer_id': 'CUST001',
            'parts': [{'part_id': 'TEST001', 'catalog_number': 'CAT001', 'quantity': 1, 'price': 100}],
            'shipping_address': {'name': 'Test Customer'}
        })
        
        order_id = create_result['order_id']
        
        # Get the order
        result = self.order_system.get_order(order_id)
        
        self.assertEqual(result['status'], 'success')
        self.assertEqual(result['order']['order_id'], order_id)
        self.assertEqual(result['order']['customer_id'], 'CUST001')
    
    def test_update_order_status(self):
        """Test updating order status"""
        # Create an order first
        create_result = self.order_system.create_order({
            'customer_id': 'CUST001',
            'parts': [{'part_id': 'TEST001', 'catalog_number': 'CAT001', 'quantity': 1, 'price': 100}],
            'shipping_address': {'name': 'Test Customer'}
        })
        
        order_id = create_result['order_id']
        
        # Update the status
        result = self.order_system.update_order_status(order_id, 'shipped')
        
        self.assertEqual(result['status'], 'success')
        
        # Verify the status was updated
        order_result = self.order_system.get_order(order_id)
        self.assertEqual(order_result['order']['status'], 'shipped')


class TestSystemIntegrationManager(unittest.TestCase):
    """Test the system integration manager"""
    
    def setUp(self):
        """Set up test environment"""
        # Create a test configuration
        self.config = {
            'catalog': {
                'db_path': '/tmp/test_system_catalog.db'
            },
            'crm': {
                'type': 'mock',
                'api_key': 'test_key'
            },
            'order_system': {
                'supplier_apis': {
                    'test_supplier': {
                        'name': 'Test Supplier',
                        'api_key': 'test_key'
                    }
                }
            },
            'vehicle_data': {
                'api_key': 'test_key',
                'cache_enabled': True
            }
        }
        
        # Create the system integration manager
        self.system_manager = SystemIntegrationManager(self.config)
    
    def tearDown(self):
        """Clean up test environment"""
        # Remove test database if it exists
        if os.path.exists('/tmp/test_system_catalog.db'):
            os.remove('/tmp/test_system_catalog.db')
    
    def test_system_status(self):
        """Test getting system status"""
        result = self.system_manager.get_system_status()
        
        self.assertEqual(result['status'], 'success')
        self.assertIn('system_status', result)
        self.assertIn('components', result['system_status'])
        self.assertIn('agents', result['system_status']['components'])
        
        # Check that all components are active
        self.assertEqual(result['system_status']['components']['catalog'], 'active')
        self.assertEqual(result['system_status']['components']['crm'], 'active')
        self.assertEqual(result['system_status']['components']['order_system'], 'active')
        self.assertEqual(result['system_status']['components']['vehicle_data'], 'active')
    
    def test_agent_request_routing(self):
        """Test routing agent requests"""
        result = self.system_manager.process_request({
            'request_type': 'agent_request',
            'agent_type': 'quality_control',
            'action': 'get_info'
        })
        
        self.assertEqual(result['status'], 'success')
        self.assertIn('agent_info', result)
        self.assertEqual(result['agent_info']['name'], 'Ido')
    
    def test_catalog_request_routing(self):
        """Test routing catalog requests"""
        # Add a test part first
        self.system_manager.process_request({
            'request_type': 'catalog_request',
            'action': 'add_part',
            'part_data': {
                'part_id': 'SYS001',
                'name': 'System Test Part',
                'description': 'A part for testing the system integration manager',
                'category': 'Test'
            }
        })
        
        # Search for the part
        result = self.system_manager.process_request({
            'request_type': 'catalog_request',
            'action': 'search',
            'query': 'System Test Part'
        })
        
        self.assertEqual(result['status'], 'success')
        self.assertIn('results', result)
        self.assertEqual(len(result['results']), 1)
        self.assertEqual(result['results'][0]['part_id'], 'SYS001')


# Mock classes for testing
class MockCRMInterface:
    """Mock CRM interface for testing"""
    
    def __init__(self):
        self.customers = []
        self.orders = []
    
    def create_customer(self, customer_data):
        customer_id = customer_data.get('id', f"CUST{len(self.customers)+1:03d}")
        customer_data['id'] = customer_id
        self.customers.append(customer_data)
        return {'id': customer_id}
    
    def get_customer(self, customer_id):
        for customer in self.customers:
            if customer['id'] == customer_id:
                return customer
        return {'error': 'Customer not found'}
    
    def create_order(self, order_data):
        order_id = f"ORD{len(self.orders)+1:03d}"
        order_data['id'] = order_id
        self.orders.append(order_data)
        return {'id': order_id}
    
    def get_order(self, order_id):
        for order in self.orders:
            if order['id'] == order_id:
                return order
        return {'error': 'Order not found'}
    
    def update_order_status(self, order_id, status):
        for order in self.orders:
            if order['id'] == order_id:
                order['status'] = status
                return {'status': 'success'}
        return {'error': 'Order not found'}
    
    def search_customers(self, query):
        results = []
        for customer in self.customers:
            if query.lower() in customer.get('name', '').lower():
                results.append(customer)
        return results


if __name__ == '__main__':
    unittest.main()

import unittest
import os
import sys
import json
import sqlite3
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Add project root to path
sys.path.append('/home/ubuntu/autosparefinder_dev')
sys.path.append('/home/ubuntu/compatibility_updates')

# Database path
db_path = '/home/ubuntu/autosparefinder_dev/database/parts_catalog.db'

class EVIntegrationTests(unittest.TestCase):
    """Comprehensive integration tests for electric vehicle functionality"""
    
    @classmethod
    def setUpClass(cls):
        """Set up test environment once before all tests"""
        # Connect to database
        cls.conn = sqlite3.connect(db_path)
        cls.cursor = cls.conn.cursor()
        
        # Get all electric manufacturers
        cls.cursor.execute("SELECT id, name FROM manufacturers WHERE type = 'Electric'")
        cls.ev_manufacturers = cls.cursor.fetchall()
        
        # Get all traditional manufacturers
        cls.cursor.execute("SELECT id, name FROM manufacturers WHERE type = 'Traditional'")
        cls.traditional_manufacturers = cls.cursor.fetchall()
        
        # Get sample parts for each manufacturer type
        cls.cursor.execute("""
        SELECT p.id, p.catalog_number, p.description, m.name 
        FROM parts p
        JOIN manufacturers m ON p.manufacturer_id = m.id
        WHERE m.type = 'Electric'
        LIMIT 10
        """)
        cls.ev_parts = cls.cursor.fetchall()
        
        cls.cursor.execute("""
        SELECT p.id, p.catalog_number, p.description, m.name 
        FROM parts p
        JOIN manufacturers m ON p.manufacturer_id = m.id
        WHERE m.type = 'Traditional'
        LIMIT 10
        """)
        cls.traditional_parts = cls.cursor.fetchall()
        
        logger.info(f"Test setup complete. Found {len(cls.ev_manufacturers)} EV manufacturers and {len(cls.traditional_manufacturers)} traditional manufacturers")
        logger.info(f"Sample parts: {len(cls.ev_parts)} EV parts and {len(cls.traditional_parts)} traditional parts")
    
    @classmethod
    def tearDownClass(cls):
        """Clean up after all tests"""
        cls.conn.close()
    
    def test_ev_manufacturers_exist(self):
        """Test that all expected EV manufacturers exist in the database"""
        expected_manufacturers = [
            'Scout Motors', 'Afeela', 'VinFast', 'Polestar', 'Rivian', 
            'Lucid Motors', 'Canoo', 'Fisker', 'Jaecoo', 'BYD'
        ]
        
        actual_manufacturers = [m[1] for m in self.ev_manufacturers]
        
        for manufacturer in expected_manufacturers:
            self.assertIn(manufacturer, actual_manufacturers, f"Expected manufacturer {manufacturer} not found in database")
        
        self.assertEqual(len(expected_manufacturers), len(actual_manufacturers), 
                         f"Expected {len(expected_manufacturers)} EV manufacturers, found {len(actual_manufacturers)}")
    
    def test_ev_parts_exist(self):
        """Test that EV parts exist in the database"""
        self.assertGreater(len(self.ev_parts), 0, "No EV parts found in database")
    
    def test_compatibility_rules_exist(self):
        """Test that compatibility rules exist for EV manufacturers"""
        for manufacturer_id, name in self.ev_manufacturers:
            self.cursor.execute(
                "SELECT COUNT(*) FROM compatibility_rules WHERE manufacturer_id = ?", 
                (manufacturer_id,)
            )
            rule_count = self.cursor.fetchone()[0]
            
            self.assertGreater(rule_count, 0, f"No compatibility rules found for {name}")
    
    def test_knowledge_base_entries_exist(self):
        """Test that knowledge base entries exist for EV manufacturers"""
        for _, name in self.ev_manufacturers:
            self.cursor.execute(
                "SELECT COUNT(*) FROM knowledge_base WHERE category = 'manufacturers' AND key = ?", 
                (name.lower(),)
            )
            entry_count = self.cursor.fetchone()[0]
            
            self.assertGreater(entry_count, 0, f"No knowledge base entry found for {name}")
    
    def test_ev_general_knowledge_exists(self):
        """Test that general EV knowledge exists in the database"""
        expected_topics = ['ev_battery_types', 'ev_charging_standards', 'ev_maintenance_tips']
        
        for topic in expected_topics:
            self.cursor.execute(
                "SELECT COUNT(*) FROM knowledge_base WHERE category = 'ev_general' AND key = ?", 
                (topic,)
            )
            entry_count = self.cursor.fetchone()[0]
            
            self.assertGreater(entry_count, 0, f"No knowledge base entry found for {topic}")
    
    def test_same_manufacturer_compatibility(self):
        """Test compatibility between parts and vehicles from the same manufacturer"""
        for part_id, catalog_number, description, manufacturer in self.ev_parts:
            # Test compatibility with same manufacturer
            compatibility = self._check_compatibility(catalog_number, manufacturer, f"{manufacturer} Model X")
            
            self.assertTrue(compatibility['compatible'], 
                           f"Part {catalog_number} from {manufacturer} should be compatible with {manufacturer} Model X")
            self.assertGreaterEqual(compatibility['confidence'], 70, 
                                  f"Confidence for same-manufacturer compatibility should be at least 70%")
    
    def test_different_manufacturer_compatibility(self):
        """Test compatibility between parts and vehicles from different manufacturers"""
        for part_id, catalog_number, description, manufacturer in self.ev_parts:
            # Find a different manufacturer
            different_manufacturers = [m[1] for m in self.ev_manufacturers if m[1] != manufacturer]
            
            if different_manufacturers:
                different_manufacturer = different_manufacturers[0]
                
                # Test compatibility with different manufacturer
                compatibility = self._check_compatibility(catalog_number, different_manufacturer, f"{different_manufacturer} Model Y")
                
                # For battery and motor parts, should not be compatible across manufacturers
                if 'battery' in description.lower() or 'motor' in description.lower():
                    self.assertFalse(compatibility['compatible'], 
                                    f"Battery/motor part {catalog_number} from {manufacturer} should not be compatible with {different_manufacturer}")
                
                # For charging ports, might be compatible if they follow the same standard
                elif 'charging' in description.lower() or 'port' in description.lower():
                    # No assertion here as it depends on standards
                    logger.info(f"Charging port compatibility: {compatibility}")
    
    def test_parent_company_compatibility(self):
        """Test compatibility between parts and vehicles from related manufacturers (same parent company)"""
        # Find manufacturers with the same parent company
        self.cursor.execute("""
        SELECT m1.id, m1.name, m2.id, m2.name
        FROM manufacturers m1
        JOIN manufacturers m2 ON m1.parent_company = m2.parent_company
        WHERE m1.id != m2.id AND m1.parent_company != 'Independent' AND m1.type = 'Electric' AND m2.type = 'Electric'
        LIMIT 1
        """)
        
        related_manufacturers = self.cursor.fetchone()
        
        if related_manufacturers:
            m1_id, m1_name, m2_id, m2_name = related_manufacturers
            
            # Get a part from the first manufacturer
            self.cursor.execute("""
            SELECT p.catalog_number, p.description
            FROM parts p
            WHERE p.manufacturer_id = ?
            LIMIT 1
            """, (m1_id,))
            
            part = self.cursor.fetchone()
            
            if part:
                catalog_number, description = part
                
                # Test compatibility with related manufacturer
                compatibility = self._check_compatibility(catalog_number, m2_name, f"{m2_name} Model Z")
                
                # For general parts, might be compatible across related manufacturers
                if 'general' in description.lower():
                    logger.info(f"Related manufacturer compatibility for general part: {compatibility}")
    
    def test_ev_traditional_compatibility(self):
        """Test compatibility between EV parts and traditional vehicles"""
        for part_id, catalog_number, description, manufacturer in self.ev_parts:
            # Get a traditional manufacturer
            traditional_manufacturer = self.traditional_manufacturers[0][1]
            
            # Test compatibility with traditional manufacturer
            compatibility = self._check_compatibility(catalog_number, traditional_manufacturer, f"{traditional_manufacturer} Model T")
            
            # EV-specific parts should not be compatible with traditional vehicles
            if 'battery' in description.lower() or 'motor' in description.lower() or 'charging' in description.lower():
                self.assertFalse(compatibility['compatible'], 
                                f"EV-specific part {catalog_number} should not be compatible with traditional vehicle {traditional_manufacturer}")
    
    def test_traditional_ev_compatibility(self):
        """Test compatibility between traditional parts and EV vehicles"""
        for part_id, catalog_number, description, manufacturer in self.traditional_parts:
            # Get an EV manufacturer
            ev_manufacturer = self.ev_manufacturers[0][1]
            
            # Test compatibility with EV manufacturer
            compatibility = self._check_compatibility(catalog_number, ev_manufacturer, f"{ev_manufacturer} Model E")
            
            # General parts might be compatible
            if 'general' in description.lower():
                logger.info(f"Traditional to EV compatibility for general part: {compatibility}")
    
    def test_compatibility_with_year(self):
        """Test compatibility with vehicle year specified"""
        for part_id, catalog_number, description, manufacturer in self.ev_parts:
            # Test compatibility with same manufacturer and specific year
            compatibility = self._check_compatibility(catalog_number, manufacturer, f"{manufacturer} Model X", "2025")
            
            self.assertTrue(compatibility['compatible'], 
                           f"Part {catalog_number} from {manufacturer} should be compatible with {manufacturer} Model X (2025)")
    
    def test_compatibility_with_invalid_data(self):
        """Test compatibility check with invalid data"""
        # Test with non-existent part
        compatibility = self._check_compatibility("NONEXISTENT", "Rivian", "Rivian R1T")
        self.assertFalse(compatibility['compatible'], "Non-existent part should not be compatible")
        
        # Test with non-existent manufacturer
        compatibility = self._check_compatibility(self.ev_parts[0][1], "NONEXISTENT", "NONEXISTENT Model")
        self.assertFalse(compatibility['compatible'], "Part with non-existent manufacturer should not be compatible")
    
    def _check_compatibility(self, part_id, vehicle_make, vehicle_model, vehicle_year=None):
        """Helper method to check part compatibility"""
        # Create a simple test function that mimics the compatibility check
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Get part information
        cursor.execute("""
        SELECT p.id, p.catalog_number, p.description, p.type, m.id, m.name, m.type
        FROM parts p
        JOIN manufacturers m ON p.manufacturer_id = m.id
        WHERE p.catalog_number = ?
        """, (part_id,))
        
        part = cursor.fetchone()
        
        if not part:
            conn.close()
            return {
                'compatible': False,
                'confidence': 0,
                'message': f"Part {part_id} not found in database"
            }
        
        part_id, catalog_number, description, part_type, manufacturer_id, manufacturer_name, manufacturer_type = part
        
        # Get vehicle manufacturer
        cursor.execute("SELECT id, name, type FROM manufacturers WHERE name LIKE ?", (f"%{vehicle_make}%",))
        vehicle_manufacturer = cursor.fetchone()
        
        if not vehicle_manufacturer:
            conn.close()
            return {
                'compatible': False,
                'confidence': 10,
                'message': f"Vehicle manufacturer {vehicle_make} not found in database"
            }
        
        vehicle_manufacturer_id, vehicle_manufacturer_name, vehicle_manufacturer_type = vehicle_manufacturer
        
        # Check direct compatibility from vehicle_compatibility table
        if vehicle_year:
            cursor.execute("""
            SELECT notes FROM vehicle_compatibility 
            WHERE part_id = ? AND manufacturer_id = ? AND model LIKE ? 
            AND (year_from IS NULL OR year_from <= ?) 
            AND (year_to IS NULL OR year_to >= ?)
            """, (part_id, vehicle_manufacturer_id, f"%{vehicle_model}%", vehicle_year, vehicle_year))
        else:
            cursor.execute("""
            SELECT notes FROM vehicle_compatibility 
            WHERE part_id = ? AND manufacturer_id = ? AND model LIKE ?
            """, (part_id, vehicle_manufacturer_id, f"%{vehicle_model}%"))
        
        direct_compatibility = cursor.fetchone()
        
        if direct_compatibility:
            conn.close()
            return {
                'compatible': True,
                'confidence': 95,
                'message': direct_compatibility[0] or "Part is directly compatible with this vehicle based on our records"
            }
        
        # Check compatibility rules
        cursor.execute("""
        SELECT rule_type, compatible_with, confidence, notes
        FROM compatibility_rules
        WHERE manufacturer_id = ? AND (part_type = ? OR part_type = 'general')
        """, (manufacturer_id, part_type))
        
        rules = cursor.fetchall()
        
        for rule_type, compatible_with_json, confidence, notes in rules:
            compatible_with = json.loads(compatible_with_json)
            
            if rule_type == 'ev_general' and manufacturer_type == 'Electric' and vehicle_manufacturer_type == 'Electric':
                if compatible_with['type'] == 'same_manufacturer' and manufacturer_id == vehicle_manufacturer_id:
                    conn.close()
                    return {
                        'compatible': True,
                        'confidence': confidence,
                        'message': notes
                    }
                elif compatible_with['type'] == 'standard' and part_type == 'charging_port':
                    # For charging ports, compatibility depends on standards
                    conn.close()
                    return {
                        'compatible': True,
                        'confidence': confidence,
                        'message': notes
                    }
            
            elif rule_type == 'parent_company':
                if compatible_with['type'] == 'parent_company' and vehicle_manufacturer_id in compatible_with['manufacturers']:
                    conn.close()
                    return {
                        'compatible': True,
                        'confidence': confidence,
                        'message': notes
                    }
        
        # If no specific rule matched but manufacturers are the same, assume some compatibility
        if manufacturer_id == vehicle_manufacturer_id:
            conn.close()
            return {
                'compatible': True,
                'confidence': 70,
                'message': f"Part is from the same manufacturer ({manufacturer_name}) as the vehicle, but specific compatibility is not confirmed"
            }
        
        # Default response for unknown compatibility
        conn.close()
        return {
            'compatible': False,
            'confidence': 20,
            'message': f"No compatibility information available for {part_id} with {vehicle_make} {vehicle_model}"
        }

class APIIntegrationTests(unittest.TestCase):
    """Integration tests for API functionality"""
    
    def test_vehicle_licensing_api(self):
        """Test integration with vehicle licensing API"""
        # Import the API module
        sys.path.append('/home/ubuntu/autosparefinder_dev/api')
        try:
            from vehicle_licensing_api import VehicleLicensingAPI
            
            # Initialize API
            api = VehicleLicensingAPI()
            
            # Test vehicle lookup
            vehicle_data = api.get_vehicle_by_license("12345678")
            
            # Just check that the API returns something without errors
            self.assertIsNotNone(vehicle_data, "Vehicle licensing API should return data")
            
        except ImportError:
            self.skipTest("Vehicle licensing API module not found")
    
    def test_parts_supplier_api(self):
        """Test integration with parts supplier API"""
        # Import the API module
        sys.path.append('/home/ubuntu/autosparefinder_dev/api')
        try:
            from parts_supplier_api import PartsSupplierAPI
            
            # Initialize API
            api = PartsSupplierAPI()
            
            # Test part lookup
            part_data = api.get_part_by_catalog_number("12345")
            
            # Just check that the API returns something without errors
            self.assertIsNotNone(part_data, "Parts supplier API should return data")
            
        except ImportError:
            self.skipTest("Parts supplier API module not found")
    
    def test_ckan_vehicle_api(self):
        """Test integration with CKAN vehicle API"""
        # Import the API module
        sys.path.append('/home/ubuntu/autosparefinder_dev/api')
        try:
            from ckan_vehicle_api import CKANVehicleAPI
            
            # Initialize API
            api = CKANVehicleAPI()
            
            # Test vehicle lookup
            vehicle_data = api.get_vehicle_data("Toyota", "Corolla", "2020")
            
            # Just check that the API returns something without errors
            self.assertIsNotNone(vehicle_data, "CKAN vehicle API should return data")
            
        except ImportError:
            self.skipTest("CKAN vehicle API module not found")
    
    def test_hybrid_vehicle_data_manager(self):
        """Test integration with hybrid vehicle data manager"""
        # Import the API module
        sys.path.append('/home/ubuntu/autosparefinder_dev/api')
        try:
            from hybrid_vehicle_data_manager import HybridVehicleDataManager
            
            # Initialize manager
            manager = HybridVehicleDataManager()
            
            # Test vehicle lookup
            vehicle_data = manager.get_vehicle_data("12345678")
            
            # Just check that the manager returns something without errors
            self.assertIsNotNone(vehicle_data, "Hybrid vehicle data manager should return data")
            
        except ImportError:
            self.skipTest("Hybrid vehicle data manager module not found")

class AgentIntegrationTests(unittest.TestCase):
    """Integration tests for agent functionality"""
    
    def test_quality_control_agent(self):
        """Test integration with quality control agent"""
        # Import the agent module
        sys.path.append('/home/ubuntu/autosparefinder_dev/agents')
        try:
            from quality_control_agent import QualityControlAgent
            
            # Initialize agent
            agent = QualityControlAgent()
            
            # Test quality check
            quality_data = agent.check_part_quality("12345")
            
            # Just check that the agent returns something without errors
            self.assertIsNotNone(quality_data, "Quality control agent should return data")
            
        except ImportError:
            self.skipTest("Quality control agent module not found")
    
    def test_monitoring_agent(self):
        """Test integration with monitoring agent"""
        # Import the agent module
        sys.path.append('/home/ubuntu/autosparefinder_dev/agents')
        try:
            from monitoring_agent import MonitoringAgent
            
            # Initialize agent
            agent = MonitoringAgent()
            
            # Test monitoring
            monitoring_data = agent.get_system_status()
            
            # Just check that the agent returns something without errors
            self.assertIsNotNone(monitoring_data, "Monitoring agent should return data")
            
        except ImportError:
            self.skipTest("Monitoring agent module not found")
    
    def test_order_agent(self):
        """Test integration with order agent"""
        # Import the agent module
        sys.path.append('/home/ubuntu/autosparefinder_dev/agents')
        try:
            from order_agent import OrderAgent
            
            # Initialize agent
            agent = OrderAgent()
            
            # Test order creation
            order_data = agent.create_order("12345", 1)
            
            # Just check that the agent returns something without errors
            self.assertIsNotNone(order_data, "Order agent should return data")
            
        except ImportError:
            self.skipTest("Order agent module not found")
    
    def test_technical_support_agent(self):
        """Test integration with technical support agent"""
        # Import the agent module
        sys.path.append('/home/ubuntu/autosparefinder_dev/agents')
        try:
            from technical_support_agent import TechnicalSupportAgent
            
            # Initialize agent
            agent = TechnicalSupportAgent()
            
            # Test technical support
            support_data = agent.get_technical_info("12345")
            
            # Just check that the agent returns something without errors
            self.assertIsNotNone(support_data, "Technical support agent should return data")
            
        except ImportError:
            self.skipTest("Technical support agent module not found")
    
    def test_agent_factory(self):
        """Test integration with agent factory"""
        # Import the agent factory module
        sys.path.append('/home/ubuntu/autosparefinder_dev/agents')
        try:
            from agent_factory import AgentFactory
            
            # Initialize factory
            factory = AgentFactory()
            
            # Test agent creation
            quality_agent = factory.create_agent("quality_control")
            monitoring_agent = factory.create_agent("monitoring")
            order_agent = factory.create_agent("order")
            technical_agent = factory.create_agent("technical_support")
            
            # Check that agents are created
            self.assertIsNotNone(quality_agent, "Agent factory should create quality control agent")
            self.assertIsNotNone(monitoring_agent, "Agent factory should create monitoring agent")
            self.assertIsNotNone(order_agent, "Agent factory should create order agent")
            self.assertIsNotNone(technical_agent, "Agent factory should create technical support agent")
            
        except ImportError:
            self.skipTest("Agent factory module not found")

class SystemIntegrationTests(unittest.TestCase):
    """Integration tests for overall system functionality"""
    
    def test_system_integration_manager(self):
        """Test integration with system integration manager"""
        # Import the system integration manager module
        sys.path.append('/home/ubuntu/autosparefinder_dev')
        try:
            from system_integration_manager import SystemIntegrationManager
            
            # Initialize manager
            manager = SystemIntegrationManager()
            
            # Test system status
            status = manager.get_system_status()
            
            # Just check that the manager returns something without errors
            self.assertIsNotNone(status, "System integration manager should return status")
            
        except ImportError:
            self.skipTest("System integration manager module not found")
    
    def test_order_management_system(self):
        """Test integration with order management system"""
        # Import the order management system module
        sys.path.append('/home/ubuntu/autosparefinder_dev/database')
        try:
            from order_management_system import OrderManagementSystem
            
            # Initialize system
            system = OrderManagementSystem()
            
            # Test order creation
            order = system.create_order("12345", 1, "Test Customer")
            
            # Just check that the system returns something without errors
            self.assertIsNotNone(order, "Order management system should create order")
            
        except ImportError:
            self.skipTest("Order management system module not found")
    
    def test_crm_interface(self):
        """Test integration with CRM interface"""
        # Import the CRM interface module
        sys.path.append('/home/ubuntu/autosparefinder_dev/api')
        try:
            from crm_interface import CRMInterface
            
            # Initialize interface
            interface = CRMInterface()
            
            # Test customer lookup
            customer = interface.get_customer("12345")
            
            # Just check that the interface returns something without errors
            self.assertIsNotNone(customer, "CRM interface should return customer data")
            
        except ImportError:
            self.skipTest("CRM interface module not found")

def run_tests():
    """Run all integration tests and generate report"""
    # Create test suite
    suite = unittest.TestSuite()
    
    # Add test cases
    suite.addTest(unittest.makeSuite(EVIntegrationTests))
    suite.addTest(unittest.makeSuite(APIIntegrationTests))
    suite.addTest(unittest.makeSuite(AgentIntegrationTests))
    suite.addTest(unittest.makeSuite(SystemIntegrationTests))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Generate report
    report = f"""# Integration Tests Report

## Summary
- **Date**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- **Tests Run**: {result.testsRun}
- **Tests Passed**: {result.testsRun - len(result.failures) - len(result.errors)}
- **Tests Failed**: {len(result.failures)}
- **Tests Errored**: {len(result.errors)}
- **Overall Result**: {'✅ Passed' if result.wasSuccessful() else '❌ Failed'}

## Test Categories
1. **EV Integration Tests**: Tests for electric vehicle manufacturer and part integration
2. **API Integration Tests**: Tests for API functionality and integration
3. **Agent Integration Tests**: Tests for agent functionality and integration
4. **System Integration Tests**: Tests for overall system functionality

## Failures
"""
    
    if result.failures:
        for test, traceback in result.failures:
            report += f"""
### {test}
```
{traceback}
```
"""
    else:
        report += "No failures.\n"
    
    report += "\n## Errors\n"
    
    if result.errors:
        for test, traceback in result.errors:
            report += f"""
### {test}
```
{traceback}
```
"""
    else:
        report += "No errors.\n"
    
    report += """
## Next Steps
1. Fix any failures or errors identified in the tests
2. Add more specific tests for edge cases
3. Implement performance tests
4. Implement load tests
"""
    
    # Save report
    output_dir = '/home/ubuntu/test_results'
    os.makedirs(output_dir, exist_ok=True)
    
    with open(os.path.join(output_dir, 'integration_tests_report.md'), 'w') as f:
        f.write(report)
    
    logger.info(f"Integration tests report generated at {os.path.join(output_dir, 'integration_tests_report.md')}")
    
    return result.wasSuccessful()

if __name__ == "__main__":
    run_tests()

from flask import Flask, request, jsonify, render_template, send_from_directory
import os
import logging
from database.db_setup import init_db
from agents.agent_factory import AgentFactory
from api.vehicle_licensing_api import VehicleLicensingAPI
from api.parts_supplier_api import PartsSupplierAPI

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)

# Initialize agents
agents = {
    "sales": AgentFactory.create_agent("sales", "Sales Assistant"),
    "quality": AgentFactory.create_agent("quality", "Ido"),
    "monitoring": AgentFactory.create_agent("monitoring", "Shira")
}

# Initialize API clients
vehicle_api = VehicleLicensingAPI()
parts_api = PartsSupplierAPI()

# Serve static files
@app.route('/static/<path:path>')
def serve_static(path):
    return send_from_directory('static', path)

# Home route
@app.route('/')
def home():
    return render_template('index.html')

# Agent management API routes
@app.route('/agents', methods=['GET'])
def get_agents():
    """Return a list of all available agents"""
    agent_data = {}
    for agent_id, agent in agents.items():
        agent_data[agent_id] = {
            "full_name": agent.name,
            "role": getattr(agent, 'role', 'Agent'),
            "specialty": getattr(agent, 'specialty', 'General'),
            "status": "active"
        }
    return jsonify(agent_data)

@app.route('/toggle_agent', methods=['POST'])
def toggle_agent():
    """Toggle an agent's status"""
    data = request.json
    agent_name = data.get('agent_name')
    status = data.get('status', 'active')
    
    if agent_name in agents:
        # In a real implementation, we would update the agent's status
        return jsonify({"message": f"Agent {agent_name} status updated to {status}"})
    else:
        return jsonify({"message": f"Agent {agent_name} not found"}), 404

@app.route('/add_agent', methods=['POST'])
def add_agent():
    """Add a new agent"""
    data = request.json
    agent_name = data.get('agent_name')
    agent_type = data.get('role', 'sales').lower().split()[0]  # Extract first word of role as type
    
    if agent_name and agent_name not in agents:
        try:
            # Create new agent using factory
            new_agent = AgentFactory.create_agent(agent_type, agent_name)
            agents[agent_name] = new_agent
            return jsonify({"message": f"Agent {agent_name} added successfully"})
        except Exception as e:
            logger.error(f"Error adding agent: {e}")
            return jsonify({"message": f"Error adding agent: {str(e)}"}), 500
    else:
        return jsonify({"message": f"Invalid agent name or agent already exists"}), 400

@app.route('/delete_agent', methods=['POST'])
def delete_agent():
    """Delete an agent"""
    data = request.json
    agent_name = data.get('agent_name')
    
    if agent_name in agents:
        del agents[agent_name]
        return jsonify({"message": f"Agent {agent_name} deleted successfully"})
    else:
        return jsonify({"message": f"Agent {agent_name} not found"}), 404

# Agent interaction routes
@app.route('/chat/<agent_id>', methods=['POST'])
def chat_with_agent(agent_id):
    """Send a message to a specific agent and get a response"""
    if agent_id not in agents:
        return jsonify({"error": f"Agent {agent_id} not found"}), 404
        
    data = request.json
    message = data.get('message', '')
    
    if not message:
        return jsonify({"error": "No message provided"}), 400
        
    try:
        response = agents[agent_id].respond(message)
        return jsonify({"response": response})
    except Exception as e:
        logger.error(f"Error getting response from agent {agent_id}: {e}")
        return jsonify({"error": f"Error getting response: {str(e)}"}), 500

# Quality control routes
@app.route('/quality/check', methods=['POST'])
def quality_check():
    """Perform quality check on a part"""
    if 'quality' not in agents:
        return jsonify({"error": "Quality control agent not available"}), 503
        
    data = request.json
    part_data = data.get('part_data', {})
    
    if not part_data:
        return jsonify({"error": "No part data provided"}), 400
        
    try:
        result = agents['quality'].check_part_quality(part_data)
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error in quality check: {e}")
        return jsonify({"error": f"Error in quality check: {str(e)}"}), 500

# Monitoring routes
@app.route('/monitoring/status', methods=['GET'])
def monitoring_status():
    """Get current system status from monitoring agent"""
    if 'monitoring' not in agents:
        return jsonify({"error": "Monitoring agent not available"}), 503
        
    try:
        report = agents['monitoring'].generate_report()
        return jsonify(report)
    except Exception as e:
        logger.error(f"Error getting monitoring status: {e}")
        return jsonify({"error": f"Error getting status: {str(e)}"}), 500

@app.route('/monitoring/track', methods=['POST'])
def track_request():
    """Track a request in the monitoring system"""
    if 'monitoring' not in agents:
        return jsonify({"error": "Monitoring agent not available"}), 503
        
    data = request.json
    request_data = data.get('request_data', {})
    
    if not request_data:
        return jsonify({"error": "No request data provided"}), 400
        
    try:
        metrics = agents['monitoring'].monitor_request(request_data)
        return jsonify({"metrics": metrics})
    except Exception as e:
        logger.error(f"Error tracking request: {e}")
        return jsonify({"error": f"Error tracking request: {str(e)}"}), 500

# Vehicle API routes
@app.route('/vehicle/details', methods=['GET'])
def get_vehicle_details():
    """Get vehicle details by license plate or VIN"""
    license_plate = request.args.get('license_plate')
    vin = request.args.get('vin')
    
    if not license_plate and not vin:
        return jsonify({"error": "Either license plate or VIN must be provided"}), 400
        
    try:
        result = vehicle_api.get_vehicle_details(license_plate, vin)
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error getting vehicle details: {e}")
        return jsonify({"error": f"Error getting vehicle details: {str(e)}"}), 500

@app.route('/vehicle/compatibility', methods=['GET'])
def check_vehicle_compatibility():
    """Check if a part is compatible with a vehicle"""
    part_id = request.args.get('part_id')
    vehicle_id = request.args.get('vehicle_id')
    make = request.args.get('make')
    model = request.args.get('model')
    year = request.args.get('year')
    
    if not part_id:
        return jsonify({"error": "Part ID is required"}), 400
        
    if not vehicle_id and not (make and model and year):
        return jsonify({"error": "Either vehicle_id or make, model, and year must be provided"}), 400
        
    try:
        if year:
            year = int(year)
        result = vehicle_api.get_part_compatibility(part_id, vehicle_id, make, model, year)
        return jsonify(result)
    except ValueError:
        return jsonify({"error": "Year must be a valid integer"}), 400
    except Exception as e:
        logger.error(f"Error checking compatibility: {e}")
        return jsonify({"error": f"Error checking compatibility: {str(e)}"}), 500

# Parts API routes
@app.route('/parts/search', methods=['GET'])
def search_parts():
    """Search for parts across suppliers"""
    query = request.args.get('query')
    make = request.args.get('make')
    model = request.args.get('model')
    year = request.args.get('year')
    suppliers = request.args.get('suppliers')
    
    if not query:
        return jsonify({"error": "Search query is required"}), 400
        
    if suppliers:
        suppliers = suppliers.split(',')
        
    try:
        if year:
            year = int(year)
        result = parts_api.search_part(query, make, model, year, suppliers)
        return jsonify(result)
    except ValueError:
        return jsonify({"error": "Year must be a valid integer"}), 400
    except Exception as e:
        logger.error(f"Error searching parts: {e}")
        return jsonify({"error": f"Error searching parts: {str(e)}"}), 500

@app.route('/parts/details', methods=['GET'])
def get_part_details():
    """Get detailed information about a part"""
    part_id = request.args.get('part_id')
    supplier_id = request.args.get('supplier_id')
    
    if not part_id or not supplier_id:
        return jsonify({"error": "Both part_id and supplier_id are required"}), 400
        
    try:
        result = parts_api.get_part_details(part_id, supplier_id)
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error getting part details: {e}")
        return jsonify({"error": f"Error getting part details: {str(e)}"}), 500

@app.route('/parts/availability', methods=['GET'])
def check_part_availability():
    """Check if a part is available from a supplier"""
    part_id = request.args.get('part_id')
    supplier_id = request.args.get('supplier_id')
    quantity = request.args.get('quantity', '1')
    
    if not part_id or not supplier_id:
        return jsonify({"error": "Both part_id and supplier_id are required"}), 400
        
    try:
        quantity = int(quantity)
        result = parts_api.check_availability(part_id, supplier_id, quantity)
        return jsonify(result)
    except ValueError:
        return jsonify({"error": "Quantity must be a valid integer"}), 400
    except Exception as e:
        logger.error(f"Error checking availability: {e}")
        return jsonify({"error": f"Error checking availability: {str(e)}"}), 500

@app.route('/parts/order', methods=['POST'])
def place_order():
    """Place an order for parts"""
    data = request.json
    
    if not data:
        return jsonify({"error": "No data provided"}), 400
        
    supplier_id = data.get('supplier_id')
    parts = data.get('parts', [])
    shipping_info = data.get('shipping_info', {})
    payment_info = data.get('payment_info', {})
    
    if not supplier_id or not parts or not shipping_info or not payment_info:
        return jsonify({"error": "Missing required order information"}), 400
        
    try:
        result = parts_api.place_order(supplier_id, parts, shipping_info, payment_info)
        
        # Track the order in the monitoring system
        if 'monitoring' in agents:
            agents['monitoring'].monitor_request({
                "type": "order",
                "supplier_id": supplier_id,
                "parts_count": len(parts),
                "status_code": 200,
                "response_time": 1.2  # Simulated response time
            })
            
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error placing order: {e}")
        return jsonify({"error": f"Error placing order: {str(e)}"}), 500

if __name__ == '__main__':
    # Initialize database
    init_db()
    
    # Run the Flask app
    app.run(host='0.0.0.0', port=5000, debug=True)

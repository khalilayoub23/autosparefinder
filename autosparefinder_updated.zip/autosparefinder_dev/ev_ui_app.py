import os
import sys
from flask import Flask, render_template, request, jsonify
from database.ev_knowledge_base import ev_knowledge

# Create Flask app
app = Flask(__name__)

@app.route('/')
def index():
    """Render the main EV interface homepage"""
    return render_template('ev_index.html')

@app.route('/ev/components')
def ev_components():
    """Render the EV components page with data from knowledge base"""
    return render_template('ev_components.html', components=ev_knowledge['components'])

@app.route('/ev/batteries')
def ev_batteries():
    """Render the EV battery types page with data from knowledge base"""
    return render_template('ev_batteries.html', batteries=ev_knowledge['battery_types'])

@app.route('/ev/charging')
def ev_charging():
    """Render the EV charging standards page with data from knowledge base"""
    return render_template('ev_charging.html', charging_standards=ev_knowledge['charging_standards'])

@app.route('/ev/maintenance')
def ev_maintenance():
    """Render the EV maintenance tips page with data from knowledge base"""
    return render_template('ev_maintenance.html', maintenance_tips=ev_knowledge['maintenance_tips'])

@app.route('/ev/manufacturers')
def ev_manufacturers():
    """Render the EV manufacturers page with data from knowledge base"""
    return render_template('ev_manufacturers.html', manufacturers=ev_knowledge['manufacturers'])

@app.route('/ev/compatibility')
def ev_compatibility():
    """Render the EV parts compatibility checker page"""
    return render_template('ev_compatibility.html')

@app.route('/api/ev/check_compatibility', methods=['POST'])
def check_compatibility():
    """API endpoint to check compatibility of a part with a vehicle"""
    data = request.json
    
    # Extract request data
    manufacturer = data.get('manufacturer')
    model = data.get('model')
    year = data.get('year')
    battery_type = data.get('battery_type')
    part_category = data.get('part_category')
    part_number = data.get('part_number')
    
    # Call compatibility checking logic
    # This would normally call a more complex function from another module
    from database.parts_catalog_db import check_part_compatibility
    result = check_part_compatibility(
        manufacturer=manufacturer,
        model=model,
        year=year,
        battery_type=battery_type,
        part_category=part_category,
        part_number=part_number
    )
    
    return jsonify(result)

@app.route('/api/ev/knowledge/<category>')
def get_knowledge(category):
    """API endpoint to get knowledge base data by category"""
    if category in ev_knowledge:
        return jsonify(ev_knowledge[category])
    else:
        return jsonify({"error": "Category not found"}), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

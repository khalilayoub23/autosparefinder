import logging
import os
import json
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class SystemIntegrationManager:
    """
    Manager for integrating all system components: agents, catalog, CRM, and order management
    """
    
    def __init__(self, config=None):
        """
        Initialize the system integration manager
        
        Args:
            config (dict, optional): Configuration parameters
        """
        self.config = config or {}
        self.agent_manager = None
        self.catalog_db = None
        self.crm_interface = None
        self.order_system = None
        self.vehicle_data_manager = None
        
        # Initialize components
        self._initialize_components()
        
        logger.info("System Integration Manager initialized")
    
    def _initialize_components(self):
        """Initialize all system components"""
        try:
            # Import required modules
            from agents.agent_factory import AgentFactory
            from database.parts_catalog_db import PartsCatalogDatabase
            from api.crm_interface import CRMInterface
            from database.order_management_system import OrderManagementSystem
            from api.hybrid_vehicle_data_manager import HybridVehicleDataManager
            
            # Initialize agent factory
            self.agent_factory = AgentFactory()
            logger.info("Agent Factory initialized")
            
            # Initialize catalog database
            catalog_config = self.config.get('catalog', {})
            self.catalog_db = PartsCatalogDatabase(catalog_config.get('db_path'))
            logger.info("Parts Catalog Database initialized")
            
            # Initialize CRM interface
            crm_config = self.config.get('crm', {})
            self.crm_interface = CRMInterface(
                crm_type=crm_config.get('type', 'generic'),
                config=crm_config
            )
            logger.info(f"CRM Interface initialized for {crm_config.get('type', 'generic')} CRM")
            
            # Initialize order management system
            order_config = self.config.get('order_system', {})
            order_config['crm_interface'] = self.crm_interface  # Pass CRM interface to order system
            self.order_system = OrderManagementSystem(order_config)
            logger.info("Order Management System initialized")
            
            # Initialize vehicle data manager
            vehicle_config = self.config.get('vehicle_data', {})
            self.vehicle_data_manager = HybridVehicleDataManager(vehicle_config)
            logger.info("Hybrid Vehicle Data Manager initialized")
            
            # Create and initialize agents
            self._initialize_agents()
            
        except Exception as e:
            logger.error(f"Error initializing system components: {e}")
            raise
    
    def _initialize_agents(self):
        """Initialize all required agents"""
        try:
            # Create agents dictionary
            self.agents = {}
            
            # Create quality control agent (Ido)
            quality_config = self.config.get('quality_agent', {})
            quality_agent = self.agent_factory.create_agent(
                'quality_control',
                name='Ido',
                config=quality_config
            )
            self.agents['quality_control'] = quality_agent
            logger.info("Quality Control Agent (Ido) initialized")
            
            # Create monitoring agent (Shira)
            monitoring_config = self.config.get('monitoring_agent', {})
            monitoring_agent = self.agent_factory.create_agent(
                'monitoring',
                name='Shira',
                config=monitoring_config
            )
            self.agents['monitoring'] = monitoring_agent
            logger.info("Monitoring Agent (Shira) initialized")
            
            # Create sales agent
            sales_config = self.config.get('sales_agent', {})
            sales_agent = self.agent_factory.create_agent(
                'sales',
                config=sales_config
            )
            self.agents['sales'] = sales_agent
            logger.info("Sales Agent initialized")
            
            # Create order agent
            order_config = self.config.get('order_agent', {})
            order_agent = self.agent_factory.create_agent(
                'order',
                config=order_config
            )
            self.agents['order'] = order_agent
            logger.info("Order Agent initialized")
            
            # Create technical support agent
            tech_config = self.config.get('technical_support_agent', {})
            tech_agent = self.agent_factory.create_agent(
                'technical_support',
                config=tech_config
            )
            self.agents['technical_support'] = tech_agent
            logger.info("Technical Support Agent initialized")
            
        except Exception as e:
            logger.error(f"Error initializing agents: {e}")
            raise
    
    def process_request(self, request_data):
        """
        Process a system request by routing to appropriate components
        
        Args:
            request_data (dict): Request data
            
        Returns:
            dict: Processing result
        """
        try:
            request_type = request_data.get('request_type', '')
            
            if not request_type:
                return {'status': 'error', 'message': 'No request type specified'}
            
            # Route to appropriate component based on request type
            if request_type.startswith('agent_'):
                return self._process_agent_request(request_data)
            elif request_type.startswith('catalog_'):
                return self._process_catalog_request(request_data)
            elif request_type.startswith('order_'):
                return self._process_order_request(request_data)
            elif request_type.startswith('vehicle_'):
                return self._process_vehicle_request(request_data)
            elif request_type.startswith('crm_'):
                return self._process_crm_request(request_data)
            else:
                logger.warning(f"Unknown request type: {request_type}")
                return {'status': 'error', 'message': f'Unknown request type: {request_type}'}
            
        except Exception as e:
            logger.error(f"Error processing request: {e}")
            return {'status': 'error', 'message': str(e)}
    
    def _process_agent_request(self, request_data):
        """
        Process an agent-related request
        
        Args:
            request_data (dict): Request data
            
        Returns:
            dict: Processing result
        """
        agent_type = request_data.get('agent_type', '')
        action = request_data.get('action', '')
        
        if not agent_type or not action:
            return {'status': 'error', 'message': 'Agent type and action are required'}
        
        # Get the requested agent
        agent = self.agents.get(agent_type)
        if not agent:
            return {'status': 'error', 'message': f'Unknown agent type: {agent_type}'}
        
        # Process the action
        if action == 'process':
            # Extract input data for the agent
            input_data = request_data.get('input_data', {})
            
            # Process the input with the agent
            result = agent.process(input_data)
            return {'status': 'success', 'result': result}
        elif action == 'get_info':
            # Get agent information
            info = agent.get_info()
            return {'status': 'success', 'agent_info': info}
        else:
            return {'status': 'error', 'message': f'Unknown action: {action}'}
    
    def _process_catalog_request(self, request_data):
        """
        Process a catalog-related request
        
        Args:
            request_data (dict): Request data
            
        Returns:
            dict: Processing result
        """
        action = request_data.get('action', '')
        
        if not action:
            return {'status': 'error', 'message': 'Action is required'}
        
        # Process the action
        if action == 'search':
            # Extract search parameters
            query = request_data.get('query', '')
            category = request_data.get('category', None)
            make = request_data.get('make', None)
            model = request_data.get('model', None)
            year = request_data.get('year', None)
            
            # Search the catalog
            results = self.catalog_db.search_parts(query, category, make, model, year)
            return {'status': 'success', 'results': results}
        elif action == 'get_part':
            # Extract part identifier
            part_id = request_data.get('part_id')
            catalog_number = request_data.get('catalog_number')
            
            if not part_id and not catalog_number:
                return {'status': 'error', 'message': 'Part ID or catalog number is required'}
            
            # Get the part
            part = self.catalog_db.get_part(part_id, catalog_number)
            
            if not part:
                return {'status': 'error', 'message': 'Part not found'}
            
            return {'status': 'success', 'part': part}
        elif action == 'add_part':
            # Extract part data
            part_data = request_data.get('part_data', {})
            
            if not part_data:
                return {'status': 'error', 'message': 'Part data is required'}
            
            # Add the part
            part_id = self.catalog_db.add_part(part_data)
            return {'status': 'success', 'part_id': part_id}
        else:
            return {'status': 'error', 'message': f'Unknown action: {action}'}
    
    def _process_order_request(self, request_data):
        """
        Process an order-related request
        
        Args:
            request_data (dict): Request data
            
        Returns:
            dict: Processing result
        """
        action = request_data.get('action', '')
        
        if not action:
            return {'status': 'error', 'message': 'Action is required'}
        
        # Process the action
        if action == 'create':
            # Extract order data
            order_data = request_data.get('order_data', {})
            
            if not order_data:
                return {'status': 'error', 'message': 'Order data is required'}
            
            # Create the order
            result = self.order_system.create_order(order_data)
            return result
        elif action == 'get':
            # Extract order ID
            order_id = request_data.get('order_id', '')
            
            if not order_id:
                return {'status': 'error', 'message': 'Order ID is required'}
            
            # Get the order
            result = self.order_system.get_order(order_id)
            return result
        elif action == 'update_status':
            # Extract order ID and status
            order_id = request_data.get('order_id', '')
            status = request_data.get('status', '')
            
            if not order_id or not status:
                return {'status': 'error', 'message': 'Order ID and status are required'}
            
            # Update the order status
            result = self.order_system.update_order_status(order_id, status)
            return result
        elif action == 'cancel':
            # Extract order ID
            order_id = request_data.get('order_id', '')
            
            if not order_id:
                return {'status': 'error', 'message': 'Order ID is required'}
            
            # Cancel the order
            result = self.order_system.cancel_order(order_id)
            return result
        elif action == 'get_customer_orders':
            # Extract customer ID
            customer_id = request_data.get('customer_id', '')
            
            if not customer_id:
                return {'status': 'error', 'message': 'Customer ID is required'}
            
            # Get customer orders
            result = self.order_system.get_customer_orders(customer_id)
            return result
        else:
            return {'status': 'error', 'message': f'Unknown action: {action}'}
    
    def _process_vehicle_request(self, request_data):
        """
        Process a vehicle-related request
        
        Args:
            request_data (dict): Request data
            
        Returns:
            dict: Processing result
        """
        action = request_data.get('action', '')
        
        if not action:
            return {'status': 'error', 'message': 'Action is required'}
        
        # Process the action
        if action == 'get_by_license':
            # Extract license plate
            license_plate = request_data.get('license_plate', '')
            
            if not license_plate:
                return {'status': 'error', 'message': 'License plate is required'}
            
            # Get vehicle data
            vehicle_data = self.vehicle_data_manager.get_vehicle_by_license(license_plate)
            
            if not vehicle_data:
                return {'status': 'error', 'message': 'Vehicle not found'}
            
            return {'status': 'success', 'vehicle': vehicle_data}
        elif action == 'check_compatibility':
            # Extract part ID and vehicle info
            part_id = request_data.get('part_id', '')
            license_plate = request_data.get('license_plate', '')
            
            if not part_id:
                return {'status': 'error', 'message': 'Part ID is required'}
            
            if not license_plate:
                return {'status': 'error', 'message': 'License plate is required'}
            
            # Get vehicle data
            vehicle_data = self.vehicle_data_manager.get_vehicle_by_license(license_plate)
            
            if not vehicle_data:
                return {'status': 'error', 'message': 'Vehicle not found'}
            
            # Get part data
            part = self.catalog_db.get_part(part_id)
            
            if not part:
                return {'status': 'error', 'message': 'Part not found'}
            
            # Check compatibility
            compatible = False
            confidence = 0
            notes = "No compatibility information available"
            
            # Check if we have compatibility information for this part
            if 'compatibility' in part:
                for compat in part['compatibility']:
                    if (compat.get('make', '').lower() == vehicle_data.get('make', '').lower() and
                        compat.get('model', '').lower() == vehicle_data.get('model', '').lower()):
                        
                        # Check year range if available
                        if 'year' in vehicle_data and compat.get('year_from') and compat.get('year_to'):
                            try:
                                year = int(vehicle_data['year'])
                                year_from = int(compat.get('year_from', 0))
                                year_to = int(compat.get('year_to', 9999))
                                
                                if year_from <= year <= year_to:
                                    compatible = True
                                    confidence = 95
                                    notes = compat.get('notes', 'Compatible based on manufacturer data')
                                else:
                                    compatible = False
                                    confidence = 80
                                    notes = f"This part is designed for {vehicle_data['make']} {vehicle_data['model']} models from {year_from} to {year_to}"
                            except (ValueError, TypeError):
                                # If year conversion fails, fall back to make/model only
                                compatible = True
                                confidence = 70
                                notes = "Compatible based on make and model, but year information could not be verified"
                        else:
                            # If no year information, match based on make/model only
                            compatible = True
                            confidence = 80
                            notes = "Compatible based on make and model"
                        
                        # Once we find a matching rule, we can break
                        break
            
            return {
                'status': 'success',
                'compatible': compatible,
                'confidence': confidence,
                'notes': notes,
                'part': {
                    'part_id': part['part_id'],
                    'name': part['name']
                },
                'vehicle': vehicle_data
            }
        else:
            return {'status': 'error', 'message': f'Unknown action: {action}'}
    
    def _process_crm_request(self, request_data):
        """
        Process a CRM-related request
        
        Args:
            request_data (dict): Request data
            
        Returns:
            dict: Processing result
        """
        action = request_data.get('action', '')
        
        if not action:
            return {'status': 'error', 'message': 'Action is required'}
        
        # Process the action
        if action == 'create_customer':
            # Extract customer data
            customer_data = request_data.get('customer_data', {})
            
            if not customer_data:
                return {'status': 'error', 'message': 'Customer data is required'}
            
            # Create the customer
            result = self.crm_interface.create_customer(customer_data)
            return result
        elif action == 'get_customer':
            # Extract customer ID
            customer_id = request_data.get('customer_id', '')
            
            if not customer_id:
                return {'status': 'error', 'message': 'Customer ID is required'}
            
            # Get the customer
            result = self.crm_interface.get_customer(customer_id)
            return result
        elif action == 'search_customers':
            # Extract search query
            query = request_data.get('query', '')
            
            if not query:
                return {'status': 'error', 'message': 'Search query is required'}
            
            # Search for customers
            result = self.crm_interface.search_customers(query)
            return {'status': 'success', 'customers': result}
        else:
            return {'status': 'error', 'message': f'Unknown action: {action}'}
    
    def get_system_status(self):
        """
        Get the status of all system components
        
        Returns:
            dict: System status
        """
        try:
            status = {
                'timestamp': datetime.now().isoformat(),
                'components': {
                    'agents': {},
                    'catalog': 'active' if self.catalog_db else 'inactive',
                    'crm': 'active' if self.crm_interface else 'inactive',
                    'order_system': 'active' if self.order_system else 'inactive',
                    'vehicle_data': 'active' if self.vehicle_data_manager else 'inactive'
                }
            }
            
            # Get status of all agents
            for agent_type, agent in self.agents.items():
                status['components']['agents'][agent_type] = agent.status
            
            return {'status': 'success', 'system_status': status}
            
        except Exception as e:
            logger.error(f"Error getting system status: {e}")
            return {'status': 'error', 'message': str(e)}

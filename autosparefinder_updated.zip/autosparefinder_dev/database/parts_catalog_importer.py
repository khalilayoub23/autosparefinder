import logging
import sqlite3
import json
import os
import pandas as pd
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class PartsCatalogImporter:
    """
    Utility for importing parts catalog data from various file formats
    """
    
    def __init__(self, db_path=None):
        """
        Initialize the parts catalog importer
        
        Args:
            db_path (str, optional): Path to the SQLite database file
        """
        if db_path is None:
            # Use default path in the project directory
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            db_path = os.path.join(base_dir, 'data', 'parts_catalog.db')
            
            # Ensure the directory exists
            os.makedirs(os.path.dirname(db_path), exist_ok=True)
        
        self.db_path = db_path
        self.conn = None
        self.cursor = None
        
        logger.info(f"Parts Catalog Importer initialized with database at {db_path}")
    
    def _connect_db(self):
        """Connect to the database"""
        try:
            self.conn = sqlite3.connect(self.db_path)
            self.cursor = self.conn.cursor()
            logger.info("Connected to database")
        except Exception as e:
            logger.error(f"Error connecting to database: {e}")
            raise
    
    def _disconnect_db(self):
        """Disconnect from the database"""
        if self.conn:
            self.conn.close()
            self.conn = None
            self.cursor = None
            logger.info("Disconnected from database")
    
    def import_from_csv(self, csv_path, mapping=None):
        """
        Import parts catalog data from a CSV file
        
        Args:
            csv_path (str): Path to the CSV file
            mapping (dict, optional): Mapping of CSV columns to database fields
            
        Returns:
            dict: Import statistics
        """
        try:
            logger.info(f"Importing parts catalog data from CSV: {csv_path}")
            
            # Read the CSV file
            df = pd.read_csv(csv_path)
            logger.info(f"Read {len(df)} rows from CSV")
            
            # Apply mapping if provided
            if mapping:
                df = df.rename(columns=mapping)
            
            # Connect to the database
            self._connect_db()
            
            # Import the data
            imported_count = 0
            error_count = 0
            
            for _, row in df.iterrows():
                try:
                    # Convert row to dict
                    part_data = row.to_dict()
                    
                    # Insert into parts table
                    self._insert_part(part_data)
                    
                    imported_count += 1
                except Exception as e:
                    logger.error(f"Error importing row: {e}")
                    error_count += 1
            
            # Commit the changes
            self.conn.commit()
            
            logger.info(f"Imported {imported_count} parts, {error_count} errors")
            
            return {
                'status': 'success',
                'imported_count': imported_count,
                'error_count': error_count,
                'total_rows': len(df)
            }
            
        except Exception as e:
            logger.error(f"Error importing from CSV: {e}")
            if self.conn:
                self.conn.rollback()
            return {
                'status': 'error',
                'message': str(e)
            }
        finally:
            self._disconnect_db()
    
    def import_from_excel(self, excel_path, sheet_name=0, mapping=None):
        """
        Import parts catalog data from an Excel file
        
        Args:
            excel_path (str): Path to the Excel file
            sheet_name (str or int, optional): Name or index of the sheet to import
            mapping (dict, optional): Mapping of Excel columns to database fields
            
        Returns:
            dict: Import statistics
        """
        try:
            logger.info(f"Importing parts catalog data from Excel: {excel_path}, sheet: {sheet_name}")
            
            # Read the Excel file
            df = pd.read_excel(excel_path, sheet_name=sheet_name)
            logger.info(f"Read {len(df)} rows from Excel")
            
            # Apply mapping if provided
            if mapping:
                df = df.rename(columns=mapping)
            
            # Connect to the database
            self._connect_db()
            
            # Import the data
            imported_count = 0
            error_count = 0
            
            for _, row in df.iterrows():
                try:
                    # Convert row to dict
                    part_data = row.to_dict()
                    
                    # Insert into parts table
                    self._insert_part(part_data)
                    
                    imported_count += 1
                except Exception as e:
                    logger.error(f"Error importing row: {e}")
                    error_count += 1
            
            # Commit the changes
            self.conn.commit()
            
            logger.info(f"Imported {imported_count} parts, {error_count} errors")
            
            return {
                'status': 'success',
                'imported_count': imported_count,
                'error_count': error_count,
                'total_rows': len(df)
            }
            
        except Exception as e:
            logger.error(f"Error importing from Excel: {e}")
            if self.conn:
                self.conn.rollback()
            return {
                'status': 'error',
                'message': str(e)
            }
        finally:
            self._disconnect_db()
    
    def import_from_json(self, json_path):
        """
        Import parts catalog data from a JSON file
        
        Args:
            json_path (str): Path to the JSON file
            
        Returns:
            dict: Import statistics
        """
        try:
            logger.info(f"Importing parts catalog data from JSON: {json_path}")
            
            # Read the JSON file
            with open(json_path, 'r') as f:
                data = json.load(f)
            
            # Check if it's a list of parts or a single part
            if isinstance(data, dict):
                parts = [data]
            elif isinstance(data, list):
                parts = data
            else:
                raise ValueError("Invalid JSON format. Expected a list of parts or a single part object.")
            
            logger.info(f"Read {len(parts)} parts from JSON")
            
            # Connect to the database
            self._connect_db()
            
            # Import the data
            imported_count = 0
            error_count = 0
            
            for part_data in parts:
                try:
                    # Insert into parts table
                    self._insert_part(part_data)
                    
                    imported_count += 1
                except Exception as e:
                    logger.error(f"Error importing part: {e}")
                    error_count += 1
            
            # Commit the changes
            self.conn.commit()
            
            logger.info(f"Imported {imported_count} parts, {error_count} errors")
            
            return {
                'status': 'success',
                'imported_count': imported_count,
                'error_count': error_count,
                'total_parts': len(parts)
            }
            
        except Exception as e:
            logger.error(f"Error importing from JSON: {e}")
            if self.conn:
                self.conn.rollback()
            return {
                'status': 'error',
                'message': str(e)
            }
        finally:
            self._disconnect_db()
    
    def _insert_part(self, part_data):
        """
        Insert a part into the database
        
        Args:
            part_data (dict): Part information
            
        Returns:
            str: Part ID of the inserted part
        """
        # Extract core part data
        part_id = part_data.get('part_id')
        if not part_id:
            # Generate a unique ID if not provided
            part_id = f"P{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        catalog_number = part_data.get('catalog_number', '')
        name = part_data.get('name')
        if not name:
            raise ValueError("Part name is required")
        
        description = part_data.get('description', '')
        category = part_data.get('category', '')
        subcategory = part_data.get('subcategory', '')
        manufacturer = part_data.get('manufacturer', '')
        weight = part_data.get('weight', 0)
        dimensions = part_data.get('dimensions', '')
        
        # Insert into parts table
        self.cursor.execute('''
        INSERT OR REPLACE INTO parts 
        (part_id, catalog_number, name, description, category, subcategory, 
         manufacturer, weight, dimensions, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        ''', (part_id, catalog_number, name, description, category, subcategory, 
              manufacturer, weight, dimensions))
        
        # Extract and insert additional details
        details = part_data.get('details', {})
        for key, value in details.items():
            self.cursor.execute('''
            INSERT OR REPLACE INTO part_details (part_id, key, value)
            VALUES (?, ?, ?)
            ''', (part_id, key, str(value)))
        
        # Extract and insert vehicle compatibility
        compatibility = part_data.get('compatibility', [])
        for compat in compatibility:
            make = compat.get('make', '')
            model = compat.get('model', '')
            year_from = compat.get('year_from', 0)
            year_to = compat.get('year_to', 9999)
            engine_type = compat.get('engine_type', '')
            notes = compat.get('notes', '')
            
            self.cursor.execute('''
            INSERT INTO vehicle_compatibility 
            (part_id, make, model, year_from, year_to, engine_type, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (part_id, make, model, year_from, year_to, engine_type, notes))
        
        # Extract and insert inventory information
        inventory = part_data.get('inventory', {})
        if inventory:
            quantity = inventory.get('quantity', 0)
            price = inventory.get('price', 0)
            cost = inventory.get('cost', 0)
            supplier = inventory.get('supplier', '')
            location = inventory.get('location', '')
            
            self.cursor.execute('''
            INSERT OR REPLACE INTO inventory 
            (part_id, quantity, price, cost, supplier, location, last_updated)
            VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ''', (part_id, quantity, price, cost, supplier, location))
        
        # Extract and insert image paths
        images = part_data.get('images', [])
        for img in images:
            image_path = img.get('path', '')
            is_primary = img.get('is_primary', 0)
            description = img.get('description', '')
            
            if image_path:
                self.cursor.execute('''
                INSERT INTO part_images (part_id, image_path, is_primary, description)
                VALUES (?, ?, ?, ?)
                ''', (part_id, image_path, is_primary, description))
        
        return part_id

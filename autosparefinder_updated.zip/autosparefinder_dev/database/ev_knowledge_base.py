"""
Electric Vehicle Knowledge Base Module

This module provides comprehensive information about electric vehicle components,
battery technologies, charging standards, and maintenance best practices.

The knowledge is structured for easy integration with the AutoSpareFinder system
and can be accessed through the knowledge base API.
"""

import logging
import json
import os
import sqlite3
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class EVKnowledgeBase:
    """Electric Vehicle Knowledge Base class for managing EV-related information"""
    
    def __init__(self, db_path=None):
        """Initialize the knowledge base with the database connection"""
        if db_path is None:
            # Default to the main database path
            self.db_path = '/home/ubuntu/autosparefinder_dev/database/parts_catalog.db'
        else:
            self.db_path = db_path
        
        self._ensure_tables_exist()
        logger.info(f"EV Knowledge Base initialized with database at {self.db_path}")
    
    def _ensure_tables_exist(self):
        """Ensure that all required tables exist in the database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create knowledge_base table if it doesn't exist
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS knowledge_base (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT NOT NULL,
            key TEXT NOT NULL,
            value TEXT NOT NULL,
            source TEXT,
            last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(category, key)
        )
        ''')
        
        conn.commit()
        conn.close()
    
    def add_knowledge(self, category, key, value, source=None):
        """Add or update a knowledge entry in the database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if entry already exists
        cursor.execute(
            "SELECT id FROM knowledge_base WHERE category = ? AND key = ?",
            (category, key)
        )
        existing = cursor.fetchone()
        
        if existing:
            # Update existing entry
            cursor.execute(
                "UPDATE knowledge_base SET value = ?, source = ?, last_updated = CURRENT_TIMESTAMP WHERE id = ?",
                (json.dumps(value) if isinstance(value, (dict, list)) else value, source, existing[0])
            )
            logger.info(f"Updated knowledge entry: {category}/{key}")
        else:
            # Insert new entry
            cursor.execute(
                "INSERT INTO knowledge_base (category, key, value, source) VALUES (?, ?, ?, ?)",
                (category, key, json.dumps(value) if isinstance(value, (dict, list)) else value, source)
            )
            logger.info(f"Added new knowledge entry: {category}/{key}")
        
        conn.commit()
        conn.close()
    
    def get_knowledge(self, category, key=None):
        """Retrieve knowledge from the database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if key is None:
            # Get all entries in the category
            cursor.execute(
                "SELECT key, value, source, last_updated FROM knowledge_base WHERE category = ?",
                (category,)
            )
            results = cursor.fetchall()
            
            knowledge = {}
            for row in results:
                k, v, src, updated = row
                try:
                    # Try to parse as JSON if possible
                    v = json.loads(v)
                except (json.JSONDecodeError, TypeError):
                    # Keep as is if not JSON
                    pass
                knowledge[k] = {
                    "value": v,
                    "source": src,
                    "last_updated": updated
                }
        else:
            # Get specific entry
            cursor.execute(
                "SELECT value, source, last_updated FROM knowledge_base WHERE category = ? AND key = ?",
                (category, key)
            )
            result = cursor.fetchone()
            
            if result:
                v, src, updated = result
                try:
                    # Try to parse as JSON if possible
                    v = json.loads(v)
                except (json.JSONDecodeError, TypeError):
                    # Keep as is if not JSON
                    pass
                knowledge = {
                    "value": v,
                    "source": src,
                    "last_updated": updated
                }
            else:
                knowledge = None
        
        conn.close()
        return knowledge
    
    def delete_knowledge(self, category, key=None):
        """Delete knowledge from the database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if key is None:
            # Delete all entries in the category
            cursor.execute(
                "DELETE FROM knowledge_base WHERE category = ?",
                (category,)
            )
            logger.info(f"Deleted all knowledge entries in category: {category}")
        else:
            # Delete specific entry
            cursor.execute(
                "DELETE FROM knowledge_base WHERE category = ? AND key = ?",
                (category, key)
            )
            logger.info(f"Deleted knowledge entry: {category}/{key}")
        
        conn.commit()
        conn.close()
    
    def populate_ev_components(self):
        """Populate the knowledge base with information about EV components"""
        components = {
            "battery_pack": {
                "description": "The traction battery pack stores electricity for use by the electric traction motor. It's typically located along the underside of the vehicle and composed of many interconnected cells.",
                "function": "Stores electrical energy to power the vehicle's propulsion system.",
                "types": ["Lithium-ion (NMC)", "Lithium-ion (LFP)", "Solid-state (emerging)"],
                "maintenance": "Generally maintenance-free, but requires thermal management and state-of-charge monitoring.",
                "source": "Alternative Fuels Data Center, U.S. Department of Energy"
            },
            "electric_traction_motor": {
                "description": "Using power from the traction battery pack, this motor drives the vehicle's wheels. Some vehicles use motor generators that perform both the drive and regeneration functions.",
                "function": "Converts electrical energy from the battery into mechanical energy to propel the vehicle.",
                "types": ["Permanent Magnet Synchronous Motor (PMSM)", "Induction Motor", "Switched Reluctance Motor"],
                "maintenance": "Generally maintenance-free with fewer moving parts than internal combustion engines.",
                "source": "Alternative Fuels Data Center, U.S. Department of Energy"
            },
            "power_electronics_controller": {
                "description": "This unit manages the flow of electrical energy delivered by the traction battery, controlling the speed of the electric traction motor and the torque it produces.",
                "function": "Controls power flow between the battery and motor, manages regenerative braking.",
                "components": ["Inverter", "DC-DC Converter", "Motor Controller"],
                "maintenance": "No regular maintenance required, but critical for vehicle performance and efficiency.",
                "source": "Alternative Fuels Data Center, U.S. Department of Energy"
            },
            "onboard_charger": {
                "description": "Takes the incoming AC electricity supplied via the charge port and converts it to DC power for charging the traction battery. It also communicates with the charging equipment and monitors battery characteristics such as voltage, current, temperature, and state of charge while charging the pack.",
                "function": "Converts AC power from external charging sources to DC power for the battery.",
                "types": ["Level 1 (120V)", "Level 2 (240V)", "DC Fast Charging Compatible"],
                "maintenance": "No regular maintenance required, but critical for charging functionality.",
                "source": "Alternative Fuels Data Center, U.S. Department of Energy"
            },
            "charge_port": {
                "description": "The charge port allows the vehicle to connect to an external power supply in order to charge the traction battery pack.",
                "function": "Provides connection point for external charging equipment.",
                "standards": ["J1772 (North America)", "CCS Combo", "CHAdeMO", "Tesla"],
                "maintenance": "Keep clean and protected from elements, inspect regularly for damage.",
                "source": "Alternative Fuels Data Center, U.S. Department of Energy"
            },
            "thermal_system": {
                "description": "This system maintains a proper operating temperature range of the engine, electric motor, power electronics, and other components.",
                "function": "Regulates temperature of battery, motor, and electronics for optimal performance and longevity.",
                "components": ["Cooling Loops", "Radiators", "Heat Exchangers", "Heat Pumps"],
                "maintenance": "Check coolant levels and condition regularly, inspect for leaks.",
                "source": "Alternative Fuels Data Center, U.S. Department of Energy"
            },
            "dc_dc_converter": {
                "description": "This device converts higher-voltage DC power from the traction battery pack to the lower-voltage DC power needed to run vehicle accessories and recharge the auxiliary battery.",
                "function": "Converts high-voltage DC from the main battery to low-voltage DC for vehicle systems.",
                "importance": "Critical for powering vehicle electronics, lights, and infotainment systems.",
                "maintenance": "No regular maintenance required.",
                "source": "Alternative Fuels Data Center, U.S. Department of Energy"
            },
            "auxiliary_battery": {
                "description": "In an electric drive vehicle, the auxiliary battery provides electricity to power vehicle accessories.",
                "function": "Powers vehicle accessories and systems when the main battery is disconnected.",
                "type": "Usually 12V lead-acid or lithium-ion.",
                "maintenance": "Similar to conventional vehicle batteries, may require replacement every 3-5 years.",
                "source": "Alternative Fuels Data Center, U.S. Department of Energy"
            },
            "transmission": {
                "description": "The transmission transfers mechanical power from the electric traction motor to drive the wheels.",
                "function": "Transfers power from motor to wheels, often with a single-speed reduction gear.",
                "types": ["Single-speed", "Multi-speed (less common)"],
                "maintenance": "Generally maintenance-free with fewer components than conventional transmissions.",
                "source": "Alternative Fuels Data Center, U.S. Department of Energy"
            }
        }
        
        for key, value in components.items():
            self.add_knowledge("ev_components", key, value, value.get("source"))
        
        logger.info(f"Populated knowledge base with {len(components)} EV component entries")
    
    def populate_battery_types(self):
        """Populate the knowledge base with information about EV battery types"""
        battery_types = {
            "lithium_ion_nmc": {
                "full_name": "Lithium Nickel Manganese Cobalt Oxide (NMC)",
                "description": "Lithium nickel manganese cobalt (NMC) chemistries are the most common lithium-ion batteries used in EVs. They offer high energy density and good power performance.",
                "pros": [
                    "High energy density (200-250 Wh/kg)",
                    "Good power performance",
                    "Established technology with proven track record",
                    "Balanced performance characteristics"
                ],
                "cons": [
                    "Contains cobalt, which has supply chain and ethical concerns",
                    "More expensive than LFP batteries",
                    "Thermal runaway concerns at high temperatures",
                    "Typically limited to 1000-2000 charge cycles"
                ],
                "manufacturers_using": ["Tesla", "Volkswagen", "BMW", "Hyundai", "Kia", "Audi"],
                "typical_range": "250-350 miles depending on battery size",
                "source": "Drive Electric Vermont, McKinsey"
            },
            "lithium_ion_lfp": {
                "full_name": "Lithium Iron Phosphate (LFP)",
                "description": "Lithium iron phosphate (LFP) batteries are gaining in popularity due to their lower cost and reduced use of cobalt. They offer excellent safety and longevity but with lower energy density than NMC.",
                "pros": [
                    "Lower cost than NMC batteries",
                    "No cobalt content (more ethical supply chain)",
                    "Excellent thermal stability and safety",
                    "Longer cycle life (3000+ cycles)",
                    "Can be charged to 100% regularly without significant degradation"
                ],
                "cons": [
                    "Lower energy density (140-160 Wh/kg)",
                    "Reduced range compared to NMC with same weight",
                    "Poorer cold-weather performance",
                    "Voltage sag as battery depletes"
                ],
                "manufacturers_using": ["Tesla (standard range models)", "BYD", "VinFast", "Rivian (standard range)"],
                "typical_range": "200-280 miles depending on battery size",
                "source": "Drive Electric Vermont, Electrifying.com"
            },
            "solid_state": {
                "full_name": "Solid-State Battery",
                "description": "Solid-state batteries replace the liquid electrolyte found in conventional lithium-ion batteries with a solid material. This emerging technology promises significant improvements in energy density, safety, and charging speed.",
                "pros": [
                    "Higher energy density (potentially 400+ Wh/kg)",
                    "Faster charging capabilities",
                    "Improved safety (no flammable liquid electrolyte)",
                    "Longer lifespan",
                    "Better temperature performance"
                ],
                "cons": [
                    "Still in development/early production phase",
                    "Currently very expensive to produce",
                    "Manufacturing challenges at scale",
                    "Limited real-world performance data"
                ],
                "manufacturers_developing": ["Toyota", "Volkswagen (with QuantumScape)", "BMW", "Ford", "Hyundai"],
                "expected_commercialization": "2025-2028 for early commercial applications",
                "source": "Drive Electric Vermont, Laserax"
            },
            "lithium_ion_nca": {
                "full_name": "Lithium Nickel Cobalt Aluminum Oxide (NCA)",
                "description": "Lithium nickel cobalt aluminum oxide (NCA) batteries offer high energy density and long life spans but contain cobalt and have some safety concerns.",
                "pros": [
                    "Very high energy density (220-260 Wh/kg)",
                    "Long lifespan",
                    "Good high-temperature performance"
                ],
                "cons": [
                    "Contains cobalt (though less than NMC)",
                    "Higher cost",
                    "Some safety concerns at high temperatures"
                ],
                "manufacturers_using": ["Tesla (older models)", "Lucid Motors"],
                "typical_range": "300-400+ miles depending on battery size",
                "source": "Zecar, Battery University"
            },
            "lithium_ion_lmo": {
                "full_name": "Lithium Manganese Oxide (LMO)",
                "description": "Lithium manganese oxide (LMO) batteries offer good thermal stability and safety but lower energy density than other lithium-ion variants.",
                "pros": [
                    "Good thermal stability",
                    "Enhanced safety",
                    "Lower cost than NMC/NCA",
                    "No cobalt content"
                ],
                "cons": [
                    "Lower energy density (140-180 Wh/kg)",
                    "Shorter cycle life",
                    "Limited use in modern EVs"
                ],
                "manufacturers_using": ["Early Nissan Leaf models", "Some hybrid vehicles"],
                "typical_range": "80-150 miles depending on battery size",
                "source": "Battery University"
            }
        }
        
        for key, value in battery_types.items():
            self.add_knowledge("ev_battery_types", key, value, value.get("source"))
        
        logger.info(f"Populated knowledge base with {len(battery_types)} EV battery type entries")
    
    def populate_charging_standards(self):
        """Populate the knowledge base with information about EV charging standards"""
        charging_standards = {
            "j1772": {
                "full_name": "SAE J1772",
                "description": "The standard North American connector for Level 1 and Level 2 AC charging, capable of delivering up to 19.2 kW (80A at 240V), though most home chargers operate at 7.2-11.5 kW (30-48A).",
                "compatibility": "All electric vehicles in North America can use J1772 either directly or with an adapter (Tesla).",
                "charging_levels": ["Level 1 (120V, 1.4-1.9 kW)", "Level 2 (240V, up to 19.2 kW)"],
                "typical_charging_rate": "3-30 miles of range per hour depending on vehicle and charger capacity",
                "source": "SAE International, Drive Electric Vermont"
            },
            "ccs_combo": {
                "full_name": "Combined Charging System (CCS)",
                "description": "CCS combines the J1772 AC connector with additional DC pins for fast charging. It's the dominant DC fast charging standard in North America and Europe.",
                "compatibility": "Most non-Tesla EVs in North America and Europe; Tesla vehicles can use CCS with an adapter.",
                "charging_levels": ["Level 2 AC (via J1772 portion)", "DC Fast Charging (up to 350 kW)"],
                "typical_charging_rate": "3-30 miles per hour (AC), 3-20 miles per minute (DC)",
                "source": "ChargePoint, Drive Electric Vermont"
            },
            "chademo": {
                "full_name": "CHAdeMO",
                "description": "A DC fast charging standard developed in Japan, capable of delivering up to 400 kW theoretically, though most stations are limited to 50-100 kW.",
                "compatibility": "Nissan Leaf, Mitsubishi Outlander PHEV, Kia Soul EV (older models); declining in North America",
                "charging_levels": ["DC Fast Charging (typically 50-100 kW)"],
                "typical_charging_rate": "2-4 miles per minute at 50 kW",
                "source": "CHAdeMO Association, Drive Electric Vermont"
            },
            "tesla_connector": {
                "full_name": "Tesla NACS (North American Charging Standard)",
                "description": "Tesla's proprietary connector that handles both AC and DC charging. Recently opened to other manufacturers and becoming a new standard in North America.",
                "compatibility": "All Tesla vehicles natively; Ford, GM, Rivian, and others adopting from 2025",
                "charging_levels": ["Level 1 and 2 AC", "DC Fast Charging (up to 250 kW at Superchargers)"],
                "typical_charging_rate": "3-30 miles per hour (AC), up to 15 miles per minute (DC)",
                "source": "Tesla, Drive Electric Vermont"
            },
            "gb_t": {
                "full_name": "GB/T",
                "description": "The standard charging connector in China for both AC and DC charging.",
                "compatibility": "Chinese-market electric vehicles",
                "charging_levels": ["AC (up to 22 kW)", "DC Fast Charging (up to 237.5 kW)"],
                "typical_charging_rate": "Varies by implementation",
                "source": "China Electricity Council"
            }
        }
        
        for key, value in charging_standards.items():
            self.add_knowledge("ev_charging_standards", key, value, value.get("source"))
        
        logger.info(f"Populated knowledge base with {len(charging_standards)} EV charging standard entries")
    
    def populate_maintenance_tips(self):
        """Populate the knowledge base with EV maintenance tips"""
        maintenance_tips = {
            "battery_maintenance": {
                "title": "Battery Maintenance Best Practices",
                "description": "Proper battery maintenance is crucial for maximizing the lifespan and performance of your electric vehicle.",
                "tips": [
                    "Follow manufacturer's recommendations for charging routines",
                    "For most lithium-ion batteries, keeping the state of charge between 20% and 80% maximizes battery life",
                    "Avoid frequent DC fast charging when not needed for long trips",
                    "Minimize exposure to extreme temperatures when possible",
                    "Allow the battery thermal management system to work (keep the vehicle plugged in during extreme temperatures)",
                    "Use scheduled charging to complete charging just before departure"
                ],
                "battery_type_specific": {
                    "NMC/NCA": "Avoid frequent charging to 100% and discharging below 10%",
                    "LFP": "Can be regularly charged to 100% without significant degradation"
                },
                "source": "Drive Electric Vermont, EV manufacturer manuals"
            },
            "brake_maintenance": {
                "title": "Brake System Maintenance",
                "description": "EVs use regenerative braking, which reduces wear on friction brakes but requires different maintenance considerations.",
                "tips": [
                    "Inspect brakes annually despite reduced wear",
                    "Occasionally use friction brakes to prevent rotor rust (especially in humid climates)",
                    "Flush brake fluid according to manufacturer's schedule (typically every 2-3 years)",
                    "Listen for unusual noises that might indicate caliper sticking due to infrequent use"
                ],
                "source": "EV manufacturer maintenance guides"
            },
            "tire_maintenance": {
                "title": "Tire Care for Electric Vehicles",
                "description": "EVs are typically heavier than equivalent ICE vehicles and deliver instant torque, affecting tire wear patterns.",
                "tips": [
                    "Maintain proper tire pressure (check monthly)",
                    "Rotate tires more frequently (every 6,000-8,000 miles recommended)",
                    "Consider EV-specific tires designed for higher weight and torque",
                    "Align wheels annually or when uneven wear is noticed",
                    "Low rolling resistance tires can improve efficiency and range"
                ],
                "source": "Tire manufacturers, EV owner manuals"
            },
            "cooling_system": {
                "title": "Cooling System Maintenance",
                "description": "EVs have sophisticated cooling systems for the battery, motor, and electronics that require periodic maintenance.",
                "tips": [
                    "Check coolant levels according to manufacturer's schedule",
                    "Flush cooling system at recommended intervals (typically 4-5 years)",
                    "Inspect for leaks during regular service",
                    "Keep radiator and cooling fins clean from debris",
                    "Never open cooling system when hot or without proper training"
                ],
                "source": "EV service manuals"
            },
            "winter_operation": {
                "title": "Cold Weather Operation Tips",
                "description": "Electric vehicles face unique challenges in cold weather, primarily affecting range and charging.",
                "tips": [
                    "Precondition the vehicle while plugged in to warm the battery and cabin",
                    "Use scheduled departure features to optimize preconditioning",
                    "Keep the battery state of charge above 20% in very cold weather",
                    "Use seat heaters instead of cabin heating when possible to conserve energy",
                    "Expect 10-30% range reduction in sub-freezing temperatures",
                    "Allow extra charging time in cold weather"
                ],
                "battery_type_specific": {
                    "LFP": "More significantly affected by cold; may show inaccurate range estimates until battery warms up"
                },
                "source": "Drive Electric Vermont, EV manufacturer winter guides"
            }
        }
        
        for key, value in maintenance_tips.items():
            self.add_knowledge("ev_maintenance", key, value, value.get("source"))
        
        logger.info(f"Populated knowledge base with {len(maintenance_tips)} EV maintenance tip entries")
    
    def populate_ev_manufacturer_info(self):
        """Populate the knowledge base with information about EV manufacturers"""
        manufacturers = {
            "scout_motors": {
                "full_name": "Scout Motors",
                "parent_company": "Volkswagen Group",
                "description": "A new electric brand from Volkswagen Group focused on electric trucks and SUVs with off-road capability.",
                "focus": "Electric trucks and SUVs with off-road capability",
                "notable_models": ["Scout SUV (upcoming)", "Scout Pickup (upcoming)"],
                "battery_technology": "Not yet announced, likely to use VW Group standards",
                "charging_standard": "Likely CCS/NACS",
                "source": "Scout Motors official information"
            },
            "afeela": {
                "full_name": "Afeela (Sony Honda Mobility)",
                "parent_company": "Joint venture between Sony and Honda",
                "description": "A new electric vehicle brand combining Honda's automotive expertise with Sony's technology and entertainment capabilities.",
                "focus": "Technology-focused electric vehicles with advanced entertainment and autonomous features",
                "notable_models": ["Afeela Sedan (upcoming)"],
                "battery_technology": "Likely based on Honda's e:Architecture",
                "charging_standard": "CCS/NACS",
                "source": "Sony Honda Mobility announcements"
            },
            "vinfast": {
                "full_name": "VinFast",
                "parent_company": "Vingroup",
                "description": "A Vietnamese automotive manufacturer rapidly expanding globally with a focus on electric vehicles.",
                "focus": "Mass-market electric SUVs and crossovers",
                "notable_models": ["VF 8", "VF 9", "VF 6", "VF 7"],
                "battery_technology": "NMC and LFP options, with battery subscription model available",
                "charging_standard": "CCS",
                "source": "VinFast official information"
            },
            "polestar": {
                "full_name": "Polestar",
                "parent_company": "Geely Holding Group (also owns Volvo)",
                "description": "A premium electric performance brand originally launched as Volvo's performance division, now focused exclusively on electric vehicles.",
                "focus": "Performance-oriented electric vehicles with minimalist Scandinavian design",
                "notable_models": ["Polestar 2", "Polestar 3", "Polestar 4"],
                "battery_technology": "NMC lithium-ion batteries",
                "charging_standard": "CCS (transitioning to NACS in North America)",
                "source": "Polestar official information"
            },
            "rivian": {
                "full_name": "Rivian",
                "parent_company": "Independent (with investments from Amazon, Ford, and others)",
                "description": "An American electric vehicle manufacturer focused on adventure-oriented trucks, SUVs, and commercial vehicles.",
                "focus": "Electric adventure vehicles and commercial vans",
                "notable_models": ["R1T (pickup)", "R1S (SUV)", "Commercial Van (for Amazon)"],
                "battery_technology": "NMC and LFP options",
                "charging_standard": "CCS (transitioning to NACS)",
                "source": "Rivian official information"
            },
            "lucid_motors": {
                "full_name": "Lucid Motors",
                "parent_company": "Majority owned by Saudi Arabia's Public Investment Fund",
                "description": "An American luxury electric vehicle manufacturer known for industry-leading range and efficiency.",
                "focus": "Luxury electric sedans and SUVs with class-leading range",
                "notable_models": ["Lucid Air", "Gravity (upcoming SUV)"],
                "battery_technology": "Custom NCA lithium-ion with 900V architecture",
                "charging_standard": "CCS (transitioning to NACS)",
                "source": "Lucid Motors official information"
            },
            "canoo": {
                "full_name": "Canoo",
                "parent_company": "Independent",
                "description": "An American electric vehicle startup focused on unique, modular designs for commercial and consumer use.",
                "focus": "Multi-purpose electric vehicles with modular designs",
                "notable_models": ["Lifestyle Vehicle", "MPDV (Multi-Purpose Delivery Vehicle)", "Pickup Truck"],
                "battery_technology": "Proprietary structural battery technology",
                "charging_standard": "CCS",
                "source": "Canoo official information"
            },
            "fisker": {
                "full_name": "Fisker Inc.",
                "parent_company": "Independent",
                "description": "An American electric vehicle manufacturer focused on sustainable vehicles with innovative design.",
                "focus": "Design-focused electric vehicles with sustainability emphasis",
                "notable_models": ["Fisker Ocean", "Fisker PEAR (upcoming)"],
                "battery_technology": "NMC lithium-ion batteries",
                "charging_standard": "CCS",
                "source": "Fisker official information"
            },
            "jaecoo": {
                "full_name": "Jaecoo",
                "parent_company": "Chery Automobile",
                "description": "A new premium electric SUV brand from Chinese automaker Chery, expanding into international markets.",
                "focus": "Premium electric and hybrid SUVs",
                "notable_models": ["Jaecoo J7", "Jaecoo J8"],
                "battery_technology": "NMC lithium-ion batteries",
                "charging_standard": "CCS/GB-T depending on market",
                "source": "Chery/Jaecoo official information"
            },
            "byd": {
                "full_name": "BYD (Build Your Dreams)",
                "parent_company": "BYD Company",
                "description": "A Chinese manufacturer and one of the world's largest producers of electric vehicles, also known for battery production.",
                "focus": "Wide range of electric vehicles from economy to luxury",
                "notable_models": ["BYD Seal", "BYD Atto 3", "BYD Han", "BYD Dolphin"],
                "battery_technology": "Blade Battery (LFP)",
                "charging_standard": "CCS/GB-T depending on market",
                "source": "BYD official information"
            }
        }
        
        for key, value in manufacturers.items():
            self.add_knowledge("ev_manufacturers", key, value, value.get("source"))
        
        logger.info(f"Populated knowledge base with {len(manufacturers)} EV manufacturer entries")

# Initialize and populate the knowledge base if this module is run directly
if __name__ == "__main__":
    kb = EVKnowledgeBase()
    kb.populate_ev_components()
    kb.populate_battery_types()
    kb.populate_charging_standards()
    kb.populate_maintenance_tips()
    kb.populate_ev_manufacturer_info()
    
    logger.info("EV Knowledge Base successfully populated with all categories")

import logging
import sqlite3
import json
import os
import pandas as pd
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class PartsCatalogDatabase:
    """
    Database manager for the parts catalog
    """
    
    def __init__(self, db_path=None):
        """
        Initialize the parts catalog database
        
        Args:
            db_path (str, optional): Path to the SQLite database file
        """
        if db_path is None:
            # Use default path in the project directory
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            db_path = os.path.join(base_dir, 'data', 'parts_catalog.db')
            
            # Ensure the directory exists
            os.makedirs(os.path.dirname(db_path), exist_ok=True)
        
        self.db_path = db_path
        self.conn = None
        self.cursor = None
        
        # Initialize the database
        self._initialize_db()
        
        logger.info(f"Parts Catalog Database initialized at {db_path}")
    
    def _initialize_db(self):
        """Initialize the database schema if it doesn't exist"""
        try:
            self.conn = sqlite3.connect(self.db_path)
            self.cursor = self.conn.cursor()
            
            # Create tables if they don't exist
            self._create_tables()
            
            self.conn.commit()
            logger.info("Database schema initialized successfully")
            
        except Exception as e:
            logger.error(f"Error initializing database: {e}")
            if self.conn:
                self.conn.rollback()
            raise
    
    def _create_tables(self):
        """Create the necessary tables for the parts catalog"""
        # Parts table - core information about each part
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS parts (
            part_id TEXT PRIMARY KEY,
            catalog_number TEXT,
            name TEXT NOT NULL,
            description TEXT,
            category TEXT,
            subcategory TEXT,
            manufacturer TEXT,
            weight REAL,
            dimensions TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
        ''')
        
        # Part details table - flexible key-value pairs for additional attributes
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS part_details (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            part_id TEXT NOT NULL,
            key TEXT NOT NULL,
            value TEXT,
            FOREIGN KEY (part_id) REFERENCES parts(part_id),
            UNIQUE(part_id, key)
        )
        ''')
        
        # Vehicle compatibility table - which parts fit which vehicles
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS vehicle_compatibility (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            part_id TEXT NOT NULL,
            make TEXT NOT NULL,
            model TEXT NOT NULL,
            year_from INTEGER,
            year_to INTEGER,
            engine_type TEXT,
            notes TEXT,
            FOREIGN KEY (part_id) REFERENCES parts(part_id)
        )
        ''')
        
        # Inventory table - stock levels, prices, etc.
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            part_id TEXT NOT NULL,
            quantity INTEGER DEFAULT 0,
            price REAL,
            cost REAL,
            supplier TEXT,
            location TEXT,
            last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (part_id) REFERENCES parts(part_id)
        )
        ''')
        
        # Suppliers table - information about part suppliers
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS suppliers (
            supplier_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            contact_person TEXT,
            email TEXT,
            phone TEXT,
            address TEXT,
            website TEXT,
            notes TEXT
        )
        ''')
        
        # Part images table - store paths to part images
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS part_images (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            part_id TEXT NOT NULL,
            image_path TEXT NOT NULL,
            is_primary BOOLEAN DEFAULT 0,
            description TEXT,
            FOREIGN KEY (part_id) REFERENCES parts(part_id)
        )
        ''')
        
        # Create indexes for better performance
        self.cursor.execute('CREATE INDEX IF NOT EXISTS idx_parts_catalog_number ON parts(catalog_number)')
        self.cursor.execute('CREATE INDEX IF NOT EXISTS idx_parts_category ON parts(category)')
        self.cursor.execute('CREATE INDEX IF NOT EXISTS idx_parts_manufacturer ON parts(manufacturer)')
        self.cursor.execute('CREATE INDEX IF NOT EXISTS idx_vehicle_compatibility_make_model ON vehicle_compatibility(make, model)')
    
    def close(self):
        """Close the database connection"""
        if self.conn:
            self.conn.close()
            self.conn = None
            self.cursor = None
    
    def __del__(self):
        """Destructor to ensure the database connection is closed"""
        self.close()
    
    def add_part(self, part_data):
        """
        Add a new part to the catalog
        
        Args:
            part_data (dict): Part information
            
        Returns:
            str: Part ID of the added part
        """
        try:
            # Extract core part data
            part_id = part_data.get('part_id')
            if not part_id:
                # Generate a unique ID if not provided
                part_id = f"P{datetime.now().strftime('%Y%m%d%H%M%S')}"
            
            catalog_number = part_data.get('catalog_number', '')
            name = part_data.get('name')
            if not name:
                raise ValueError("Part name is required")
            
            description = part_data.get('description', '')
            category = part_data.get('category', '')
            subcategory = part_data.get('subcategory', '')
            manufacturer = part_data.get('manufacturer', '')
            weight = part_data.get('weight', 0)
            dimensions = part_data.get('dimensions', '')
            
            # Insert into parts table
            self.cursor.execute('''
            INSERT OR REPLACE INTO parts 
            (part_id, catalog_number, name, description, category, subcategory, 
             manufacturer, weight, dimensions, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ''', (part_id, catalog_number, name, description, category, subcategory, 
                  manufacturer, weight, dimensions))
            
            # Extract and insert additional details
            details = part_data.get('details', {})
            for key, value in details.items():
                self.cursor.execute('''
                INSERT OR REPLACE INTO part_details (part_id, key, value)
                VALUES (?, ?, ?)
                ''', (part_id, key, str(value)))
            
            # Extract and insert vehicle compatibility
            compatibility = part_data.get('compatibility', [])
            for compat in compatibility:
                make = compat.get('make', '')
                model = compat.get('model', '')
                year_from = compat.get('year_from', 0)
                year_to = compat.get('year_to', 9999)
                engine_type = compat.get('engine_type', '')
                notes = compat.get('notes', '')
                
                self.cursor.execute('''
                INSERT INTO vehicle_compatibility 
                (part_id, make, model, year_from, year_to, engine_type, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (part_id, make, model, year_from, year_to, engine_type, notes))
            
            # Extract and insert inventory information
            inventory = part_data.get('inventory', {})
            if inventory:
                quantity = inventory.get('quantity', 0)
                price = inventory.get('price', 0)
                cost = inventory.get('cost', 0)
                supplier = inventory.get('supplier', '')
                location = inventory.get('location', '')
                
                self.cursor.execute('''
                INSERT OR REPLACE INTO inventory 
                (part_id, quantity, price, cost, supplier, location, last_updated)
                VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ''', (part_id, quantity, price, cost, supplier, location))
            
            # Extract and insert image paths
            images = part_data.get('images', [])
            for img in images:
                image_path = img.get('path', '')
                is_primary = img.get('is_primary', 0)
                description = img.get('description', '')
                
                if image_path:
                    self.cursor.execute('''
                    INSERT INTO part_images (part_id, image_path, is_primary, description)
                    VALUES (?, ?, ?, ?)
                    ''', (part_id, image_path, is_primary, description))
            
            self.conn.commit()
            logger.info(f"Added part {part_id} to catalog")
            return part_id
            
        except Exception as e:
            logger.error(f"Error adding part to catalog: {e}")
            self.conn.rollback()
            raise
    
    def get_part(self, part_id=None, catalog_number=None):
        """
        Get part information by ID or catalog number
        
        Args:
            part_id (str, optional): Part ID
            catalog_number (str, optional): Catalog number
            
        Returns:
            dict: Part information or None if not found
        """
        try:
            if part_id:
                self.cursor.execute('SELECT * FROM parts WHERE part_id = ?', (part_id,))
            elif catalog_number:
                self.cursor.execute('SELECT * FROM parts WHERE catalog_number = ?', (catalog_number,))
            else:
                raise ValueError("Either part_id or catalog_number must be provided")
            
            part_row = self.cursor.fetchone()
            if not part_row:
                return None
            
            # Convert row to dict
            columns = [col[0] for col in self.cursor.description]
            part_data = dict(zip(columns, part_row))
            
            # Get additional details
            self.cursor.execute('SELECT key, value FROM part_details WHERE part_id = ?', (part_data['part_id'],))
            details = {row[0]: row[1] for row in self.cursor.fetchall()}
            part_data['details'] = details
            
            # Get vehicle compatibility
            self.cursor.execute('''
            SELECT make, model, year_from, year_to, engine_type, notes 
            FROM vehicle_compatibility 
            WHERE part_id = ?
            ''', (part_data['part_id'],))
            compatibility = []
            for row in self.cursor.fetchall():
                compat = {
                    'make': row[0],
                    'model': row[1],
                    'year_from': row[2],
                    'year_to': row[3],
                    'engine_type': row[4],
                    'notes': row[5]
                }
                compatibility.append(compat)
            part_data['compatibility'] = compatibility
            
            # Get inventory information
            self.cursor.execute('''
            SELECT quantity, price, cost, supplier, location, last_updated 
            FROM inventory 
            WHERE part_id = ?
            ''', (part_data['part_id'],))
            inv_row = self.cursor.fetchone()
            if inv_row:
                inventory = {
                    'quantity': inv_row[0],
                    'price': inv_row[1],
                    'cost': inv_row[2],
                    'supplier': inv_row[3],
                    'location': inv_row[4],
                    'last_updated': inv_row[5]
                }
                part_data['inventory'] = inventory
            
            # Get images
            self.cursor.execute('''
            SELECT image_path, is_primary, description 
            FROM part_images 
            WHERE part_id = ?
            ''', (part_data['part_id'],))
            images = []
            for row in self.cursor.fetchall():
                img = {
                    'path': row[0],
                    'is_primary': bool(row[1]),
                    'description': row[2]
                }
                images.append(img)
            part_data['images'] = images
            
            return part_data
            
        except Exception as e:
            logger.error(f"Error getting part from catalog: {e}")
            raise
    
    def search_parts(self, query=None, category=None, make=None, model=None, year=None):
        """
        Search for parts in the catalog
        
        Args:
            query (str, optional): Search query for name or description
            category (str, optional): Part category
            make (str, optional): Vehicle make
            model (str, optional): Vehicle model
            year (int, optional): Vehicle year
            
        Returns:
            list: List of matching parts
        """
        try:
            params = []
            conditions = []
            
            # Build the query conditions
            if query:
                conditions.append("(p.name LIKE ? OR p.description LIKE ? OR p.catalog_number LIKE ?)")
                params.extend([f"%{query}%", f"%{query}%", f"%{query}%"])
            
            if category:
                conditions.append("p.category = ?")
                params.append(category)
            
            # Vehicle compatibility conditions
            vehicle_join = ""
            if make or model or year:
                vehicle_join = "LEFT JOIN vehicle_compatibility vc ON p.part_id = vc.part_id"
                
                if make:
                    conditions.append("vc.make = ?")
                    params.append(make)
                
                if model:
                    conditions.append("vc.model = ?")
                    params.append(model)
                
                if year:
                    conditions.append("(vc.year_from <= ? AND vc.year_to >= ?)")
                    params.extend([year, year])
            
            # Build the final query
            sql = f"""
            SELECT DISTINCT p.part_id, p.catalog_number, p.name, p.description, 
                   p.category, p.manufacturer
            FROM parts p
            {vehicle_join}
            """
            
            if conditions:
                sql += " WHERE " + " AND ".join(conditions)
            
            self.cursor.execute(sql, params)
            results = []
            
            for row in self.cursor.fetchall():
                part = {
                    'part_id': row[0],
                    'catalog_number': row[1],
                    'name': row[2],
                    'description': row[3],
                    'category': row[4],
                    'manufacturer': row[5]
                }
                results.append(part)
            
            return results
            
        except Exception as e:
            logger.error(f"Error searching parts catalog: {e}")
            raise
    
    def update_inventory(self, part_id, quantity=None, price=None, cost=None):
        """
        Update inventory information for a part
        
        Args:
            part_id (str): Part ID
            quantity (int, optional): New quantity
            price (float, optional): New price
            cost (float, optional): New cost
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Check if the part exists
            self.cursor.execute('SELECT 1 FROM parts WHERE part_id = ?', (part_id,))
            if not self.cursor.fetchone():
                logger.warning(f"Cannot update inventory: Part {part_id} not found")
                return False
            
            # Check if inventory record exists
            self.cursor.execute('SELECT 1 FROM inventory WHERE part_id = ?', (part_id,))
            exists = self.cursor.fetchone() is not None
            
            if exists:
                # Update existing record
                updates = []
                params = []
                
                if quantity is not None:
                    updates.append("quantity = ?")
                    params.append(quantity)
                
                if price is not None:
                    updates.append("price = ?")
                    params.append(price)
                
                if cost is not None:
                    updates.append("cost = ?")
                    params.append(cost)
                
                if updates:
                    updates.append("last_updated = CURRENT_TIMESTAMP")
                    sql = f"UPDATE inventory SET {', '.join(updates)} WHERE part_id = ?"
                    params.append(part_id)
                    self.cursor.execute(sql, params)
            else:
                # Insert new record
                self.cursor.execute('''
                INSERT INTO inventory (part_id, quantity, price, cost, last_updated)
                VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                ''', (part_id, quantity or 0, price or 0, cost or 0))
            
            self.conn.commit()
            logger.info(f"Updated inventory for part {part_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error updating inventory: {e}")
            self.conn.rollback()
            return False
    
    def import_from_csv(self, csv_path, mapping=None):
        """
        Import parts data from a CSV file
        
        Args:
            csv_path (str): Path to the CSV file
            mapping (dict, optional): Column mapping
            
        Returns:
            tuple: (success_count, error_count)
        """
        try:
            # Read the CSV file
            df = pd.read_csv(csv_path)
            
            # Default mapping if not provided
            if mapping is None:
                mapping = {
                    'part_id': 'part_id',
                    'catalog_number': 'catalog_number',
                    'name': 'name',
                    'description': 'description',
                    'category': 'category',
                    'subcategory': 'subcategory',
                    'manufacturer': 'manufacturer',
                    'weight': 'weight',
                    'dimensions': 'dimensions',
                    'quantity': 'quantity',
                    'price': 'price',
                    'cost': 'cost'
                }
            
            success_count = 0
            error_count = 0
            
            # Process each row
            for _, row in df.iterrows():
                try:
                    part_data = {}
                    
                    # Map columns according to the provided mapping
                    for db_field, csv_field in mapping.items():
                        if csv_field in row and not pd.isna(row[csv_field]):
                            part_data[db_field] = row[csv_field]
                    
                    # Ensure required fields are present
                    if 'name' not in part_data:
                        logger.warning(f"Skipping row: Missing required field 'name'")
                        error_count += 1
                        continue
                    
                    # Extract inventory data if present
                    inventory = {}
                    for field in ['quantity', 'price', 'cost']:
                        if field in part_data:
                            inventory[field] = part_data.pop(field)
                    
                    if inventory:
                        part_data['inventory'] = inventory
                    
                    # Add the part to the database
                    self.add_part(part_data)
                    success_count += 1
                    
                except Exception as e:
                    logger.error(f"Error importing row: {e}")
                    error_count += 1
            
            self.conn.commit()
            logger.info(f"Imported {success_count} parts from CSV, {error_count} errors")
            return (success_count, error_count)
            
        except Exception as e:
            logger.error(f"Error importing from CSV: {e}")
            self.conn.rollback()
            raise
    
    def export_to_csv(self, csv_path):
        """
        Export parts data to a CSV file
        
        Args:
            csv_path (str): Path to save the CSV file
            
        Returns:
            int: Number of parts exported
        """
        try:
            # Get all parts with basic information
            self.cursor.execute('''
            SELECT p.part_id, p.catalog_number, p.name, p.description, p.category, 
                   p.subcategory, p.manufacturer, p.weight, p.dimensions,
                   i.quantity, i.price, i.cost
            FROM parts p
            LEFT JOIN inventory i ON p.part_id = i.part_id
            ''')
            
            rows = self.cursor.fetchall()
            
            # Create DataFrame
            columns = ['part_id', 'catalog_number', 'name', 'description', 'category', 
                      'subcategory', 'manufacturer', 'weight', 'dimensions',
                      'quantity', 'price', 'cost']
            
            df = pd.DataFrame(rows, columns=columns)
            
            # Save to CSV
            df.to_csv(csv_path, index=False)
            
            logger.info(f"Exported {len(rows)} parts to {csv_path}")
            return len(rows)
            
        except Exception as e:
            logger.error(f"Error exporting to CSV: {e}")
            raise
    
    def get_compatible_parts(self, make, model, year=None):
        """
        Get parts compatible with a specific vehicle
        
        Args:
            make (str): Vehicle make
            model (str): Vehicle model
            year (int, optional): Vehicle year
            
        Returns:
            list: List of compatible parts
        """
        try:
            params = [make, model]
            sql = '''
            SELECT p.part_id, p.catalog_number, p.name, p.category, p.manufacturer,
                   i.price, i.quantity
            FROM parts p
            JOIN vehicle_compatibility vc ON p.part_id = vc.part_id
            LEFT JOIN inventory i ON p.part_id = i.part_id
            WHERE vc.make = ? AND vc.model = ?
            '''
            
            if year:
                sql += " AND vc.year_from <= ? AND vc.year_to >= ?"
                params.extend([year, year])
            
            self.cursor.execute(sql, params)
            
            results = []
            for row in self.cursor.fetchall():
                part = {
                    'part_id': row[0],
                    'catalog_number': row[1],
                    'name': row[2],
                    'category': row[3],
                    'manufacturer': row[4],
                    'price': row[5],
                    'in_stock': row[6] > 0 if row[6] is not None else False
                }
                results.append(part)
            
            return results
            
        except Exception as e:
            logger.error(f"Error getting compatible parts: {e}")
            raise
    
    def add_sample_data(self):
        """Add sample data to the database for testing"""
        try:
            # Sample parts
            sample_parts = [
                {
                    'part_id': 'BP1001',
                    'catalog_number': 'BP-1001-T',
                    'name': 'Premium Brake Pad Set',
                    'description': 'High-quality ceramic brake pads for Toyota vehicles',
                    'category': 'Brakes',
                    'subcategory': 'Brake Pads',
                    'manufacturer': 'BrakeMaster',
                    'weight': 2.5,
                    'dimensions': '15x10x5 cm',
                    'details': {
                        'material': 'Ceramic',
                        'position': 'Front',
                        'warranty': '2 years'
                    },
                    'compatibility': [
                        {
                            'make': 'Toyota',
                            'model': 'Corolla',
                            'year_from': 2015,
                            'year_to': 2022,
                            'engine_type': 'All',
                            'notes': 'Fits all trim levels'
                        },
                        {
                            'make': 'Toyota',
                            'model': 'Camry',
                            'year_from': 2015,
                            'year_to': 2020,
                            'engine_type': 'All',
                            'notes': 'Except hybrid models'
                        }
                    ],
                    'inventory': {
                        'quantity': 45,
                        'price': 89.99,
                        'cost': 45.50,
                        'supplier': 'BrakeMaster Distributors',
                        'location': 'Warehouse A'
                    },
                    'images': [
                        {
                            'path': '/images/parts/BP1001_1.jpg',
                            'is_primary': True,
                            'description': 'Front view'
                        },
                        {
                            'path': '/images/parts/BP1001_2.jpg',
                            'is_primary': False,
                            'description': 'Side view'
                        }
                    ]
                },
                {
                    'part_id': 'OF2001',
                    'catalog_number': 'OF-2001-H',
                    'name': 'Premium Oil Filter',
                    'description': 'High-efficiency oil filter for Honda vehicles',
                    'category': 'Engine',
                    'subcategory': 'Oil Filters',
                    'manufacturer': 'FilterPro',
                    'weight': 0.5,
                    'dimensions': '8x8x10 cm',
                    'details': {
                        'filter_type': 'Cartridge',
                        'thread_size': '3/4-16 UNF',
                        'warranty': '1 year'
                    },
                    'compatibility': [
                        {
                            'make': 'Honda',
                            'model': 'Civic',
                            'year_from': 2016,
                            'year_to': 2023,
                            'engine_type': '1.5L',
                            'notes': 'All 1.5L engines'
                        },
                        {
                            'make': 'Honda',
                            'model': 'Accord',
                            'year_from': 2018,
                            'year_to': 2023,
                            'engine_type': '1.5L',
                            'notes': 'All 1.5L engines'
                        }
                    ],
                    'inventory': {
                        'quantity': 120,
                        'price': 12.99,
                        'cost': 5.75,
                        'supplier': 'FilterPro Inc.',
                        'location': 'Warehouse B'
                    },
                    'images': [
                        {
                            'path': '/images/parts/OF2001_1.jpg',
                            'is_primary': True,
                            'description': 'Product image'
                        }
                    ]
                },
                {
                    'part_id': 'AF3001',
                    'catalog_number': 'AF-3001-M',
                    'name': 'Premium Air Filter',
                    'description': 'High-flow air filter for Mazda vehicles',
                    'category': 'Engine',
                    'subcategory': 'Air Filters',
                    'manufacturer': 'FilterPro',
                    'weight': 0.3,
                    'dimensions': '25x20x3 cm',
                    'details': {
                        'filter_type': 'Panel',
                        'material': 'Synthetic',
                        'washable': False
                    },
                    'compatibility': [
                        {
                            'make': 'Mazda',
                            'model': 'Mazda3',
                            'year_from': 2014,
                            'year_to': 2023,
                            'engine_type': 'All',
                            'notes': 'All engine types'
                        },
                        {
                            'make': 'Mazda',
                            'model': 'Mazda6',
                            'year_from': 2014,
                            'year_to': 2021,
                            'engine_type': 'All',
                            'notes': 'All engine types'
                        }
                    ],
                    'inventory': {
                        'quantity': 85,
                        'price': 19.99,
                        'cost': 8.25,
                        'supplier': 'FilterPro Inc.',
                        'location': 'Warehouse B'
                    },
                    'images': [
                        {
                            'path': '/images/parts/AF3001_1.jpg',
                            'is_primary': True,
                            'description': 'Product image'
                        }
                    ]
                }
            ]
            
            # Add sample parts to the database
            for part in sample_parts:
                self.add_part(part)
            
            self.conn.commit()
            logger.info(f"Added {len(sample_parts)} sample parts to the database")
            
        except Exception as e:
            logger.error(f"Error adding sample data: {e}")
            self.conn.rollback()
            raise

# Example usage
if __name__ == '__main__':
    # Create a parts catalog database
    db = PartsCatalogDatabase()
    
    # Add sample data
    db.add_sample_data()
    
    # Search for parts
    results = db.search_parts(category='Brakes')
    print(f"Found {len(results)} brake parts")
    
    # Get compatible parts for a vehicle
    compatible = db.get_compatible_parts('Toyota', 'Corolla', 2018)
    print(f"Found {len(compatible)} compatible parts for Toyota Corolla 2018")
    
    # Close the database connection
    db.close()

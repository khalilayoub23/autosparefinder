import logging
import requests
import json
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class OrderManagementSystem:
    """
    System for managing orders across multiple suppliers and integrating with CRM
    """
    
    def __init__(self, config=None):
        """
        Initialize the order management system
        
        Args:
            config (dict, optional): Configuration parameters
        """
        self.config = config or {}
        self.crm_interface = self.config.get('crm_interface')
        self.supplier_apis = self.config.get('supplier_apis', {})
        self.order_history = []
        
        logger.info(f"Order Management System initialized with {len(self.supplier_apis)} supplier connections")
    
    def create_order(self, *args, **kwargs):
        """
        Create a new order - supports both positional and dictionary input formats
        
        Format 1 (dictionary):
            create_order({
                'customer_id': 'CUST001',
                'parts': [{'part_id': 'TEST001', 'catalog_number': 'CAT001', 'quantity': 1, 'price': 100}],
                'shipping_address': {'name': 'Test Customer'}
            })
            
        Format 2 (positional):
            create_order('TEST001', 1, 'Test Customer', 'CUST001', {'name': 'Test Customer'})
            
        Returns:
            dict: Order creation result
        """
        try:
            # Check if first argument is a dictionary (Format 1)
            if args and isinstance(args[0], dict):
                # Use the dictionary directly
                order_data = args[0]
                logger.info(f"Creating order with dictionary format, customer_id: {order_data.get('customer_id')}")
                return self._create_order_internal(order_data)
            else:
                # Format 2: positional arguments
                part_id = args[0] if len(args) > 0 else None
                quantity = args[1] if len(args) > 1 else 1
                customer_name = args[2] if len(args) > 2 else kwargs.get('customer_name')
                customer_id = args[3] if len(args) > 3 else kwargs.get('customer_id')
                shipping_address = args[4] if len(args) > 4 else kwargs.get('shipping_address', {})
                supplier_id = args[5] if len(args) > 5 else kwargs.get('supplier_id')
                
                # Use provided customer_id or generate one if not provided
                effective_customer_id = customer_id if customer_id is not None else f"CUST-{datetime.now().strftime('%Y%m%d%H%M%S')}"
                
                # Convert parameters to order_data format for internal processing
                order_data = {
                    'customer_id': effective_customer_id,
                    'customer_name': customer_name,
                    'parts': [
                        {
                            'catalog_number': part_id,
                            'quantity': quantity,
                            'price': 0  # Price will be determined later
                        }
                    ],
                    'supplier_id': supplier_id,
                    'shipping_address': shipping_address or {}
                }
                
                logger.info(f"Creating order with positional format, customer_id: {effective_customer_id}")
                return self._create_order_internal(order_data)
            
        except Exception as e:
            logger.error(f"Error creating order: {e}")
            return {'status': 'error', 'message': str(e)}
    
    def _create_order_internal(self, order_data):
        """
        Internal method to create a new order
        
        Args:
            order_data (dict): Order information
            
        Returns:
            dict: Order creation result
        """
        try:
            # Extract order details
            customer_id = order_data.get('customer_id')
            parts = order_data.get('parts', [])
            supplier_id = order_data.get('supplier_id')
            shipping_address = order_data.get('shipping_address', {})
            
            # Validate input
            if not customer_id:
                return {'status': 'error', 'message': 'Customer ID is required'}
            
            if not parts:
                return {'status': 'error', 'message': 'No parts specified in order'}
            
            # Generate order ID
            order_id = f"ORD-{datetime.now().strftime('%Y%m%d%H%M%S')}"
            
            # Create order in CRM if available
            crm_order_id = None
            if self.crm_interface:
                crm_result = self.crm_interface.create_order({
                    'customer_id': customer_id,
                    'order_date': datetime.now().isoformat(),
                    'status': 'New',
                    'total_amount': sum(part.get('price', 0) for part in parts),
                    'items': parts
                })
                
                if 'error' not in crm_result:
                    crm_order_id = crm_result.get('id')
                    logger.info(f"Created order in CRM with ID: {crm_order_id}")
                else:
                    logger.warning(f"Failed to create order in CRM: {crm_result.get('error')}")
            
            # Create order with supplier if specified
            supplier_order_id = None
            if supplier_id and supplier_id in self.supplier_apis:
                supplier_result = self._create_supplier_order(supplier_id, parts, shipping_address)
                
                if supplier_result.get('status') == 'success':
                    supplier_order_id = supplier_result.get('supplier_order_id')
                    logger.info(f"Created order with supplier {supplier_id}, ID: {supplier_order_id}")
                else:
                    logger.warning(f"Failed to create order with supplier: {supplier_result.get('message')}")
            
            # Record the order in our system
            order = {
                'order_id': order_id,
                'customer_id': customer_id,
                'parts': parts,
                'supplier_id': supplier_id,
                'supplier_order_id': supplier_order_id,
                'crm_order_id': crm_order_id,
                'shipping_address': shipping_address,
                'status': 'pending',
                'created_at': datetime.now().isoformat(),
                'updated_at': datetime.now().isoformat()
            }
            
            # Add to order history
            self.order_history.append(order)
            
            logger.info(f"Created order {order_id} for customer {customer_id}")
            
            return {
                'status': 'success',
                'message': 'Order created successfully',
                'order_id': order_id,
                'supplier_order_id': supplier_order_id,
                'crm_order_id': crm_order_id,
                'order': order
            }
            
        except Exception as e:
            logger.error(f"Error creating order: {e}")
            return {'status': 'error', 'message': str(e)}
    
    def _create_supplier_order(self, supplier_id, parts, shipping_address):
        """
        Create an order with a supplier
        
        Args:
            supplier_id (str): Supplier ID
            parts (list): List of parts to order
            shipping_address (dict): Shipping address
            
        Returns:
            dict: Supplier order creation result
        """
        try:
            supplier_api = self.supplier_apis.get(supplier_id)
            if not supplier_api:
                return {'status': 'error', 'message': f'Supplier API not configured: {supplier_id}'}
            
            # Map our parts format to supplier's format
            supplier_parts = []
            for part in parts:
                supplier_parts.append({
                    'part_number': part.get('catalog_number', ''),
                    'quantity': part.get('quantity', 1),
                    'unit_price': part.get('price', 0)
                })
            
            # Map shipping address to supplier's format
            supplier_shipping = {
                'name': shipping_address.get('name', ''),
                'street': shipping_address.get('street', ''),
                'city': shipping_address.get('city', ''),
                'state': shipping_address.get('state', ''),
                'postal_code': shipping_address.get('postal_code', ''),
                'country': shipping_address.get('country', '')
            }
            
            # Build the request
            url = supplier_api.get('order_url', '')
            api_key = supplier_api.get('api_key', '')
            
            if not url:
                return {'status': 'error', 'message': 'Supplier order URL not configured'}
            
            headers = {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {api_key}'
            }
            
            data = {
                'parts': supplier_parts,
                'shipping_address': supplier_shipping,
                'order_date': datetime.now().isoformat()
            }
            
            # Make the request
            response = requests.post(url, headers=headers, json=data)
            response.raise_for_status()
            
            # Parse the response
            result = response.json()
            
            return {
                'status': 'success',
                'supplier_order_id': result.get('order_id'),
                'message': 'Order created with supplier'
            }
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Error creating supplier order: {e}")
            return {'status': 'error', 'message': str(e)}
        except Exception as e:
            logger.error(f"Error processing supplier order: {e}")
            return {'status': 'error', 'message': str(e)}
    
    def get_order(self, order_id):
        """
        Get order information
        
        Args:
            order_id (str): Order ID
            
        Returns:
            dict: Order information
        """
        try:
            # Find the order in our history
            for order in self.order_history:
                if order['order_id'] == order_id:
                    # Check if we need to update status from supplier
                    if order['supplier_id'] and order['supplier_order_id']:
                        supplier_status = self._check_supplier_order_status(
                            order['supplier_id'], 
                            order['supplier_order_id']
                        )
                        
                        if supplier_status:
                            order['status'] = supplier_status
                            order['updated_at'] = datetime.now().isoformat()
                    
                    # Check if we need to update status from CRM
                    if self.crm_interface and order['crm_order_id']:
                        crm_order = self.crm_interface.get_order(order['crm_order_id'])
                        
                        if 'error' not in crm_order:
                            crm_status = crm_order.get('status')
                            if crm_status and crm_status != order['status']:
                                order['status'] = crm_status
                                order['updated_at'] = datetime.now().isoformat()
                    
                    logger.info(f"Retrieved order {order_id}, status: {order['status']}")
                    return {'status': 'success', 'order': order}
            
            logger.warning(f"Order not found: {order_id}")
            return {'status': 'error', 'message': f'Order not found: {order_id}'}
            
        except Exception as e:
            logger.error(f"Error getting order: {e}")
            return {'status': 'error', 'message': str(e)}
    
    def _check_supplier_order_status(self, supplier_id, supplier_order_id):
        """
        Check the status of an order with a supplier
        
        Args:
            supplier_id (str): Supplier ID
            supplier_order_id (str): Supplier's order ID
            
        Returns:
            str: Order status or None if status check failed
        """
        try:
            supplier_api = self.supplier_apis.get(supplier_id)
            if not supplier_api:
                logger.warning(f'Supplier API not configured: {supplier_id}')
                return None
            
            # Build the request
            url = supplier_api.get('status_url', '')
            api_key = supplier_api.get('api_key', '')
            
            if not url:
                logger.warning('Supplier status URL not configured')
                return None
            
            headers = {
                'Authorization': f'Bearer {api_key}'
            }
            
            # Make the request
            response = requests.get(f"{url}/{supplier_order_id}", headers=headers)
            response.raise_for_status()
            
            # Parse the response
            result = response.json()
            
            # Map supplier status to our status
            supplier_status = result.get('status', '').lower()
            
            if supplier_status == 'processing':
                return 'processing'
            elif supplier_status == 'shipped':
                return 'shipped'
            elif supplier_status == 'delivered':
                return 'delivered'
            elif supplier_status == 'cancelled':
                return 'cancelled'
            else:
                return supplier_status
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Error checking supplier order status: {e}")
            return None
        except Exception as e:
            logger.error(f"Error processing supplier status: {e}")
            return None
    
    def update_order_status(self, order_id, status):
        """
        Update the status of an order
        
        Args:
            order_id (str): Order ID
            status (str): New status
            
        Returns:
            dict: Status update result
        """
        try:
            # Find the order in our history
            for order in self.order_history:
                if order['order_id'] == order_id:
                    # Update status in our system
                    old_status = order['status']
                    order['status'] = status
                    order['updated_at'] = datetime.now().isoformat()
                    
                    # Update status in CRM if available
                    if self.crm_interface and order['crm_order_id']:
                        crm_result = self.crm_interface.update_order_status(
                            order['crm_order_id'], 
                            status
                        )
                        
                        if 'error' in crm_result:
                            logger.warning(f"Failed to update order status in CRM: {crm_result.get('error')}")
                    
                    # Update status with supplier if available
                    if order['supplier_id'] and order['supplier_order_id']:
                        supplier_result = self._update_supplier_order_status(
                            order['supplier_id'],
                            order['supplier_order_id'],
                            status
                        )
                        
                        if supplier_result and supplier_result.get('status') != 'success':
                            logger.warning(f"Failed to update order status with supplier: {supplier_result.get('message')}")
                    
                    logger.info(f"Updated order {order_id} status from {old_status} to {status}")
                    return {'status': 'success', 'message': f'Order status updated to {status}'}
            
            logger.warning(f"Order not found for status update: {order_id}")
            return {'status': 'error', 'message': f'Order not found: {order_id}'}
            
        except Exception as e:
            logger.error(f"Error updating order status: {e}")
            return {'status': 'error', 'message': str(e)}
    
    def _update_supplier_order_status(self, supplier_id, supplier_order_id, status):
        """
        Update the status of an order with a supplier
        
        Args:
            supplier_id (str): Supplier ID
            supplier_order_id (str): Supplier's order ID
            status (str): New status
            
        Returns:
            dict: Status update result
        """
        try:
            supplier_api = self.supplier_apis.get(supplier_id)
            if not supplier_api:
                return {'status': 'error', 'message': f'Supplier API not configured: {supplier_id}'}
            
            # Build the request
            url = supplier_api.get('status_update_url', '')
            api_key = supplier_api.get('api_key', '')
            
            if not url:
                return {'status': 'error', 'message': 'Supplier status update URL not configured'}
            
            headers = {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {api_key}'
            }
            
            # Map our status to supplier status
            supplier_status = status
            if status == 'cancelled':
                supplier_status = 'cancel'
            
            data = {
                'order_id': supplier_order_id,
                'status': supplier_status
            }
            
            # Make the request
            response = requests.put(url, headers=headers, json=data)
            response.raise_for_status()
            
            # Parse the response
            result = response.json()
            
            return {
                'status': 'success',
                'message': 'Order status updated with supplier'
            }
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Error updating supplier order status: {e}")
            return {'status': 'error', 'message': str(e)}
        except Exception as e:
            logger.error(f"Error processing supplier status update: {e}")
            return {'status': 'error', 'message': str(e)}
    
    def cancel_order(self, order_id):
        """
        Cancel an order
        
        Args:
            order_id (str): Order ID
            
        Returns:
            dict: Cancellation result
        """
        return self.update_order_status(order_id, 'cancelled')
    
    def get_order_history(self, customer_id=None, status=None, limit=10):
        """
        Get order history
        
        Args:
            customer_id (str, optional): Filter by customer ID
            status (str, optional): Filter by status
            limit (int, optional): Maximum number of orders to return
            
        Returns:
            dict: Order history
        """
        try:
            # Filter orders
            filtered_orders = self.order_history
            
            if customer_id:
                filtered_orders = [order for order in filtered_orders if order['customer_id'] == customer_id]
            
            if status:
                filtered_orders = [order for order in filtered_orders if order['status'] == status]
            
            # Sort by created_at (newest first)
            filtered_orders.sort(key=lambda x: x['created_at'], reverse=True)
            
            # Limit the number of orders
            limited_orders = filtered_orders[:limit]
            
            logger.info(f"Retrieved {len(limited_orders)} orders from history")
            
            return {
                'status': 'success',
                'count': len(limited_orders),
                'orders': limited_orders
            }
            
        except Exception as e:
            logger.error(f"Error getting order history: {e}")
            return {'status': 'error', 'message': str(e)}

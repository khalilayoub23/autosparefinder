import logging
import os
import json
import requests
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class CatalogAPIIntegration:
    """
    Integration with external catalog APIs for parts data enrichment
    """
    
    def __init__(self, config=None):
        """
        Initialize the catalog API integration
        
        Args:
            config (dict, optional): Configuration parameters for API connections
        """
        self.config = config or {}
        self.api_keys = self.config.get('api_keys', {})
        self.base_urls = self.config.get('base_urls', {})
        self.cache_dir = self.config.get('cache_dir', 'api_cache')
        
        # Ensure cache directory exists
        os.makedirs(self.cache_dir, exist_ok=True)
        
        logger.info(f"Catalog API Integration initialized with {len(self.api_keys)} API connections")
    
    def enrich_part_data(self, part_data):
        """
        Enrich part data with information from external APIs
        
        Args:
            part_data (dict): Basic part information
            
        Returns:
            dict: Enriched part data
        """
        try:
            # Extract identifiers
            part_id = part_data.get('part_id', '')
            catalog_number = part_data.get('catalog_number', '')
            manufacturer = part_data.get('manufacturer', '')
            
            if not (part_id or catalog_number):
                logger.warning("Cannot enrich part data without part_id or catalog_number")
                return part_data
            
            # Check cache first
            cache_key = f"{manufacturer}_{catalog_number}_{part_id}".replace('/', '_').replace(' ', '_')
            cache_file = os.path.join(self.cache_dir, f"{cache_key}.json")
            
            if os.path.exists(cache_file):
                # Use cached data
                with open(cache_file, 'r') as f:
                    cached_data = json.load(f)
                
                # Update the original data with cached enriched data
                self._update_part_with_enriched_data(part_data, cached_data)
                logger.info(f"Used cached enriched data for part {part_id or catalog_number}")
                
                return part_data
            
            # No cache, fetch from APIs
            enriched_data = {}
            
            # Try different APIs based on available identifiers
            if catalog_number and manufacturer:
                # Try manufacturer-specific API first
                if manufacturer.lower() in self.api_keys:
                    api_result = self._query_manufacturer_api(manufacturer, catalog_number)
                    if api_result:
                        enriched_data.update(api_result)
            
            # Try generic parts database API
            if 'generic_parts_db' in self.api_keys:
                api_result = self._query_generic_parts_db(part_id, catalog_number, manufacturer)
                if api_result:
                    enriched_data.update(api_result)
            
            # Try technical specs API
            if 'technical_specs' in self.api_keys:
                api_result = self._query_technical_specs_api(part_id, catalog_number)
                if api_result:
                    enriched_data.update(api_result)
            
            # If we got any enriched data, cache it
            if enriched_data:
                with open(cache_file, 'w') as f:
                    json.dump(enriched_data, f, indent=2)
                
                # Update the original data with enriched data
                self._update_part_with_enriched_data(part_data, enriched_data)
                logger.info(f"Enriched and cached data for part {part_id or catalog_number}")
            else:
                logger.warning(f"No enriched data found for part {part_id or catalog_number}")
            
            return part_data
            
        except Exception as e:
            logger.error(f"Error enriching part data: {e}")
            return part_data
    
    def _update_part_with_enriched_data(self, part_data, enriched_data):
        """
        Update part data with enriched information
        
        Args:
            part_data (dict): Original part data
            enriched_data (dict): Enriched data from APIs
        """
        # Update basic fields if they're empty in original data
        for field in ['description', 'weight', 'dimensions', 'manufacturer']:
            if field in enriched_data and (field not in part_data or not part_data[field]):
                part_data[field] = enriched_data[field]
        
        # Update or add details
        if 'details' in enriched_data:
            if 'details' not in part_data:
                part_data['details'] = {}
            
            for key, value in enriched_data['details'].items():
                if key not in part_data['details']:
                    part_data['details'][key] = value
        
        # Update or add compatibility information
        if 'compatibility' in enriched_data and enriched_data['compatibility']:
            if 'compatibility' not in part_data:
                part_data['compatibility'] = []
            
            # Add new compatibility entries that don't exist in original data
            existing_compat = {(c.get('make', ''), c.get('model', '')): c for c in part_data['compatibility']}
            
            for compat in enriched_data['compatibility']:
                key = (compat.get('make', ''), compat.get('model', ''))
                if key not in existing_compat:
                    part_data['compatibility'].append(compat)
        
        # Add images if available
        if 'images' in enriched_data and enriched_data['images']:
            if 'images' not in part_data:
                part_data['images'] = []
            
            # Add new images that don't exist in original data
            existing_images = {img.get('path', ''): img for img in part_data['images']}
            
            for img in enriched_data['images']:
                path = img.get('path', '')
                if path and path not in existing_images:
                    part_data['images'].append(img)
    
    def _query_manufacturer_api(self, manufacturer, catalog_number):
        """
        Query manufacturer-specific API for part information
        
        Args:
            manufacturer (str): Manufacturer name
            catalog_number (str): Catalog number/part number
            
        Returns:
            dict: Part information from manufacturer API or None if not found
        """
        try:
            manufacturer_key = manufacturer.lower()
            
            if manufacturer_key not in self.api_keys:
                logger.warning(f"No API key found for manufacturer: {manufacturer}")
                return None
            
            if manufacturer_key not in self.base_urls:
                logger.warning(f"No base URL found for manufacturer: {manufacturer}")
                return None
            
            api_key = self.api_keys[manufacturer_key]
            base_url = self.base_urls[manufacturer_key]
            
            # Build the request URL
            url = f"{base_url}/parts/{catalog_number}"
            
            # Make the request
            headers = {
                'Authorization': f'Bearer {api_key}',
                'Accept': 'application/json'
            }
            
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            
            # Parse the response
            data = response.json()
            
            # Map the response to our format
            result = {
                'description': data.get('description', ''),
                'weight': data.get('weight', 0),
                'dimensions': data.get('dimensions', ''),
                'details': {}
            }
            
            # Map additional details
            for key, value in data.get('attributes', {}).items():
                result['details'][key] = value
            
            # Map compatibility information
            result['compatibility'] = []
            for vehicle in data.get('compatible_vehicles', []):
                compat = {
                    'make': vehicle.get('make', ''),
                    'model': vehicle.get('model', ''),
                    'year_from': vehicle.get('year_from', 0),
                    'year_to': vehicle.get('year_to', 9999),
                    'engine_type': vehicle.get('engine', ''),
                    'notes': vehicle.get('notes', '')
                }
                result['compatibility'].append(compat)
            
            # Map images
            result['images'] = []
            for img_url in data.get('images', []):
                img = {
                    'path': img_url,
                    'is_primary': len(result['images']) == 0,  # First image is primary
                    'description': f"{manufacturer} {catalog_number} image"
                }
                result['images'].append(img)
            
            logger.info(f"Successfully queried manufacturer API for {manufacturer} {catalog_number}")
            return result
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Error querying manufacturer API: {e}")
            return None
        except Exception as e:
            logger.error(f"Error processing manufacturer API response: {e}")
            return None
    
    def _query_generic_parts_db(self, part_id, catalog_number, manufacturer):
        """
        Query generic parts database API for part information
        
        Args:
            part_id (str): Internal part ID
            catalog_number (str): Catalog number/part number
            manufacturer (str): Manufacturer name
            
        Returns:
            dict: Part information from generic parts database or None if not found
        """
        try:
            if 'generic_parts_db' not in self.api_keys:
                logger.warning("No API key found for generic parts database")
                return None
            
            if 'generic_parts_db' not in self.base_urls:
                logger.warning("No base URL found for generic parts database")
                return None
            
            api_key = self.api_keys['generic_parts_db']
            base_url = self.base_urls['generic_parts_db']
            
            # Build the request URL and parameters
            url = f"{base_url}/api/parts/search"
            params = {
                'catalog_number': catalog_number,
                'manufacturer': manufacturer
            }
            
            # Make the request
            headers = {
                'X-API-Key': api_key,
                'Accept': 'application/json'
            }
            
            response = requests.get(url, headers=headers, params=params)
            response.raise_for_status()
            
            # Parse the response
            data = response.json()
            
            # Check if we got any results
            if not data.get('results', []):
                logger.warning(f"No results found in generic parts database for {catalog_number}")
                return None
            
            # Use the first result
            part_data = data['results'][0]
            
            # Map the response to our format
            result = {
                'description': part_data.get('description', ''),
                'weight': part_data.get('weight_kg', 0),
                'dimensions': part_data.get('dimensions', ''),
                'details': {}
            }
            
            # Map additional details
            for key, value in part_data.get('specifications', {}).items():
                result['details'][key] = value
            
            # Map compatibility information
            result['compatibility'] = []
            for vehicle in part_data.get('fits_vehicles', []):
                compat = {
                    'make': vehicle.get('make', ''),
                    'model': vehicle.get('model', ''),
                    'year_from': vehicle.get('year_start', 0),
                    'year_to': vehicle.get('year_end', 9999),
                    'engine_type': vehicle.get('engine', ''),
                    'notes': vehicle.get('notes', '')
                }
                result['compatibility'].append(compat)
            
            # Map images
            result['images'] = []
            for img_data in part_data.get('images', []):
                img = {
                    'path': img_data.get('url', ''),
                    'is_primary': img_data.get('is_primary', False),
                    'description': img_data.get('description', '')
                }
                result['images'].append(img)
            
            logger.info(f"Successfully queried generic parts database for {catalog_number}")
            return result
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Error querying generic parts database: {e}")
            return None
        except Exception as e:
            logger.error(f"Error processing generic parts database response: {e}")
            return None
    
    def _query_technical_specs_api(self, part_id, catalog_number):
        """
        Query technical specifications API for detailed part information
        
        Args:
            part_id (str): Internal part ID
            catalog_number (str): Catalog number/part number
            
        Returns:
            dict: Technical specifications or None if not found
        """
        try:
            if 'technical_specs' not in self.api_keys:
                logger.warning("No API key found for technical specs API")
                return None
            
            if 'technical_specs' not in self.base_urls:
                logger.warning("No base URL found for technical specs API")
                return None
            
            api_key = self.api_keys['technical_specs']
            base_url = self.base_urls['technical_specs']
            
            # Build the request URL
            url = f"{base_url}/api/v1/parts/specs"
            params = {
                'part_number': catalog_number
            }
            
            # Make the request
            headers = {
                'Authorization': f'ApiKey {api_key}',
                'Accept': 'application/json'
            }
            
            response = requests.get(url, headers=headers, params=params)
            response.raise_for_status()
            
            # Parse the response
            data = response.json()
            
            # Check if we got any results
            if not data.get('specs', {}):
                logger.warning(f"No technical specs found for {catalog_number}")
                return None
            
            # Map the response to our format
            result = {
                'details': {}
            }
            
            # Map technical specifications to details
            for category, specs in data['specs'].items():
                for key, value in specs.items():
                    detail_key = f"{category}_{key}".lower().replace(' ', '_')
                    result['details'][detail_key] = value
            
            logger.info(f"Successfully queried technical specs API for {catalog_number}")
            return result
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Error querying technical specs API: {e}")
            return None
        except Exception as e:
            logger.error(f"Error processing technical specs API response: {e}")
            return None

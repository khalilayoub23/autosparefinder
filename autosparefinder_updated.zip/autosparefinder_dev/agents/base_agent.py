import logging
import json
import os
from abc import ABC, abstractmethod
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class AIAgent(ABC):
    """
    Abstract base class for all AI agents in the AutoSpareFinder system
    """
    
    def __init__(self, agent_id, name, model_type="gpt-4", config=None):
        """
        Initialize the AI agent
        
        Args:
            agent_id (str): Unique identifier for the agent
            name (str): Human-readable name for the agent
            model_type (str): Type of AI model to use
            config (dict, optional): Configuration parameters for the agent
        """
        self.agent_id = agent_id
        self.name = name
        self.model_type = model_type
        self.config = config or {}
        self.created_at = datetime.now()
        self.last_active = None
        self.status = "initialized"
        
        # Initialize agent-specific components
        self._initialize_components()
        
        logger.info(f"Agent {self.name} (ID: {self.agent_id}) initialized with model {self.model_type}")
    
    @abstractmethod
    def _initialize_components(self):
        """Initialize agent-specific components"""
        pass
    
    @abstractmethod
    def process(self, input_data):
        """
        Process input data and return a response
        
        Args:
            input_data: Input data to process
            
        Returns:
            dict: Processing result
        """
        pass
    
    def update_status(self, status):
        """
        Update the agent's status
        
        Args:
            status (str): New status
        """
        self.status = status
        self.last_active = datetime.now()
        logger.info(f"Agent {self.name} status updated to: {status}")
    
    def get_info(self):
        """
        Get information about the agent
        
        Returns:
            dict: Agent information
        """
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "model_type": self.model_type,
            "status": self.status,
            "created_at": self.created_at.isoformat(),
            "last_active": self.last_active.isoformat() if self.last_active else None
        }
    
    def save_state(self, filepath=None):
        """
        Save the agent's state to a file
        
        Args:
            filepath (str, optional): Path to save the state file
            
        Returns:
            str: Path to the saved state file
        """
        if filepath is None:
            # Create a default filepath if none is provided
            os.makedirs("agent_states", exist_ok=True)
            filepath = f"agent_states/{self.agent_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        # Get the agent's state
        state = self.get_state()
        
        # Save the state to a file
        with open(filepath, 'w') as f:
            json.dump(state, f, indent=2)
        
        logger.info(f"Agent {self.name} state saved to {filepath}")
        return filepath
    
    def load_state(self, filepath):
        """
        Load the agent's state from a file
        
        Args:
            filepath (str): Path to the state file
            
        Returns:
            bool: True if the state was loaded successfully, False otherwise
        """
        try:
            # Load the state from a file
            with open(filepath, 'r') as f:
                state = json.load(f)
            
            # Set the agent's state
            self.set_state(state)
            
            logger.info(f"Agent {self.name} state loaded from {filepath}")
            return True
        except Exception as e:
            logger.error(f"Error loading agent state: {e}")
            return False
    
    @abstractmethod
    def get_state(self):
        """
        Get the agent's current state
        
        Returns:
            dict: Agent state
        """
        # Base state that all agents should include
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "model_type": self.model_type,
            "status": self.status,
            "created_at": self.created_at.isoformat(),
            "last_active": self.last_active.isoformat() if self.last_active else None
        }
    
    @abstractmethod
    def set_state(self, state):
        """
        Set the agent's state
        
        Args:
            state (dict): Agent state
        """
        # Set base state properties
        self.agent_id = state.get("agent_id", self.agent_id)
        self.name = state.get("name", self.name)
        self.model_type = state.get("model_type", self.model_type)
        self.status = state.get("status", self.status)
        
        # Parse datetime strings
        if "created_at" in state:
            try:
                self.created_at = datetime.fromisoformat(state["created_at"])
            except (ValueError, TypeError):
                pass
        
        if "last_active" in state and state["last_active"]:
            try:
                self.last_active = datetime.fromisoformat(state["last_active"])
            except (ValueError, TypeError):
                pass

import logging
import json
from datetime import datetime
from .base_agent import AIAgent

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class QualityControlAgent(AIAgent):
    """
    Quality Control Agent (Ido) - Responsible for identifying issues, mismatches,
    performing quality checks, and flagging parts at risk.
    """
    
    def __init__(self, agent_id, name="Ido", model_type="gpt-4", config=None):
        """
        Initialize the Quality Control Agent
        
        Args:
            agent_id (str): Unique identifier for the agent
            name (str): Human-readable name for the agent
            model_type (str): Type of AI model to use
            config (dict, optional): Configuration parameters for the agent
        """
        super().__init__(agent_id, name, model_type, config)
        
        # Quality control agent specific attributes
        self.quality_thresholds = self.config.get('quality_thresholds', {
            'high': 90,
            'medium': 70,
            'low': 50
        })
        self.check_history = []
        
        logger.info(f"Quality Control Agent {self.name} initialized with {len(self.quality_thresholds)} quality thresholds")
    
    def _initialize_components(self):
        """Initialize agent-specific components"""
        # Set up quality check rules
        self.quality_rules = {
            'critical_fields': ['part_id', 'name', 'category'],
            'recommended_fields': ['description', 'manufacturer', 'weight', 'dimensions'],
            'price_rules': {
                'min_price': 0.01,
                'max_markup': 500  # percentage
            }
        }
        
        logger.info(f"Quality Control Agent components initialized with {len(self.quality_rules)} rule categories")
    
    def process(self, input_data):
        """
        Process quality control requests
        
        Args:
            input_data (dict): Input data containing part information or batch of parts
            
        Returns:
            dict: Processing result
        """
        self.update_status("processing")
        
        try:
            # Check if this is a batch request or single part
            if 'parts' in input_data:
                return self._batch_quality_check(input_data['parts'])
            else:
                return self._check_part_quality(input_data)
        
        except Exception as e:
            logger.error(f"Error processing quality control request: {e}")
            return {
                'status': 'error',
                'message': str(e)
            }
        finally:
            self.update_status("idle")
    
    def _check_part_quality(self, part_data):
        """
        Analyze part data for quality issues
        
        Args:
            part_data (dict): Dictionary containing part information
            
        Returns:
            dict: Quality assessment results
        """
        issues = []
        warnings = []
        quality_score = 100
        risk_level = "low"
        
        # Check for missing critical information
        for field in self.quality_rules['critical_fields']:
            if field not in part_data or not part_data[field]:
                issues.append(f"Missing critical field: {field}")
                quality_score -= 20
                risk_level = "high"
        
        # Check for missing recommended information
        for field in self.quality_rules['recommended_fields']:
            if field not in part_data or not part_data[field]:
                warnings.append(f"Missing recommended field: {field}")
                quality_score -= 5
        
        # Check for price anomalies
        if "price" in part_data:
            price = part_data["price"]
            if price < self.quality_rules['price_rules']['min_price']:
                issues.append(f"Invalid price: {price} (below minimum)")
                quality_score -= 15
                risk_level = "medium"
            
            # Check for cost vs price if both are available
            if "cost" in part_data and part_data["cost"] > 0:
                cost = part_data["cost"]
                markup = ((price - cost) / cost) * 100
                if markup > self.quality_rules['price_rules']['max_markup']:
                    warnings.append(f"Unusually high markup: {markup:.1f}%")
                    quality_score -= 10
        else:
            warnings.append("Missing price information")
            quality_score -= 10
        
        # Check for compatibility information
        if "compatibility" not in part_data or not part_data["compatibility"]:
            warnings.append("Missing compatibility information")
            quality_score -= 10
        
        # Ensure quality score is within bounds
        quality_score = max(0, min(100, quality_score))
        
        # Determine risk level based on quality score
        if quality_score < self.quality_thresholds['low']:
            risk_level = "high"
        elif quality_score < self.quality_thresholds['medium']:
            risk_level = "medium"
        
        # Prepare assessment result
        assessment = {
            "status": "success",
            "part_id": part_data.get("part_id", "unknown"),
            "part_name": part_data.get("name", "unknown"),
            "quality_score": quality_score,
            "risk_level": risk_level,
            "issues": issues,
            "warnings": warnings,
            "passed": len(issues) == 0,
            "timestamp": datetime.now().isoformat()
        }
        
        # Log the check
        self.check_history.append({
            "part_id": assessment["part_id"],
            "quality_score": quality_score,
            "risk_level": risk_level,
            "timestamp": assessment["timestamp"]
        })
        
        logger.info(f"Quality check for part {assessment['part_id']}: Score {quality_score}, Risk level {risk_level}")
        return assessment
    
    def _batch_quality_check(self, parts_list):
        """
        Perform quality checks on a batch of parts
        
        Args:
            parts_list (list): List of part dictionaries
            
        Returns:
            dict: Summary of quality check results
        """
        if not parts_list:
            return {
                "status": "error",
                "message": "No parts provided for batch quality check"
            }
        
        results = []
        issues_count = 0
        high_risk_count = 0
        total_score = 0
        
        for part in parts_list:
            assessment = self._check_part_quality(part)
            results.append(assessment)
            
            if not assessment["passed"]:
                issues_count += 1
            
            if assessment["risk_level"] == "high":
                high_risk_count += 1
            
            total_score += assessment["quality_score"]
        
        avg_score = total_score / len(parts_list) if parts_list else 0
        
        summary = {
            "status": "success",
            "total_parts": len(parts_list),
            "issues_found": issues_count,
            "high_risk_parts": high_risk_count,
            "average_quality_score": avg_score,
            "pass_rate": (len(parts_list) - issues_count) / len(parts_list) if len(parts_list) > 0 else 0,
            "detailed_results": results,
            "timestamp": datetime.now().isoformat()
        }
        
        logger.info(f"Batch quality check completed: {issues_count} issues found in {len(parts_list)} parts, avg score: {avg_score:.1f}")
        return summary
    
    def get_state(self):
        """
        Get the agent's current state
        
        Returns:
            dict: Agent state
        """
        # Get base state from parent class
        state = super().get_state()
        
        # Add quality control agent specific state
        state.update({
            'quality_thresholds': self.quality_thresholds,
            'check_history': self.check_history[-100:] if self.check_history else []  # Keep last 100 checks
        })
        
        return state
    
    def set_state(self, state):
        """
        Set the agent's state
        
        Args:
            state (dict): Agent state
        """
        # Set base state from parent class
        super().set_state(state)
        
        # Set quality control agent specific state
        self.quality_thresholds = state.get('quality_thresholds', self.quality_thresholds)
        self.check_history = state.get('check_history', [])

import logging
import json
from datetime import datetime
from .base_agent import AIAgent

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class TechnicalSupportAgent(AIAgent):
    """
    AI agent responsible for providing technical information and compatibility assistance
    """
    
    def __init__(self, agent_id, name="Technical Support Agent", model_type="gpt-4", config=None):
        """
        Initialize the Technical Support Agent
        
        Args:
            agent_id (str): Unique identifier for the agent
            name (str): Human-readable name for the agent
            model_type (str): Type of AI model to use
            config (dict, optional): Configuration parameters for the agent
        """
        # Initialize knowledge base and other attributes before calling parent constructor
        # to ensure they exist before _initialize_components is called
        self.knowledge_base = {} if config is None else config.get('knowledge_base', {})
        self.interaction_history = []
        self.compatibility_rules = [] if config is None else config.get('compatibility_rules', [])
        self.kb_categories = {}
        self.compatibility_cache = {}
        
        # Now call parent constructor which will call _initialize_components
        super().__init__(agent_id, name, model_type, config)
        
        logger.info(f"Technical Support Agent {self.name} initialized with {len(self.knowledge_base)} knowledge items")
    
    def _initialize_components(self):
        """Initialize agent-specific components"""
        # Set up knowledge base access
        for category, items in self.knowledge_base.items():
            self.kb_categories[category] = len(items)
        
        logger.info(f"Technical Support Agent components initialized with {len(self.kb_categories)} knowledge categories")
    
    def process(self, input_data):
        """
        Process technical support requests
        
        Args:
            input_data (dict): Input data containing technical query or request
            
        Returns:
            dict: Processing result
        """
        self.update_status("processing")
        
        try:
            request_type = input_data.get('request_type', '')
            
            if request_type == 'technical_query':
                return self._answer_technical_query(input_data)
            elif request_type == 'compatibility_check':
                return self._check_compatibility(input_data)
            elif request_type == 'installation_guide':
                return self._provide_installation_guide(input_data)
            elif request_type == 'troubleshooting':
                return self._provide_troubleshooting(input_data)
            else:
                logger.warning(f"Unknown request type: {request_type}")
                return {
                    'status': 'error',
                    'message': f"Unknown request type: {request_type}"
                }
        
        except Exception as e:
            logger.error(f"Error processing technical support request: {e}")
            return {
                'status': 'error',
                'message': str(e)
            }
        finally:
            self.update_status("idle")
    
    def _answer_technical_query(self, input_data):
        """
        Answer a technical query about a part or vehicle
        
        Args:
            input_data (dict): Query information
            
        Returns:
            dict: Answer to the query
        """
        query = input_data.get('query', '')
        part_id = input_data.get('part_id', '')
        vehicle_make = input_data.get('vehicle_make', '')
        vehicle_model = input_data.get('vehicle_model', '')
        
        if not query:
            return {'status': 'error', 'message': 'No query provided'}
        
        # Log the interaction
        self.interaction_history.append({
            'timestamp': datetime.now().isoformat(),
            'type': 'technical_query',
            'query': query,
            'part_id': part_id,
            'vehicle_make': vehicle_make,
            'vehicle_model': vehicle_model
        })
        
        # In a real implementation, this would use NLP to understand the query
        # and retrieve relevant information from the knowledge base
        
        # For now, we'll provide a simple response based on the query keywords
        response = "I don't have specific information about that query."
        
        # Check if we have information about the specific part
        if part_id and part_id in self.knowledge_base.get('parts', {}):
            part_info = self.knowledge_base['parts'][part_id]
            response = f"Information about part {part_id}: {part_info}"
        
        # Check if we have information about the vehicle
        elif vehicle_make and vehicle_model:
            vehicle_key = f"{vehicle_make}_{vehicle_model}".lower()
            if vehicle_key in self.knowledge_base.get('vehicles', {}):
                vehicle_info = self.knowledge_base['vehicles'][vehicle_key]
                response = f"Information about {vehicle_make} {vehicle_model}: {vehicle_info}"
        
        # Check for common keywords in the query
        elif 'installation' in query.lower():
            response = "For installation guides, please provide a specific part number."
        elif 'compatibility' in query.lower():
            response = "To check compatibility, please provide both part number and vehicle details."
        elif 'warranty' in query.lower():
            response = "Most parts come with a 1-year warranty. Please check the specific part details for more information."
        
        logger.info(f"Answered technical query: {query}")
        
        return {
            'status': 'success',
            'query': query,
            'answer': response
        }
    
    def _check_compatibility(self, input_data):
        """
        Check compatibility between a part and a vehicle
        
        Args:
            input_data (dict): Part and vehicle information
            
        Returns:
            dict: Compatibility check result
        """
        part_id = input_data.get('part_id', '')
        vehicle_make = input_data.get('vehicle_make', '')
        vehicle_model = input_data.get('vehicle_model', '')
        vehicle_year = input_data.get('vehicle_year', '')
        
        if not part_id:
            return {'status': 'error', 'message': 'No part ID provided'}
        if not vehicle_make or not vehicle_model:
            return {'status': 'error', 'message': 'Vehicle make and model are required'}
        
        # Generate a cache key
        cache_key = f"{part_id}_{vehicle_make}_{vehicle_model}_{vehicle_year}"
        
        # Check if we have a cached result
        if cache_key in self.compatibility_cache:
            return self.compatibility_cache[cache_key]
        
        # Log the interaction
        self.interaction_history.append({
            'timestamp': datetime.now().isoformat(),
            'type': 'compatibility_check',
            'part_id': part_id,
            'vehicle_make': vehicle_make,
            'vehicle_model': vehicle_model,
            'vehicle_year': vehicle_year
        })
        
        # In a real implementation, this would check a database of compatibility information
        # For now, we'll use a simple rule-based approach
        
        # Check if we have specific compatibility rules for this part
        compatible = False
        confidence = 0
        notes = "No specific compatibility information available."
        
        for rule in self.compatibility_rules:
            if rule.get('part_id') == part_id:
                # Check if the vehicle matches the rule
                if (rule.get('vehicle_make', '').lower() == vehicle_make.lower() and
                    rule.get('vehicle_model', '').lower() == vehicle_model.lower()):
                    
                    # Check year range if provided
                    if vehicle_year and rule.get('year_from') and rule.get('year_to'):
                        try:
                            year = int(vehicle_year)
                            year_from = int(rule.get('year_from', 0))
                            year_to = int(rule.get('year_to', 9999))
                            
                            if year_from <= year <= year_to:
                                compatible = True
                                confidence = 95
                                notes = rule.get('notes', 'Compatible based on manufacturer data.')
                            else:
                                compatible = False
                                confidence = 80
                                notes = f"This part is designed for {vehicle_make} {vehicle_model} models from {year_from} to {year_to}."
                        except ValueError:
                            # If year conversion fails, fall back to make/model only
                            compatible = True
                            confidence = 70
                            notes = "Compatible based on make and model, but year information could not be verified."
                    else:
                        # If no year information, match based on make/model only
                        compatible = True
                        confidence = 80
                        notes = "Compatible based on make and model."
                    
                    # Once we find a matching rule, we can break
                    break
        
        # If no specific rule was found, make an educated guess
        if confidence == 0:
            # Check if we have any rules for this make/model
            for rule in self.compatibility_rules:
                if (rule.get('vehicle_make', '').lower() == vehicle_make.lower() and
                    rule.get('vehicle_model', '').lower() == vehicle_model.lower()):
                    
                    # We have some information about this vehicle, so we can make a better guess
                    compatible = False
                    confidence = 30
                    notes = "This part is not specifically listed as compatible with your vehicle, but we have limited information."
                    break
            
            # If we still don't have any information, provide a very low confidence response
            if confidence == 0:
                compatible = False
                confidence = 10
                notes = "We don't have specific compatibility information for this combination. Please consult with a mechanic."
        
        # Create the result
        result = {
            'status': 'success',
            'compatible': compatible,
            'confidence': confidence,
            'notes': notes,
            'part_id': part_id,
            'vehicle': {
                'make': vehicle_make,
                'model': vehicle_model,
                'year': vehicle_year
            }
        }
        
        # Cache the result
        self.compatibility_cache[cache_key] = result
        
        logger.info(f"Checked compatibility for part {part_id} with {vehicle_make} {vehicle_model} {vehicle_year}: {compatible}")
        
        return result
    
    def _provide_installation_guide(self, input_data):
        """
        Provide installation guide for a part
        
        Args:
            input_data (dict): Part information
            
        Returns:
            dict: Installation guide
        """
        part_id = input_data.get('part_id', '')
        vehicle_make = input_data.get('vehicle_make', '')
        vehicle_model = input_data.get('vehicle_model', '')
        
        if not part_id:
            return {'status': 'error', 'message': 'No part ID provided'}
        
        # Log the interaction
        self.interaction_history.append({
            'timestamp': datetime.now().isoformat(),
            'type': 'installation_guide',
            'part_id': part_id,
            'vehicle_make': vehicle_make,
            'vehicle_model': vehicle_model
        })
        
        # In a real implementation, this would retrieve an installation guide from a database
        # For now, we'll provide a generic guide based on the part type
        
        # Extract part type from part ID (assuming a naming convention)
        part_type = "unknown"
        if part_id.startswith("BP"):
            part_type = "brake_pad"
        elif part_id.startswith("OF"):
            part_type = "oil_filter"
        elif part_id.startswith("AF"):
            part_type = "air_filter"
        
        # Provide a guide based on part type
        guide = "No specific installation guide available for this part."
        
        if part_type == "brake_pad":
            guide = """
            Brake Pad Installation Guide:
            1. Ensure the vehicle is safely supported on jack stands
            2. Remove the wheel
            3. Remove the caliper bolts and swing the caliper away
            4. Remove the old brake pads
            5. Compress the caliper piston
            6. Install the new brake pads
            7. Reinstall the caliper and bolts
            8. Reinstall the wheel
            9. Pump the brake pedal to restore pressure before driving
            """
        elif part_type == "oil_filter":
            guide = """
            Oil Filter Installation Guide:
            1. Drain the engine oil
            2. Locate the oil filter
            3. Remove the old oil filter using an oil filter wrench
            4. Apply a thin film of oil to the gasket of the new filter
            5. Screw on the new filter by hand until the gasket contacts the engine
            6. Tighten the filter an additional 3/4 turn
            7. Refill the engine with the recommended oil
            8. Start the engine and check for leaks
            """
        elif part_type == "air_filter":
            guide = """
            Air Filter Installation Guide:
            1. Locate the air filter housing
            2. Open the housing (usually secured by clips or screws)
            3. Remove the old air filter
            4. Clean the housing of any debris
            5. Insert the new air filter, ensuring it's properly seated
            6. Close and secure the air filter housing
            """
        
        logger.info(f"Provided installation guide for part {part_id} (type: {part_type})")
        
        return {
            'status': 'success',
            'part_id': part_id,
            'part_type': part_type,
            'installation_guide': guide
        }
    
    def _provide_troubleshooting(self, input_data):
        """
        Provide troubleshooting advice for a problem
        
        Args:
            input_data (dict): Problem information
            
        Returns:
            dict: Troubleshooting advice
        """
        problem = input_data.get('problem', '')
        vehicle_make = input_data.get('vehicle_make', '')
        vehicle_model = input_data.get('vehicle_model', '')
        
        if not problem:
            return {'status': 'error', 'message': 'No problem description provided'}
        
        # Log the interaction
        self.interaction_history.append({
            'timestamp': datetime.now().isoformat(),
            'type': 'troubleshooting',
            'problem': problem,
            'vehicle_make': vehicle_make,
            'vehicle_model': vehicle_model
        })
        
        # In a real implementation, this would use NLP to understand the problem
        # and provide relevant troubleshooting steps
        
        # For now, we'll provide generic advice based on keywords in the problem description
        advice = "I don't have specific troubleshooting advice for that problem."
        
        problem_lower = problem.lower()
        
        if 'brake' in problem_lower and ('squeak' in problem_lower or 'noise' in problem_lower):
            advice = """
            Brake Squeak Troubleshooting:
            1. Check if the noise occurs only when applying brakes or all the time
            2. If only when braking, it could be:
               - Normal break-in noise from new brake pads
               - Worn brake pads that need replacement
               - Glazed brake pads or rotors
            3. If constant, it could be:
               - A small stone caught between the brake pad and rotor
               - A bent backing plate rubbing against the rotor
            4. Inspect the brake pads for wear and replace if less than 3mm thick
            5. Check rotors for scoring or warping
            6. Apply brake lubricant to the back of the pads and contact points
            """
        elif 'engine' in problem_lower and 'overheat' in problem_lower:
            advice = """
            Engine Overheating Troubleshooting:
            1. Check coolant level when engine is cool
            2. Inspect for visible coolant leaks
            3. Check radiator for blockage or damage
            4. Ensure the radiator fan is operating properly
            5. Check the thermostat operation
            6. Inspect the water pump for leaks or noise
            7. Check the radiator cap for proper sealing
            8. Look for air in the cooling system
            9. Consider having the cooling system pressure tested
            """
        elif 'start' in problem_lower and ('won\'t' in problem_lower or 'not' in problem_lower or 'doesn\'t' in problem_lower):
            advice = """
            Vehicle Won't Start Troubleshooting:
            1. Check if the dashboard lights come on when turning the key
            2. If no lights: Check battery connections and battery charge
            3. If lights come on but engine doesn't crank:
               - Check starter connections
               - Test the starter motor
               - Check the ignition switch
            4. If engine cranks but doesn't start:
               - Check for fuel (gauge, listen for fuel pump)
               - Check spark (remove a spark plug and test for spark)
               - Check for proper compression
               - Check engine immobilizer or security system
            5. If it occasionally starts, check for loose connections
            """
        elif ('check' in problem_lower and 'engine' in problem_lower) or 'cel' in problem_lower or 'code' in problem_lower:
            advice = """
            Check Engine Light Troubleshooting:
            1. Use an OBD-II scanner to retrieve the error codes
            2. Common causes include:
               - Loose gas cap
               - Faulty oxygen sensor
               - Catalytic converter issues
               - Mass airflow sensor problems
               - Spark plug or ignition coil failures
            3. After fixing the issue, clear the codes and see if the light returns
            4. If the light is flashing, reduce speed and load immediately and get the vehicle serviced
            5. Some auto parts stores offer free code reading services
            """
        
        logger.info(f"Provided troubleshooting advice for problem: {problem[:50]}...")
        
        return {
            'status': 'success',
            'problem': problem,
            'troubleshooting_advice': advice
        }
    
    def get_state(self):
        """
        Get the agent's current state
        
        Returns:
            dict: Agent state
        """
        # Get base state from parent class
        state = super().get_state()
        
        # Add technical support agent specific state
        state.update({
            'kb_categories': self.kb_categories,
            'interaction_history': self.interaction_history[-50:] if self.interaction_history else [],  # Keep last 50 interactions
            'compatibility_cache_size': len(self.compatibility_cache)
        })
        
        return state
    
    def set_state(self, state):
        """
        Set the agent's state
        
        Args:
            state (dict): Agent state
        """
        # Set base state from parent class
        super().set_state(state)
        
        # Set technical support agent specific state
        self.kb_categories = state.get('kb_categories', {})
        self.interaction_history = state.get('interaction_history', [])
        # We don't restore the compatibility cache as it might be outdated

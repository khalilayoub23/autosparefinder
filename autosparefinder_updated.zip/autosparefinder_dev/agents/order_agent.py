import logging
import json
from datetime import datetime
from .base_agent import AIAgent

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class OrderAgent(AIAgent):
    """
    AI agent responsible for managing orders from international suppliers
    """
    
    def __init__(self, agent_id, name="Order Agent", model_type="gpt-4", config=None):
        """
        Initialize the Order Agent
        
        Args:
            agent_id (str): Unique identifier for the agent
            name (str): Human-readable name for the agent
            model_type (str): Type of AI model to use
            config (dict, optional): Configuration parameters for the agent
        """
        # Initialize with default supplier for testing
        self.supplier_apis = {
            'default_supplier': {
                'name': 'Default Test Supplier',
                'api_key': 'test_key',
                'base_url': 'http://example.com/api',
                'enabled': True
            }
        }
        
        self.pending_orders = []
        self.completed_orders = []
        self.supplier_preferences = {} if config is None else config.get('supplier_preferences', {})
        self.order_history = []
        self.order_tracking = {}
        
        # Now call parent constructor which will call _initialize_components
        super().__init__(agent_id, name, model_type, config)
        
        logger.info(f"Order Agent {self.name} initialized with {len(self.supplier_preferences)} supplier preferences")
    
    def _initialize_components(self):
        """Initialize agent-specific components"""
        # Set up additional supplier API connections from config
        suppliers = self.config.get('suppliers', []) if self.config else []
        
        for supplier in suppliers:
            supplier_id = supplier.get('id')
            if supplier_id:
                self.supplier_apis[supplier_id] = {
                    'name': supplier.get('name', ''),
                    'api_key': supplier.get('api_key', ''),
                    'base_url': supplier.get('base_url', ''),
                    'enabled': supplier.get('enabled', True)
                }
        
        logger.info(f"Order Agent components initialized with {len(self.supplier_apis)} supplier APIs")
    
    def process(self, input_data):
        """
        Process order-related requests
        
        Args:
            input_data (dict): Input data containing order information or request
            
        Returns:
            dict: Processing result
        """
        self.update_status("processing")
        
        try:
            request_type = input_data.get('request_type', '')
            
            if request_type == 'create_order':
                return self._create_order(input_data)
            elif request_type == 'check_order_status':
                return self._check_order_status(input_data)
            elif request_type == 'cancel_order':
                return self._cancel_order(input_data)
            elif request_type == 'find_best_supplier':
                return self._find_best_supplier(input_data)
            else:
                logger.warning(f"Unknown request type: {request_type}")
                return {
                    'status': 'error',
                    'message': f"Unknown request type: {request_type}"
                }
        
        except Exception as e:
            logger.error(f"Error processing order request: {e}")
            return {
                'status': 'error',
                'message': str(e)
            }
        finally:
            self.update_status("idle")
    
    def _create_order(self, input_data):
        """
        Create a new order with a supplier
        
        Args:
            input_data (dict): Order information
            
        Returns:
            dict: Order creation result
        """
        # Extract order details
        parts = input_data.get('parts', [])
        customer_id = input_data.get('customer_id', '')
        shipping_address = input_data.get('shipping_address', {})
        supplier_id = input_data.get('supplier_id', '')
        
        # Validate input
        if not parts:
            return {'status': 'error', 'message': 'No parts specified in order'}
        
        # If no supplier specified, find the best one
        if not supplier_id:
            best_supplier_result = self._find_best_supplier({'parts': parts})
            if best_supplier_result.get('status') == 'success':
                supplier_id = best_supplier_result.get('supplier_id', '')
            else:
                return best_supplier_result
        
        # Generate order ID
        order_id = f"ORD-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        # Create order object
        order = {
            'order_id': order_id,
            'supplier_id': supplier_id,
            'customer_id': customer_id,
            'parts': parts,
            'shipping_address': shipping_address,
            'status': 'pending',
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        }
        
        # Add to pending orders
        self.pending_orders.append(order)
        
        # Add to order history
        self.order_history.append({
            'timestamp': datetime.now().isoformat(),
            'action': 'create',
            'order_id': order_id,
            'details': 'Order created'
        })
        
        logger.info(f"Created order {order_id} with supplier {supplier_id}")
        
        return {
            'status': 'success',
            'message': 'Order created successfully',
            'order_id': order_id,
            'supplier_id': supplier_id
        }
    
    def _check_order_status(self, input_data):
        """
        Check the status of an existing order
        
        Args:
            input_data (dict): Order identifier
            
        Returns:
            dict: Order status information
        """
        order_id = input_data.get('order_id', '')
        
        if not order_id:
            return {'status': 'error', 'message': 'No order ID provided'}
        
        # Check pending orders
        for order in self.pending_orders:
            if order['order_id'] == order_id:
                return {
                    'status': 'success',
                    'order_status': order['status'],
                    'order_details': order
                }
        
        # Check completed orders
        for order in self.completed_orders:
            if order['order_id'] == order_id:
                return {
                    'status': 'success',
                    'order_status': order['status'],
                    'order_details': order
                }
        
        return {
            'status': 'error',
            'message': f'Order {order_id} not found'
        }
    
    def _cancel_order(self, input_data):
        """
        Cancel an existing order
        
        Args:
            input_data (dict): Order identifier
            
        Returns:
            dict: Cancellation result
        """
        order_id = input_data.get('order_id', '')
        
        if not order_id:
            return {'status': 'error', 'message': 'No order ID provided'}
        
        # Find and cancel the order
        for i, order in enumerate(self.pending_orders):
            if order['order_id'] == order_id:
                # Update order status
                order['status'] = 'cancelled'
                order['updated_at'] = datetime.now().isoformat()
                
                # Move to completed orders
                self.completed_orders.append(order)
                self.pending_orders.pop(i)
                
                # Add to order history
                self.order_history.append({
                    'timestamp': datetime.now().isoformat(),
                    'action': 'cancel',
                    'order_id': order_id,
                    'details': 'Order cancelled'
                })
                
                logger.info(f"Cancelled order {order_id}")
                
                return {
                    'status': 'success',
                    'message': f'Order {order_id} cancelled successfully'
                }
        
        return {
            'status': 'error',
            'message': f'Order {order_id} not found or already completed/cancelled'
        }
    
    def _find_best_supplier(self, input_data):
        """
        Find the best supplier for a given set of parts
        
        Args:
            input_data (dict): Parts information
            
        Returns:
            dict: Best supplier information
        """
        parts = input_data.get('parts', [])
        
        if not parts:
            return {'status': 'error', 'message': 'No parts specified'}
        
        # In a real implementation, this would query supplier APIs for availability and pricing
        # For now, we'll use a simple algorithm based on supplier preferences
        
        # Get all enabled suppliers
        enabled_suppliers = {
            supplier_id: details for supplier_id, details in self.supplier_apis.items()
            if details.get('enabled', True)
        }
        
        if not enabled_suppliers:
            return {'status': 'error', 'message': 'No enabled suppliers available'}
        
        # For this simplified version, just return the first enabled supplier
        # In a real implementation, we would score suppliers based on price, availability, shipping time, etc.
        supplier_id = next(iter(enabled_suppliers.keys()))
        supplier_name = enabled_suppliers[supplier_id].get('name', '')
        
        return {
            'status': 'success',
            'supplier_id': supplier_id,
            'supplier_name': supplier_name,
            'message': f'Selected {supplier_name} as the best supplier for the requested parts'
        }
    
    def get_state(self):
        """
        Get the agent's current state
        
        Returns:
            dict: Agent state
        """
        # Get base state from parent class
        state = super().get_state()
        
        # Add order agent specific state
        state.update({
            'pending_orders': self.pending_orders,
            'completed_orders': self.completed_orders,
            'supplier_preferences': self.supplier_preferences,
            'order_history': self.order_history
        })
        
        return state
    
    def set_state(self, state):
        """
        Set the agent's state
        
        Args:
            state (dict): Agent state
        """
        # Set base state from parent class
        super().set_state(state)
        
        # Set order agent specific state
        self.pending_orders = state.get('pending_orders', [])
        self.completed_orders = state.get('completed_orders', [])
        self.supplier_preferences = state.get('supplier_preferences', {})
        self.order_history = state.get('order_history', [])

import logging
import json
from datetime import datetime
import os
import sys

# Import base agent class
from .base_agent import AIAgent

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SalesAgent(AIAgent):
    """
    Sales Agent for AutoSpareFinder system.
    Handles customer interactions, product recommendations, and sales processes.
    Implements fallback mechanisms for when optional ML dependencies are not available.
    """
    
    def __init__(self, agent_id=None, name="Sales Agent", model_type="gpt-4", config=None):
        """
        Initialize the Sales Agent
        
        Args:
            agent_id (str): Unique identifier for the agent
            name (str): Name of the agent
            model_type (str): Type of AI model to use
            config (dict): Configuration parameters for the agent
        """
        super().__init__(agent_id, name, model_type, config)
    
    def _initialize_components(self):
        """Initialize agent-specific components"""
        self.ml_enabled = False
        
        # Try to import optional ML dependencies
        try:
            import torch
            import transformers
            self.ml_enabled = True
            logger.info("ML capabilities enabled for Sales Agent")
        except ImportError:
            logger.warning("ML libraries not available. Sales Agent will operate in basic mode.")
        
        # Initialize sales-specific attributes
        self.customer_history = {}
        self.product_recommendations = {}
        self.sales_metrics = {
            "interactions": 0,
            "recommendations": 0,
            "conversions": 0,
            "last_updated": datetime.now().isoformat()
        }
    
    def process(self, input_data):
        """
        Process a customer request
        
        Args:
            input_data (dict): Request data containing customer information and query
            
        Returns:
            dict: Response with recommendations and actions
        """
        self.sales_metrics["interactions"] += 1
        self.update_status("processing")
        
        # Extract customer info and query
        customer_id = input_data.get("customer_id", "anonymous")
        query = input_data.get("query", "")
        vehicle_info = input_data.get("vehicle_info", {})
        
        # Update customer history
        if customer_id not in self.customer_history:
            self.customer_history[customer_id] = []
        
        self.customer_history[customer_id].append({
            "timestamp": datetime.now().isoformat(),
            "query": query,
            "vehicle_info": vehicle_info
        })
        
        # Generate recommendations based on query and vehicle info
        recommendations = self._generate_recommendations(customer_id, query, vehicle_info)
        
        # Record recommendations
        self.sales_metrics["recommendations"] += len(recommendations)
        
        # Prepare response
        response = {
            "agent_id": self.agent_id,
            "agent_name": self.name,
            "timestamp": datetime.now().isoformat(),
            "recommendations": recommendations,
            "suggested_actions": self._suggest_actions(customer_id, recommendations)
        }
        
        self.update_status("idle")
        return response
    
    def _generate_recommendations(self, customer_id, query, vehicle_info):
        """
        Generate product recommendations based on customer query and vehicle info
        
        Args:
            customer_id (str): Customer ID
            query (str): Customer query
            vehicle_info (dict): Vehicle information
            
        Returns:
            list: List of recommended products
        """
        recommendations = []
        
        # Use ML-based recommendations if available, otherwise use rule-based approach
        if self.ml_enabled:
            try:
                recommendations = self._ml_based_recommendations(query, vehicle_info)
            except Exception as e:
                logger.error(f"Error in ML recommendations: {e}")
                recommendations = self._rule_based_recommendations(query, vehicle_info)
        else:
            recommendations = self._rule_based_recommendations(query, vehicle_info)
        
        return recommendations
    
    def _ml_based_recommendations(self, query, vehicle_info):
        """
        Generate recommendations using ML models
        
        Args:
            query (str): Customer query
            vehicle_info (dict): Vehicle information
            
        Returns:
            list: List of recommended products
        """
        # This would use PyTorch and transformers for advanced recommendations
        # Since we're in fallback mode, we'll simulate the results
        logger.info("Using ML-based recommendation engine")
        
        # Simulate ML processing
        recommendations = []
        
        # Extract key information from query and vehicle
        is_ev = vehicle_info.get("is_electric", False)
        manufacturer = vehicle_info.get("manufacturer", "")
        model = vehicle_info.get("model", "")
        year = vehicle_info.get("year", "")
        
        # Simulate recommendations based on vehicle type
        if is_ev:
            recommendations = [
                {
                    "part_id": "EV-BAT-001",
                    "name": "High-Performance EV Battery",
                    "compatibility": 0.95,
                    "price": 1200.00,
                    "availability": "In Stock"
                },
                {
                    "part_id": "EV-CHG-002",
                    "name": "Fast Charging Port",
                    "compatibility": 0.92,
                    "price": 350.00,
                    "availability": "In Stock"
                },
                {
                    "part_id": "EV-INV-003",
                    "name": "Advanced Inverter",
                    "compatibility": 0.88,
                    "price": 780.00,
                    "availability": "3-5 days"
                }
            ]
        else:
            recommendations = [
                {
                    "part_id": "ICE-FIL-001",
                    "name": "Premium Oil Filter",
                    "compatibility": 0.97,
                    "price": 25.00,
                    "availability": "In Stock"
                },
                {
                    "part_id": "ICE-BRK-002",
                    "name": "Performance Brake Pads",
                    "compatibility": 0.94,
                    "price": 120.00,
                    "availability": "In Stock"
                },
                {
                    "part_id": "ICE-SPK-003",
                    "name": "Iridium Spark Plugs",
                    "compatibility": 0.91,
                    "price": 45.00,
                    "availability": "In Stock"
                }
            ]
        
        return recommendations
    
    def _rule_based_recommendations(self, query, vehicle_info):
        """
        Generate recommendations using rule-based approach
        
        Args:
            query (str): Customer query
            vehicle_info (dict): Vehicle information
            
        Returns:
            list: List of recommended products
        """
        logger.info("Using rule-based recommendation engine")
        
        recommendations = []
        
        # Extract key information from query and vehicle
        is_ev = vehicle_info.get("is_electric", False)
        manufacturer = vehicle_info.get("manufacturer", "")
        model = vehicle_info.get("model", "")
        year = vehicle_info.get("year", "")
        
        # Simple rule-based recommendations
        if "battery" in query.lower():
            if is_ev:
                recommendations.append({
                    "part_id": "EV-BAT-001",
                    "name": "High-Performance EV Battery",
                    "compatibility": 0.95,
                    "price": 1200.00,
                    "availability": "In Stock"
                })
            else:
                recommendations.append({
                    "part_id": "ICE-BAT-001",
                    "name": "Standard 12V Battery",
                    "compatibility": 0.98,
                    "price": 120.00,
                    "availability": "In Stock"
                })
        
        if "brake" in query.lower():
            recommendations.append({
                "part_id": "GEN-BRK-001",
                "name": "Performance Brake Pads",
                "compatibility": 0.94,
                "price": 120.00,
                "availability": "In Stock"
            })
        
        if "charger" in query.lower() and is_ev:
            recommendations.append({
                "part_id": "EV-CHG-001",
                "name": "Home Charging Station",
                "compatibility": 0.97,
                "price": 850.00,
                "availability": "In Stock"
            })
        
        # Add generic recommendations if specific ones weren't found
        if not recommendations:
            if is_ev:
                recommendations = [
                    {
                        "part_id": "EV-BAT-001",
                        "name": "High-Performance EV Battery",
                        "compatibility": 0.95,
                        "price": 1200.00,
                        "availability": "In Stock"
                    },
                    {
                        "part_id": "EV-CHG-002",
                        "name": "Fast Charging Port",
                        "compatibility": 0.92,
                        "price": 350.00,
                        "availability": "In Stock"
                    }
                ]
            else:
                recommendations = [
                    {
                        "part_id": "ICE-FIL-001",
                        "name": "Premium Oil Filter",
                        "compatibility": 0.97,
                        "price": 25.00,
                        "availability": "In Stock"
                    },
                    {
                        "part_id": "ICE-BRK-002",
                        "name": "Performance Brake Pads",
                        "compatibility": 0.94,
                        "price": 120.00,
                        "availability": "In Stock"
                    }
                ]
        
        return recommendations
    
    def _suggest_actions(self, customer_id, recommendations):
        """
        Suggest next actions based on recommendations
        
        Args:
            customer_id (str): Customer ID
            recommendations (list): List of recommended products
            
        Returns:
            list: List of suggested actions
        """
        actions = []
        
        if recommendations:
            actions.append({
                "type": "contact",
                "description": "Contact customer with personalized recommendations",
                "priority": "high"
            })
            
            actions.append({
                "type": "discount",
                "description": "Offer 10% discount on selected items",
                "priority": "medium"
            })
        
        # Check customer history for repeat visits
        if customer_id in self.customer_history and len(self.customer_history[customer_id]) > 3:
            actions.append({
                "type": "loyalty",
                "description": "Enroll customer in loyalty program",
                "priority": "high"
            })
        
        return actions
    
    def record_conversion(self, customer_id, purchased_items):
        """
        Record a successful sales conversion
        
        Args:
            customer_id (str): Customer ID
            purchased_items (list): List of purchased items
            
        Returns:
            bool: Success status
        """
        self.sales_metrics["conversions"] += 1
        self.sales_metrics["last_updated"] = datetime.now().isoformat()
        
        logger.info(f"Recorded conversion for customer {customer_id}: {len(purchased_items)} items")
        
        return True
    
    def get_metrics(self):
        """
        Get sales metrics
        
        Returns:
            dict: Sales metrics
        """
        # Calculate conversion rate
        if self.sales_metrics["recommendations"] > 0:
            conversion_rate = (self.sales_metrics["conversions"] / self.sales_metrics["recommendations"]) * 100
        else:
            conversion_rate = 0
        
        metrics = {
            **self.sales_metrics,
            "conversion_rate": conversion_rate
        }
        
        return metrics
    
    def get_state(self):
        """
        Get agent state
        
        Returns:
            dict: Agent state
        """
        # Get base state from parent class
        base_state = super().get_state()
        
        # Add sales agent specific state
        state = {
            **base_state,
            "ml_enabled": self.ml_enabled,
            "customer_history": self.customer_history,
            "sales_metrics": self.sales_metrics
        }
        
        return state
    
    def set_state(self, state):
        """
        Set agent state
        
        Args:
            state (dict): Agent state
        """
        # Set base state from parent class
        super().set_state(state)
        
        # Set sales agent specific state
        self.ml_enabled = state.get("ml_enabled", False)
        self.customer_history = state.get("customer_history", {})
        self.sales_metrics = state.get("sales_metrics", {
            "interactions": 0,
            "recommendations": 0,
            "conversions": 0,
            "last_updated": datetime.now().isoformat()
        })

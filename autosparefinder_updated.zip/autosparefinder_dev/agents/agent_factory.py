import logging
import uuid
from .quality_control_agent import QualityControlAgent
from .monitoring_agent import MonitoringAgent
from .sales_agent import SalesAgent
from .order_agent import OrderAgent
from .technical_support_agent import TechnicalSupportAgent

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class AgentFactory:
    """
    Factory class for creating different types of AI agents
    """
    
    @staticmethod
    def create_agent(agent_type, name=None, model_type="gpt-4", config=None):
        """
        Create a new agent of the specified type
        
        Args:
            agent_type (str): Type of agent to create ('quality_control', 'monitoring', 'sales', etc.)
            name (str, optional): Name for the agent. If not provided, a default name will be used.
            model_type (str, optional): Type of AI model to use. Defaults to 'gpt-4'.
            config (dict, optional): Configuration parameters for the agent.
            
        Returns:
            AIAgent: The created agent instance
        """
        # Generate a unique ID for the agent
        agent_id = str(uuid.uuid4())
        
        # Create the appropriate agent type
        agent_type = agent_type.lower()
        
        if agent_type == 'quality_control':
            # Create a quality control agent (Ido)
            agent_name = name or 'Ido'
            logger.info(f"Creating Quality Control Agent: {agent_name}")
            return QualityControlAgent(agent_id, agent_name, model_type, config)
            
        elif agent_type == 'monitoring':
            # Create a monitoring agent (Shira)
            agent_name = name or 'Shira'
            logger.info(f"Creating Monitoring Agent: {agent_name}")
            return MonitoringAgent(agent_id, agent_name, model_type, config)
            
        elif agent_type == 'sales':
            # Create a sales agent
            agent_name = name or 'Sales Agent'
            logger.info(f"Creating Sales Agent: {agent_name}")
            return SalesAgent(agent_id, agent_name, model_type, config)
            
        elif agent_type == 'order':
            # Create an order agent
            agent_name = name or 'Order Agent'
            logger.info(f"Creating Order Agent: {agent_name}")
            return OrderAgent(agent_id, agent_name, model_type, config)
            
        elif agent_type == 'technical_support':
            # Create a technical support agent
            agent_name = name or 'Technical Support Agent'
            logger.info(f"Creating Technical Support Agent: {agent_name}")
            return TechnicalSupportAgent(agent_id, agent_name, model_type, config)
            
        else:
            # Unknown agent type
            logger.error(f"Unknown agent type: {agent_type}")
            raise ValueError(f"Unknown agent type: {agent_type}")

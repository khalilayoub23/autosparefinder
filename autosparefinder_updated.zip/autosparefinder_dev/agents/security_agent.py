import logging
import json
from datetime import datetime

class SecurityAgent:
    """
    Security Agent (Amit) - Responsible for monitoring security, detecting threats,
    and enforcing security policies throughout the system.
    """
    
    def __init__(self, name="Amit", config=None):
        """
        Initialize the Security Agent
        
        Args:
            name (str): Agent name
            config (dict): Configuration parameters
        """
        self.name = name
        self.agent_type = "security"
        self.config = config or {}
        self.logger = logging.getLogger(f"agent.{self.agent_type}")
        self.security_events = []
        self.threat_levels = {
            "low": 1,
            "medium": 2,
            "high": 3,
            "critical": 4
        }
        self.active_threats = {}
        self.security_rules = self._load_security_rules()
        
        self.logger.info(f"Security Agent '{self.name}' initialized")
    
    def _load_security_rules(self):
        """Load security rules from configuration"""
        # Default security rules
        return {
            "login_attempts": {
                "max_attempts": 5,
                "lockout_period": 15,  # minutes
                "threat_level": "medium"
            },
            "api_rate_limits": {
                "standard_endpoint": 100,  # requests per minute
                "sensitive_endpoint": 20,  # requests per minute
                "threat_level": "low"
            },
            "suspicious_patterns": {
                "sql_injection": {
                    "patterns": ["'--", "OR 1=1", "DROP TABLE", ";--"],
                    "threat_level": "high"
                },
                "xss": {
                    "patterns": ["<script>", "javascript:", "onerror=", "onload="],
                    "threat_level": "high"
                },
                "path_traversal": {
                    "patterns": ["../", "..\\", "/etc/passwd", "C:\\Windows\\"],
                    "threat_level": "high"
                }
            },
            "sensitive_data_access": {
                "payment_info": {
                    "required_roles": ["admin", "finance"],
                    "threat_level": "high"
                },
                "user_data": {
                    "required_roles": ["admin", "support"],
                    "threat_level": "medium"
                }
            }
        }
    
    def monitor_login_attempts(self, user_id, success, ip_address, user_agent):
        """
        Monitor login attempts and detect suspicious activity
        
        Args:
            user_id (str): User ID
            success (bool): Whether login was successful
            ip_address (str): IP address of the request
            user_agent (str): User agent string
            
        Returns:
            dict: Monitoring result with security status
        """
        self.logger.info(f"Monitoring login attempt for user {user_id} from {ip_address}")
        
        # Record login attempt
        event = {
            "event_type": "login_attempt",
            "user_id": user_id,
            "success": success,
            "ip_address": ip_address,
            "user_agent": user_agent,
            "timestamp": datetime.now().isoformat()
        }
        self.security_events.append(event)
        
        # Check for failed login attempts
        if not success:
            recent_failed_attempts = self._count_recent_failed_logins(user_id, ip_address)
            max_attempts = self.security_rules["login_attempts"]["max_attempts"]
            
            if recent_failed_attempts >= max_attempts:
                # Trigger account lockout
                threat_level = self.security_rules["login_attempts"]["threat_level"]
                self._register_threat(
                    threat_type="excessive_login_attempts",
                    user_id=user_id,
                    ip_address=ip_address,
                    threat_level=threat_level,
                    details={
                        "failed_attempts": recent_failed_attempts,
                        "lockout_period": self.security_rules["login_attempts"]["lockout_period"]
                    }
                )
                
                return {
                    "status": "locked",
                    "reason": "excessive_failed_attempts",
                    "lockout_minutes": self.security_rules["login_attempts"]["lockout_period"]
                }
        
        # Check for successful login after failures (potential password guessing)
        if success:
            recent_failed_attempts = self._count_recent_failed_logins(user_id, ip_address)
            if recent_failed_attempts > 0:
                self.logger.warning(f"Successful login after {recent_failed_attempts} failed attempts for user {user_id}")
                
                if recent_failed_attempts >= 3:  # Threshold for suspicious activity
                    self._register_threat(
                        threat_type="successful_login_after_failures",
                        user_id=user_id,
                        ip_address=ip_address,
                        threat_level="low",
                        details={
                            "failed_attempts_before_success": recent_failed_attempts
                        }
                    )
        
        return {
            "status": "monitored",
            "suspicious": False
        }
    
    def _count_recent_failed_logins(self, user_id, ip_address, minutes=30):
        """Count recent failed login attempts for a user or IP address"""
        cutoff_time = datetime.now().timestamp() - (minutes * 60)
        
        # Count failed logins for this user or IP in the last 'minutes'
        count = 0
        for event in reversed(self.security_events):
            if event["event_type"] != "login_attempt" or event["success"]:
                continue
                
            event_time = datetime.fromisoformat(event["timestamp"]).timestamp()
            if event_time < cutoff_time:
                break
                
            if event["user_id"] == user_id or event["ip_address"] == ip_address:
                count += 1
        
        return count
    
    def monitor_api_request(self, endpoint, method, user_id, ip_address, request_data):
        """
        Monitor API requests for suspicious activity
        
        Args:
            endpoint (str): API endpoint
            method (str): HTTP method
            user_id (str): User ID
            ip_address (str): IP address of the request
            request_data (dict): Request data
            
        Returns:
            dict: Monitoring result with security status
        """
        self.logger.info(f"Monitoring API request to {method} {endpoint} from {ip_address}")
        
        # Record API request
        event = {
            "event_type": "api_request",
            "endpoint": endpoint,
            "method": method,
            "user_id": user_id,
            "ip_address": ip_address,
            "timestamp": datetime.now().isoformat()
        }
        self.security_events.append(event)
        
        # Check for rate limiting
        endpoint_type = "sensitive_endpoint" if "/admin/" in endpoint or "/payment/" in endpoint else "standard_endpoint"
        rate_limit = self.security_rules["api_rate_limits"][endpoint_type]
        
        recent_requests = self._count_recent_api_requests(endpoint, ip_address)
        if recent_requests > rate_limit:
            self._register_threat(
                threat_type="api_rate_limit_exceeded",
                user_id=user_id,
                ip_address=ip_address,
                threat_level=self.security_rules["api_rate_limits"]["threat_level"],
                details={
                    "endpoint": endpoint,
                    "method": method,
                    "request_count": recent_requests,
                    "rate_limit": rate_limit
                }
            )
            
            return {
                "status": "blocked",
                "reason": "rate_limit_exceeded",
                "retry_after": 60  # seconds
            }
        
        # Check for suspicious patterns in request data
        suspicious_patterns = self._detect_suspicious_patterns(request_data)
        if suspicious_patterns:
            pattern_type, patterns = suspicious_patterns
            threat_level = self.security_rules["suspicious_patterns"][pattern_type]["threat_level"]
            
            self._register_threat(
                threat_type=f"suspicious_{pattern_type}_pattern",
                user_id=user_id,
                ip_address=ip_address,
                threat_level=threat_level,
                details={
                    "endpoint": endpoint,
                    "method": method,
                    "detected_patterns": patterns
                }
            )
            
            return {
                "status": "blocked",
                "reason": "suspicious_pattern_detected",
                "pattern_type": pattern_type
            }
        
        return {
            "status": "allowed",
            "suspicious": False
        }
    
    def _count_recent_api_requests(self, endpoint, ip_address, seconds=60):
        """Count recent API requests for an endpoint from an IP address"""
        cutoff_time = datetime.now().timestamp() - seconds
        
        # Count API requests for this endpoint or IP in the last 'seconds'
        count = 0
        for event in reversed(self.security_events):
            if event["event_type"] != "api_request":
                continue
                
            event_time = datetime.fromisoformat(event["timestamp"]).timestamp()
            if event_time < cutoff_time:
                break
                
            if event["ip_address"] == ip_address:
                if endpoint == "*" or event["endpoint"] == endpoint:
                    count += 1
        
        return count
    
    def _detect_suspicious_patterns(self, request_data):
        """Detect suspicious patterns in request data"""
        if not request_data:
            return None
            
        # Convert request data to string for pattern matching
        data_str = json.dumps(request_data).lower()
        
        # Check for suspicious patterns
        for pattern_type, pattern_config in self.security_rules["suspicious_patterns"].items():
            detected_patterns = []
            
            for pattern in pattern_config["patterns"]:
                if pattern.lower() in data_str:
                    detected_patterns.append(pattern)
            
            if detected_patterns:
                return pattern_type, detected_patterns
        
        return None
    
    def check_data_access_permission(self, user_id, data_type, action, user_roles):
        """
        Check if a user has permission to access sensitive data
        
        Args:
            user_id (str): User ID
            data_type (str): Type of data being accessed
            action (str): Action being performed (read, write, delete)
            user_roles (list): User's roles
            
        Returns:
            dict: Permission check result
        """
        self.logger.info(f"Checking {action} permission for {data_type} data for user {user_id}")
        
        # Record access attempt
        event = {
            "event_type": "data_access_attempt",
            "user_id": user_id,
            "data_type": data_type,
            "action": action,
            "user_roles": user_roles,
            "timestamp": datetime.now().isoformat()
        }
        self.security_events.append(event)
        
        # Check if data type is sensitive
        if data_type in self.security_rules["sensitive_data_access"]:
            required_roles = self.security_rules["sensitive_data_access"][data_type]["required_roles"]
            
            # Check if user has required role
            has_permission = any(role in required_roles for role in user_roles)
            
            if not has_permission:
                threat_level = self.security_rules["sensitive_data_access"][data_type]["threat_level"]
                self._register_threat(
                    threat_type="unauthorized_data_access_attempt",
                    user_id=user_id,
                    ip_address=None,
                    threat_level=threat_level,
                    details={
                        "data_type": data_type,
                        "action": action,
                        "user_roles": user_roles,
                        "required_roles": required_roles
                    }
                )
                
                return {
                    "allowed": False,
                    "reason": "insufficient_permissions",
                    "required_roles": required_roles
                }
        
        return {
            "allowed": True
        }
    
    def _register_threat(self, threat_type, user_id, ip_address, threat_level, details=None):
        """Register a security threat"""
        threat_id = f"{threat_type}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        threat = {
            "threat_id": threat_id,
            "threat_type": threat_type,
            "user_id": user_id,
            "ip_address": ip_address,
            "threat_level": threat_level,
            "threat_level_value": self.threat_levels.get(threat_level, 1),
            "details": details or {},
            "timestamp": datetime.now().isoformat(),
            "status": "active"
        }
        
        self.active_threats[threat_id] = threat
        self.security_events.append({
            "event_type": "threat_detected",
            "threat_id": threat_id,
            "threat_type": threat_type,
            "threat_level": threat_level,
            "timestamp": datetime.now().isoformat()
        })
        
        self.logger.warning(f"Security threat detected: {threat_type} (Level: {threat_level})")
        
        # Take immediate action based on threat level
        if threat_level == "critical":
            self._take_critical_threat_action(threat)
        elif threat_level == "high":
            self._take_high_threat_action(threat)
        
        return threat_id
    
    def _take_critical_threat_action(self, threat):
        """Take immediate action for critical threats"""
        self.logger.critical(f"Taking immediate action for critical threat: {threat['threat_id']}")
        
        # Record action
        self.security_events.append({
            "event_type": "critical_threat_action",
            "threat_id": threat["threat_id"],
            "action": "block_ip_and_notify",
            "timestamp": datetime.now().isoformat()
        })
        
        # In a real implementation, this would:
        # 1. Block the IP address at the firewall/WAF level
        # 2. Send immediate notification to security team
        # 3. Potentially force logout all sessions for the affected user
    
    def _take_high_threat_action(self, threat):
        """Take immediate action for high threats"""
        self.logger.warning(f"Taking action for high threat: {threat['threat_id']}")
        
        # Record action
        self.security_events.append({
            "event_type": "high_threat_action",
            "threat_id": threat["threat_id"],
            "action": "notify_security",
            "timestamp": datetime.now().isoformat()
        })
        
        # In a real implementation, this would:
        # 1. Send notification to security team
        # 2. Add additional monitoring for the IP/user
    
    def resolve_threat(self, threat_id, resolution_notes=None):
        """
        Resolve a security threat
        
        Args:
            threat_id (str): Threat ID
            resolution_notes (str): Notes on how the threat was resolved
            
        Returns:
            dict: Resolution result
        """
        if threat_id not in self.active_threats:
            return {
                "success": False,
                "error": "Threat not found"
            }
        
        threat = self.active_threats[threat_id]
        threat["status"] = "resolved"
        threat["resolution_timestamp"] = datetime.now().isoformat()
        threat["resolution_notes"] = resolution_notes
        
        # Record resolution
        self.security_events.append({
            "event_type": "threat_resolved",
            "threat_id": threat_id,
            "resolution_notes": resolution_notes,
            "timestamp": datetime.now().isoformat()
        })
        
        self.logger.info(f"Security threat {threat_id} resolved")
        
        # Remove from active threats
        del self.active_threats[threat_id]
        
        return {
            "success": True,
            "threat_id": threat_id
        }
    
    def get_active_threats(self, min_threat_level=None):
        """
        Get active security threats
        
        Args:
            min_threat_level (str): Minimum threat level to include
            
        Returns:
            list: Active threats
        """
        if not min_threat_level:
            return list(self.active_threats.values())
        
        min_level_value = self.threat_levels.get(min_threat_level, 0)
        return [
            threat for threat in self.active_threats.values()
            if threat["threat_level_value"] >= min_level_value
        ]
    
    def get_security_events(self, event_types=None, start_time=None, end_time=None, limit=100):
        """
        Get security events with optional filters
        
        Args:
            event_types (list): Types of events to include
            start_time (str): Start time in ISO format
            end_time (str): End time in ISO format
            limit (int): Maximum number of events to return
            
        Returns:
            list: Filtered security events
        """
        filtered_events = self.security_events
        
        # Apply filters
        if event_types:
            filtered_events = [e for e in filtered_events if e["event_type"] in event_types]
        
        if start_time:
            start = datetime.fromisoformat(start_time)
            filtered_events = [
                e for e in filtered_events 
                if datetime.fromisoformat(e["timestamp"]) >= start
            ]
        
        if end_time:
            end = datetime.fromisoformat(end_time)
            filtered_events = [
                e for e in filtered_events 
                if datetime.fromisoformat(e["timestamp"]) <= end
            ]
        
        # Sort by timestamp (newest first) and limit
        sorted_events = sorted(
            filtered_events,
            key=lambda e: datetime.fromisoformat(e["timestamp"]),
            reverse=True
        )
        
        return sorted_events[:limit]
    
    def generate_security_report(self, report_type, period_start, period_end):
        """
        Generate security report
        
        Args:
            report_type (str): Type of report (threats, logins, api_activity)
            period_start (str): Start date in ISO format
            period_end (str): End date in ISO format
            
        Returns:
            dict: Report data
        """
        self.logger.info(f"Generating {report_type} report from {period_start} to {period_end}")
        
        # Convert dates to datetime objects
        start_date = datetime.fromisoformat(period_start)
        end_date = datetime.fromisoformat(period_end)
        
        # Filter events by date range
        events = [
            e for e in self.security_events 
            if start_date <= datetime.fromisoformat(e["timestamp"]) <= end_date
        ]
        
        # Generate report based on type
        if report_type == "threats":
            return self._generate_threats_report(events)
        elif report_type == "logins":
            return self._generate_logins_report(events)
        elif report_type == "api_activity":
            return self._generate_api_activity_report(events)
        else:
            self.logger.error(f"Unsupported report type: {report_type}")
            return {
                "success": False,
                "error": f"Unsupported report type: {report_type}"
            }
    
    def _generate_threats_report(self, events):
        """Generate threats report from events"""
        # Filter threat events
        threat_events = [e for e in events if e["event_type"] in ["threat_detected", "threat_resolved"]]
        
        # Count threats by type
        threats_by_type = {}
        for event in threat_events:
            if event["event_type"] != "threat_detected":
                continue
                
            threat_type = event["threat_type"]
            if threat_type not in threats_by_type:
                threats_by_type[threat_type] = 0
            threats_by_type[threat_type] += 1
        
        # Count threats by level
        threats_by_level = {}
        for event in threat_events:
            if event["event_type"] != "threat_detected":
                continue
                
            threat_level = event["threat_level"]
            if threat_level not in threats_by_level:
                threats_by_level[threat_level] = 0
            threats_by_level[threat_level] += 1
        
        # Calculate resolution rate
        detected_count = len([e for e in threat_events if e["event_type"] == "threat_detected"])
        resolved_count = len([e for e in threat_events if e["event_type"] == "threat_resolved"])
        resolution_rate = resolved_count / detected_count if detected_count > 0 else 0
        
        return {
            "report_type": "threats",
            "total_threats": detected_count,
            "resolved_threats": resolved_count,
            "resolution_rate": resolution_rate,
            "threats_by_type": threats_by_type,
            "threats_by_level": threats_by_level
        }
    
    def _generate_logins_report(self, events):
        """Generate logins report from events"""
        # Filter login events
        login_events = [e for e in events if e["event_type"] == "login_attempt"]
        
        # Count successful and failed logins
        successful_logins = len([e for e in login_events if e["success"]])
        failed_logins = len([e for e in login_events if not e["success"]])
        
        # Group by IP address
        logins_by_ip = {}
        for event in login_events:
            ip = event["ip_address"]
            if ip not in logins_by_ip:
                logins_by_ip[ip] = {"successful": 0, "failed": 0}
            
            if event["success"]:
                logins_by_ip[ip]["successful"] += 1
            else:
                logins_by_ip[ip]["failed"] += 1
        
        # Find suspicious IPs (high failure rate)
        suspicious_ips = []
        for ip, counts in logins_by_ip.items():
            total = counts["successful"] + counts["failed"]
            if total >= 5 and counts["failed"] / total > 0.5:
                suspicious_ips.append({
                    "ip": ip,
                    "successful": counts["successful"],
                    "failed": counts["failed"],
                    "failure_rate": counts["failed"] / total
                })
        
        return {
            "report_type": "logins",
            "total_logins": len(login_events),
            "successful_logins": successful_logins,
            "failed_logins": failed_logins,
            "success_rate": successful_logins / len(login_events) if login_events else 0,
            "suspicious_ips": suspicious_ips
        }
    
    def _generate_api_activity_report(self, events):
        """Generate API activity report from events"""
        # Filter API request events
        api_events = [e for e in events if e["event_type"] == "api_request"]
        
        # Group by endpoint
        requests_by_endpoint = {}
        for event in api_events:
            endpoint = event["endpoint"]
            if endpoint not in requests_by_endpoint:
                requests_by_endpoint[endpoint] = 0
            requests_by_endpoint[endpoint] += 1
        
        # Group by IP address
        requests_by_ip = {}
        for event in api_events:
            ip = event["ip_address"]
            if ip not in requests_by_ip:
                requests_by_ip[ip] = 0
            requests_by_ip[ip] += 1
        
        # Find high-volume IPs
        high_volume_ips = []
        for ip, count in requests_by_ip.items():
            if count > 1000:  # Arbitrary threshold
                high_volume_ips.append({
                    "ip": ip,
                    "request_count": count
                })
        
        return {
            "report_type": "api_activity",
            "total_requests": len(api_events),
            "requests_by_endpoint": requests_by_endpoint,
            "top_endpoints": sorted(
                requests_by_endpoint.items(),
                key=lambda x: x[1],
                reverse=True
            )[:10],
            "high_volume_ips": high_volume_ips
        }
    
    def validate_password_strength(self, password):
        """
        Validate password strength
        
        Args:
            password (str): Password to validate
            
        Returns:
            dict: Validation result
        """
        score = 0
        feedback = []
        
        # Check length
        if len(password) < 8:
            feedback.append("Password is too short (minimum 8 characters)")
        elif len(password) >= 12:
            score += 2
        else:
            score += 1
        
        # Check for uppercase letters
        if any(c.isupper() for c in password):
            score += 1
        else:
            feedback.append("Password should include uppercase letters")
        
        # Check for lowercase letters
        if any(c.islower() for c in password):
            score += 1
        else:
            feedback.append("Password should include lowercase letters")
        
        # Check for digits
        if any(c.isdigit() for c in password):
            score += 1
        else:
            feedback.append("Password should include digits")
        
        # Check for special characters
        if any(not c.isalnum() for c in password):
            score += 1
        else:
            feedback.append("Password should include special characters")
        
        # Determine strength
        if score >= 5:
            strength = "strong"
        elif score >= 3:
            strength = "moderate"
        else:
            strength = "weak"
        
        return {
            "score": score,
            "strength": strength,
            "feedback": feedback,
            "is_strong_enough": score >= 3  # Minimum acceptable score
        }
    
    def scan_for_vulnerabilities(self, target_type, target_id):
        """
        Scan for vulnerabilities in a system component
        
        Args:
            target_type (str): Type of target (api, database, frontend)
            target_id (str): Target identifier
            
        Returns:
            dict: Scan results
        """
        self.logger.info(f"Scanning {target_type} {target_id} for vulnerabilities")
        
        # This is a placeholder for actual vulnerability scanning
        # In a real implementation, this would integrate with security scanning tools
        
        # Simulate scan results
        vulnerabilities = []
        
        if target_type == "api":
            vulnerabilities = [
                {
                    "id": "API-SEC-001",
                    "name": "Missing Rate Limiting",
                    "severity": "medium",
                    "description": "API endpoint does not implement rate limiting",
                    "recommendation": "Implement rate limiting using the security middleware"
                }
            ]
        elif target_type == "database":
            vulnerabilities = [
                {
                    "id": "DB-SEC-001",
                    "name": "Unencrypted Sensitive Data",
                    "severity": "high",
                    "description": "Sensitive data is stored without encryption",
                    "recommendation": "Use the data protection module to encrypt sensitive fields"
                }
            ]
        elif target_type == "frontend":
            vulnerabilities = [
                {
                    "id": "FE-SEC-001",
                    "name": "Missing Content Security Policy",
                    "severity": "medium",
                    "description": "Frontend does not implement Content Security Policy",
                    "recommendation": "Add CSP headers using the security middleware"
                }
            ]
        
        # Record scan
        self.security_events.append({
            "event_type": "vulnerability_scan",
            "target_type": target_type,
            "target_id": target_id,
            "vulnerabilities_found": len(vulnerabilities),
            "timestamp": datetime.now().isoformat()
        })
        
        return {
            "target_type": target_type,
            "target_id": target_id,
            "scan_id": f"SCAN-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "vulnerabilities": vulnerabilities,
            "total_vulnerabilities": len(vulnerabilities),
            "scan_timestamp": datetime.now().isoformat()
        }
from datetime import datetime
import os
import sys

# Import base agent class
from .base_agent import AIAgent

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SecurityAgent(AIAgent):
    """
    Security Agent for AutoSpareFinder system.
    Handles security monitoring, threat detection, and security policy enforcement.
    """
    
    def __init__(self, agent_id=None, name="Security Agent", model_type="gpt-4", config=None):
        """
        Initialize the Security Agent
        
        Args:
            agent_id (str): Unique identifier for the agent
            name (str): Name of the agent
            model_type (str): Type of AI model to use
            config (dict): Configuration parameters for the agent
        """
        super().__init__(agent_id, name, model_type, config)
    
    def _initialize_components(self):
        """Initialize agent-specific components"""
        self.security_enabled = True
        
        # Initialize security-specific attributes
        self.security_logs = []
        self.threat_database = {}
        self.security_policies = {}
        self.active_sessions = {}
        self.blocked_ips = set()
        self.security_metrics = {
            "login_attempts": 0,
            "failed_logins": 0,
            "blocked_attempts": 0,
            "detected_threats": 0,
            "last_updated": datetime.now().isoformat()
        }
        
        # Load security policies from config
        if self.config and 'security_policies' in self.config:
            self.security_policies = self.config['security_policies']
        else:
            # Default security policies
            self.security_policies = {
                "max_login_attempts": 5,
                "session_timeout_minutes": 30,
                "password_requirements": {
                    "min_length": 10,
                    "require_uppercase": True,
                    "require_lowercase": True,
                    "require_numbers": True,
                    "require_special_chars": True
                },
                "ip_blocking_duration_minutes": 30,
                "sensitive_operations_require_2fa": True
            }
        
        logger.info(f"Security Agent initialized with {len(self.security_policies)} security policies")
    
    def process(self, input_data):
        """
        Process a security-related request
        
        Args:
            input_data (dict): Request data containing security operation details
            
        Returns:
            dict: Response with operation results
        """
        self.update_status("processing")
        
        try:
            request_type = input_data.get('request_type', '')
            
            if request_type == 'validate_login':
                return self._validate_login(input_data)
            elif request_type == 'validate_password':
                return self._validate_password(input_data)
            elif request_type == 'check_session':
                return self._check_session(input_data)
            elif request_type == 'log_security_event':
                return self._log_security_event(input_data)
            elif request_type == 'check_permission':
                return self._check_permission(input_data)
            elif request_type == 'analyze_threat':
                return self._analyze_threat(input_data)
            elif request_type == 'get_security_metrics':
                return self._get_security_metrics()
            else:
                logger.warning(f"Unknown request type: {request_type}")
                return {
                    'status': 'error',
                    'message': f"Unknown request type: {request_type}"
                }
        except Exception as e:
            logger.error(f"Error processing security request: {e}")
            return {
                'status': 'error',
                'message': str(e)
            }
        finally:
            self.update_status("idle")
    
    def _validate_login(self, input_data):
        """
        Validate a login attempt
        
        Args:
            input_data (dict): Login details
            
        Returns:
            dict: Validation result
        """
        username = input_data.get('username', '')
        password_hash = input_data.get('password_hash', '')
        ip_address = input_data.get('ip_address', '')
        user_agent = input_data.get('user_agent', '')
        
        # Update metrics
        self.security_metrics["login_attempts"] += 1
        
        # Check if IP is blocked
        if ip_address in self.blocked_ips:
            self.security_metrics["blocked_attempts"] += 1
            
            self._log_security_event({
                'event_type': 'blocked_login_attempt',
                'username': username,
                'ip_address': ip_address,
                'user_agent': user_agent,
                'reason': 'IP address is blocked'
            })
            
            return {
                'status': 'error',
                'message': 'Your IP address is temporarily blocked due to multiple failed login attempts'
            }
        
        # In a real implementation, this would check against a user database
        # For now, we'll simulate a successful login for a test user
        if username == 'test_user' and password_hash == 'valid_hash':
            # Generate session token
            session_token = f"session_{datetime.now().strftime('%Y%m%d%H%M%S')}_{username}"
            
            # Store session
            self.active_sessions[session_token] = {
                'username': username,
                'ip_address': ip_address,
                'user_agent': user_agent,
                'created_at': datetime.now().isoformat(),
                'last_activity': datetime.now().isoformat(),
                'expires_at': (datetime.now() + datetime.timedelta(minutes=self.security_policies['session_timeout_minutes'])).isoformat()
            }
            
            self._log_security_event({
                'event_type': 'successful_login',
                'username': username,
                'ip_address': ip_address,
                'user_agent': user_agent
            })
            
            return {
                'status': 'success',
                'message': 'Login successful',
                'session_token': session_token,
                'expires_at': self.active_sessions[session_token]['expires_at']
            }
        else:
            # Failed login
            self.security_metrics["failed_logins"] += 1
            
            # Check if we should block this IP
            ip_failures = sum(1 for log in self.security_logs 
                             if log.get('event_type') == 'failed_login' 
                             and log.get('ip_address') == ip_address
                             and (datetime.now() - datetime.fromisoformat(log.get('timestamp', datetime.now().isoformat()))).total_seconds() < 600)  # Last 10 minutes
            
            if ip_failures >= self.security_policies['max_login_attempts'] - 1:  # Current attempt + previous failures
                self.blocked_ips.add(ip_address)
                
                # Schedule unblocking
                # In a real implementation, this would use a proper scheduler
                # For now, we'll just note when it should be unblocked
                unblock_time = (datetime.now() + datetime.timedelta(minutes=self.security_policies['ip_blocking_duration_minutes'])).isoformat()
                
                self._log_security_event({
                    'event_type': 'ip_blocked',
                    'ip_address': ip_address,
                    'reason': 'Multiple failed login attempts',
                    'unblock_time': unblock_time
                })
            
            self._log_security_event({
                'event_type': 'failed_login',
                'username': username,
                'ip_address': ip_address,
                'user_agent': user_agent
            })
            
            return {
                'status': 'error',
                'message': 'Invalid username or password',
                'attempts_remaining': max(0, self.security_policies['max_login_attempts'] - ip_failures - 1)
            }
    
    def _validate_password(self, input_data):
        """
        Validate a password against security policies
        
        Args:
            input_data (dict): Password details
            
        Returns:
            dict: Validation result
        """
        password = input_data.get('password', '')
        
        # Check password requirements
        requirements = self.security_policies['password_requirements']
        issues = []
        
        if len(password) < requirements['min_length']:
            issues.append(f"Password must be at least {requirements['min_length']} characters long")
        
        if requirements['require_uppercase'] and not any(c.isupper() for c in password):
            issues.append("Password must contain at least one uppercase letter")
        
        if requirements['require_lowercase'] and not any(c.islower() for c in password):
            issues.append("Password must contain at least one lowercase letter")
        
        if requirements['require_numbers'] and not any(c.isdigit() for c in password):
            issues.append("Password must contain at least one number")
        
        if requirements['require_special_chars'] and not any(not c.isalnum() for c in password):
            issues.append("Password must contain at least one special character")
        
        # Check for common passwords (in a real implementation, this would check against a database)
        common_passwords = ['password', '123456', 'qwerty', 'admin']
        if password.lower() in common_passwords:
            issues.append("Password is too common and easily guessable")
        
        if issues:
            return {
                'status': 'error',
                'message': 'Password does not meet security requirements',
                'issues': issues
            }
        
        return {
            'status': 'success',
            'message': 'Password meets all security requirements'
        }
    
    def _check_session(self, input_data):
        """
        Check if a session is valid
        
        Args:
            input_data (dict): Session details
            
        Returns:
            dict: Session status
        """
        session_token = input_data.get('session_token', '')
        ip_address = input_data.get('ip_address', '')
        
        if not session_token or session_token not in self.active_sessions:
            return {
                'status': 'error',
                'message': 'Invalid or expired session',
                'valid': False
            }
        
        session = self.active_sessions[session_token]
        
        # Check if session has expired
        if datetime.now() > datetime.fromisoformat(session['expires_at']):
            # Remove expired session
            del self.active_sessions[session_token]
            
            self._log_security_event({
                'event_type': 'session_expired',
                'username': session['username'],
                'session_token': session_token
            })
            
            return {
                'status': 'error',
                'message': 'Session has expired',
                'valid': False
            }
        
        # Check if IP address has changed (potential session hijacking)
        if ip_address and session['ip_address'] != ip_address:
            # Invalidate session
            del self.active_sessions[session_token]
            
            self._log_security_event({
                'event_type': 'potential_session_hijacking',
                'username': session['username'],
                'session_token': session_token,
                'original_ip': session['ip_address'],
                'new_ip': ip_address
            })
            
            return {
                'status': 'error',
                'message': 'Session invalidated due to IP address change',
                'valid': False
            }
        
        # Update last activity
        session['last_activity'] = datetime.now().isoformat()
        
        # Extend session if needed
        session['expires_at'] = (datetime.now() + datetime.timedelta(minutes=self.security_policies['session_timeout_minutes'])).isoformat()
        
        return {
            'status': 'success',
            'message': 'Session is valid',
            'valid': True,
            'username': session['username'],
            'expires_at': session['expires_at']
        }
    
    def _log_security_event(self, input_data):
        """
        Log a security event
        
        Args:
            input_data (dict): Event details
            
        Returns:
            dict: Logging result
        """
        event_type = input_data.get('event_type', '')
        
        if not event_type:
            return {
                'status': 'error',
                'message': 'Event type is required'
            }
        
        # Add timestamp if not provided
        if 'timestamp' not in input_data:
            input_data['timestamp'] = datetime.now().isoformat()
        
        # Add to security logs
        self.security_logs.append(input_data)
        
        # Update metrics if this is a threat
        if event_type in ['potential_attack', 'suspicious_activity', 'potential_session_hijacking']:
            self.security_metrics["detected_threats"] += 1
        
        # Update last updated timestamp
        self.security_metrics["last_updated"] = datetime.now().isoformat()
        
        logger.info(f"Security event logged: {event_type}")
        
        return {
            'status': 'success',
            'message': 'Security event logged successfully',
            'log_id': len(self.security_logs) - 1
        }
    
    def _check_permission(self, input_data):
        """
        Check if a user has permission for an operation
        
        Args:
            input_data (dict): Permission check details
            
        Returns:
            dict: Permission check result
        """
        username = input_data.get('username', '')
        operation = input_data.get('operation', '')
        resource = input_data.get('resource', '')
        
        if not username or not operation:
            return {
                'status': 'error',
                'message': 'Username and operation are required'
            }
        
        # In a real implementation, this would check against a permissions database
        # For now, we'll use a simple rule-based approach
        
        # Admin can do anything
        if username == 'admin':
            return {
                'status': 'success',
                'has_permission': True
            }
        
        # Check if operation requires 2FA for sensitive operations
        requires_2fa = self.security_policies.get('sensitive_operations_require_2fa', False)
        sensitive_operations = ['delete', 'update_payment', 'change_permissions']
        
        if requires_2fa and operation in sensitive_operations:
            # Check if 2FA was provided
            if not input_data.get('two_factor_verified', False):
                return {
                    'status': 'error',
                    'message': 'This operation requires two-factor authentication',
                    'has_permission': False,
                    'requires_2fa': True
                }
        
        # Simple permission rules
        if operation == 'read':
            # Everyone can read public resources
            if resource.startswith('public_'):
                return {
                    'status': 'success',
                    'has_permission': True
                }
            
            # Users can read their own resources
            if resource.startswith(f'user_{username}_'):
                return {
                    'status': 'success',
                    'has_permission': True
                }
        
        elif operation == 'write':
            # Users can write to their own resources
            if resource.startswith(f'user_{username}_'):
                return {
                    'status': 'success',
                    'has_permission': True
                }
        
        # Default deny
        return {
            'status': 'error',
            'message': 'Permission denied',
            'has_permission': False
        }
    
    def _analyze_threat(self, input_data):
        """
        Analyze a potential security threat
        
        Args:
            input_data (dict): Threat details
            
        Returns:
            dict: Threat analysis result
        """
        threat_type = input_data.get('threat_type', '')
        details = input_data.get('details', {})
        
        if not threat_type:
            return {
                'status': 'error',
                'message': 'Threat type is required'
            }
        
        # Log the threat
        self._log_security_event({
            'event_type': 'potential_attack',
            'threat_type': threat_type,
            'details': details
        })
        
        # Update metrics
        self.security_metrics["detected_threats"] += 1
        
        # Analyze based on threat type
        if threat_type == 'sql_injection':
            # Check for SQL injection patterns
            input_string = details.get('input', '')
            sql_patterns = ["'", "OR 1=1", "DROP TABLE", "DELETE FROM", "INSERT INTO", "SELECT *"]
            
            detected_patterns = [pattern for pattern in sql_patterns if pattern.lower() in input_string.lower()]
            
            if detected_patterns:
                # Block the IP if provided
                ip_address = details.get('ip_address')
                if ip_address:
                    self.blocked_ips.add(ip_address)
                
                return {
                    'status': 'success',
                    'threat_detected': True,
                    'confidence': 'high',
                    'detected_patterns': detected_patterns,
                    'recommended_action': 'block_request'
                }
        
        elif threat_type == 'xss':
            # Check for XSS patterns
            input_string = details.get('input', '')
            xss_patterns = ["<script>", "javascript:", "onerror=", "onload=", "eval("]
            
            detected_patterns = [pattern for pattern in xss_patterns if pattern.lower() in input_string.lower()]
            
            if detected_patterns:
                return {
                    'status': 'success',
                    'threat_detected': True,
                    'confidence': 'high',
                    'detected_patterns': detected_patterns,
                    'recommended_action': 'sanitize_input'
                }
        
        elif threat_type == 'brute_force':
            # Check for brute force patterns
            ip_address = details.get('ip_address', '')
            username = details.get('username', '')
            
            if ip_address:
                # Count failed attempts from this IP
                failed_attempts = sum(1 for log in self.security_logs 
                                     if log.get('event_type') == 'failed_login' 
                                     and log.get('ip_address') == ip_address
                                     and (datetime.now() - datetime.fromisoformat(log.get('timestamp', datetime.now().isoformat()))).total_seconds() < 600)  # Last 10 minutes
                
                if failed_attempts >= self.security_policies['max_login_attempts']:
                    # Block the IP
                    self.blocked_ips.add(ip_address)
                    
                    return {
                        'status': 'success',
                        'threat_detected': True,
                        'confidence': 'high',
                        'failed_attempts': failed_attempts,
                        'recommended_action': 'block_ip'
                    }
                elif failed_attempts >= self.security_policies['max_login_attempts'] // 2:
                    return {
                        'status': 'success',
                        'threat_detected': True,
                        'confidence': 'medium',
                        'failed_attempts': failed_attempts,
                        'recommended_action': 'increase_monitoring'
                    }
        
        # Default response if no specific threat pattern was detected
        return {
            'status': 'success',
            'threat_detected': False,
            'confidence': 'low',
            'recommended_action': 'monitor'
        }
    
    def _get_security_metrics(self):
        """
        Get security metrics
        
        Returns:
            dict: Security metrics
        """
        # Update last updated timestamp
        self.security_metrics["last_updated"] = datetime.now().isoformat()
        
        # Calculate additional metrics
        if self.security_metrics["login_attempts"] > 0:
            failure_rate = (self.security_metrics["failed_logins"] / self.security_metrics["login_attempts"]) * 100
        else:
            failure_rate = 0
        
        metrics = {
            **self.security_metrics,
            "active_sessions": len(self.active_sessions),
            "blocked_ips": len(self.blocked_ips),
            "security_logs": len(self.security_logs),
            "login_failure_rate": failure_rate
        }
        
        return {
            'status': 'success',
            'metrics': metrics
        }
    
    def get_state(self):
        """
        Get the agent's current state
        
        Returns:
            dict: Agent state
        """
        # Get base state from parent class
        state = super().get_state()
        
        # Add security agent specific state
        state.update({
            'security_logs': self.security_logs[-100:],  # Only keep the last 100 logs to avoid state getting too large
            'security_policies': self.security_policies,
            'active_sessions': self.active_sessions,
            'blocked_ips': list(self.blocked_ips),
            'security_metrics': self.security_metrics
        })
        
        return state
    
    def set_state(self, state):
        """
        Set the agent's state
        
        Args:
            state (dict): Agent state
        """
        # Set base state from parent class
        super().set_state(state)
        
        # Set security agent specific state
        self.security_logs = state.get('security_logs', [])
        self.security_policies = state.get('security_policies', {})
        self.active_sessions = state.get('active_sessions', {})
        self.blocked_ips = set(state.get('blocked_ips', []))
        self.security_metrics = state.get('security_metrics', {
            "login_attempts": 0,
            "failed_logins": 0,
            "blocked_attempts": 0,
            "detected_threats": 0,
            "last_updated": datetime.now().isoformat()
        })

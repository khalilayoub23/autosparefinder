import logging
import json
from datetime import datetime

class FinanceAgent:
    """
    Finance Agent (David) - Responsible for all financial aspects of the system
    including payment processing, invoice generation, and CRM financial records.
    """
    
    def __init__(self, name="David", config=None):
        """
        Initialize the Finance Agent
        
        Args:
            name (str): Agent name
            config (dict): Configuration parameters
        """
        self.name = name
        self.agent_type = "finance"
        self.config = config or {}
        self.logger = logging.getLogger(f"agent.{self.agent_type}")
        self.transaction_history = []
        self.payment_processors = self._initialize_payment_processors()
        self.invoice_templates = self._load_invoice_templates()
        self.tax_rates = self._load_tax_rates()
        self.discount_rules = self._load_discount_rules()
        
        self.logger.info(f"Finance Agent '{self.name}' initialized")
    
    def _initialize_payment_processors(self):
        """Initialize supported payment processors"""
        processors = {
            "credit_card": self._process_credit_card_payment,
            "paypal": self._process_paypal_payment,
            "bank_transfer": self._process_bank_transfer,
            "bit": self._process_bit_payment,
            "cash": self._process_cash_payment
        }
        return processors
    
    def _load_invoice_templates(self):
        """Load invoice templates from configuration"""
        templates = {
            "standard": "templates/invoice_standard.html",
            "detailed": "templates/invoice_detailed.html",
            "receipt": "templates/receipt.html"
        }
        return templates
    
    def _load_tax_rates(self):
        """Load tax rates from configuration"""
        # Default Israeli tax rates
        return {
            "vat": 0.17,  # 17% VAT
            "income_tax": {
                "business": 0.23,  # 23% for businesses
                "individual": 0.25  # 25% for individuals
            },
            "import_tax": {
                "standard": 0.12,  # 12% standard import tax
                "luxury": 0.33  # 33% luxury import tax
            }
        }
    
    def _load_discount_rules(self):
        """Load discount rules from configuration"""
        return {
            "bulk": {
                "threshold": 10,  # 10+ items
                "rate": 0.05  # 5% discount
            },
            "loyal_customer": {
                "threshold": 5,  # 5+ previous orders
                "rate": 0.07  # 7% discount
            },
            "seasonal": {
                "active": True,
                "rate": 0.10  # 10% discount
            }
        }
    
    def process_payment(self, order_data, payment_method, payment_details):
        """
        Process payment for an order
        
        Args:
            order_data (dict): Order information
            payment_method (str): Payment method (credit_card, paypal, etc.)
            payment_details (dict): Payment details
            
        Returns:
            dict: Payment result with transaction ID and status
        """
        self.logger.info(f"Processing {payment_method} payment for order {order_data['order_id']}")
        
        # Validate payment method
        if payment_method not in self.payment_processors:
            self.logger.error(f"Unsupported payment method: {payment_method}")
            return {
                "success": False,
                "error": "Unsupported payment method",
                "order_id": order_data["order_id"]
            }
        
        # Calculate final amount with taxes and discounts
        amount = self._calculate_final_amount(order_data)
        
        # Process payment using appropriate processor
        payment_result = self.payment_processors[payment_method](amount, payment_details)
        
        # Record transaction
        transaction = {
            "transaction_id": payment_result.get("transaction_id"),
            "order_id": order_data["order_id"],
            "customer_id": order_data["customer_id"],
            "amount": amount,
            "payment_method": payment_method,
            "status": payment_result.get("status"),
            "timestamp": datetime.now().isoformat()
        }
        self.transaction_history.append(transaction)
        
        # Update CRM with payment information
        self._update_crm_with_payment(transaction)
        
        # Generate invoice if payment successful
        if payment_result.get("success"):
            invoice_id = self.generate_invoice(order_data, transaction)
            payment_result["invoice_id"] = invoice_id
        
        return payment_result
    
    def _process_credit_card_payment(self, amount, payment_details):
        """Process credit card payment"""
        # In a real implementation, this would integrate with a payment gateway
        self.logger.info(f"Processing credit card payment of {amount}")
        
        # Simulate payment processing
        # In production, this would call an actual payment gateway API
        return {
            "success": True,
            "transaction_id": f"CC-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "status": "completed",
            "amount": amount,
            "processor_response": {
                "authorization_code": "AUTH123456",
                "processor_id": "VISA-12345"
            }
        }
    
    def _process_paypal_payment(self, amount, payment_details):
        """Process PayPal payment"""
        # Simulate PayPal payment processing
        self.logger.info(f"Processing PayPal payment of {amount}")
        return {
            "success": True,
            "transaction_id": f"PP-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "status": "completed",
            "amount": amount
        }
    
    def _process_bank_transfer(self, amount, payment_details):
        """Process bank transfer payment"""
        # Simulate bank transfer processing
        self.logger.info(f"Processing bank transfer of {amount}")
        return {
            "success": True,
            "transaction_id": f"BT-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "status": "pending",  # Bank transfers typically start as pending
            "amount": amount,
            "estimated_completion_date": (datetime.now().date() + timedelta(days=2)).isoformat()
        }
    
    def _process_bit_payment(self, amount, payment_details):
        """Process Bit payment (Israeli payment app)"""
        # Simulate Bit payment processing
        self.logger.info(f"Processing Bit payment of {amount}")
        return {
            "success": True,
            "transaction_id": f"BIT-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "status": "completed",
            "amount": amount
        }
    
    def _process_cash_payment(self, amount, payment_details):
        """Process cash payment"""
        # Simulate cash payment processing
        self.logger.info(f"Recording cash payment of {amount}")
        return {
            "success": True,
            "transaction_id": f"CASH-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "status": "completed",
            "amount": amount
        }
    
    def _calculate_final_amount(self, order_data):
        """
        Calculate final amount including taxes and discounts
        
        Args:
            order_data (dict): Order information
            
        Returns:
            float: Final amount
        """
        subtotal = sum(item["price"] * item["quantity"] for item in order_data["items"])
        
        # Apply discounts
        discount_amount = 0
        
        # Check for bulk discount
        total_quantity = sum(item["quantity"] for item in order_data["items"])
        if total_quantity >= self.discount_rules["bulk"]["threshold"]:
            discount_amount += subtotal * self.discount_rules["bulk"]["rate"]
        
        # Check for loyal customer discount
        if order_data.get("previous_orders", 0) >= self.discount_rules["loyal_customer"]["threshold"]:
            discount_amount += subtotal * self.discount_rules["loyal_customer"]["rate"]
        
        # Check for seasonal discount
        if self.discount_rules["seasonal"]["active"]:
            discount_amount += subtotal * self.discount_rules["seasonal"]["rate"]
        
        # Calculate amount after discounts
        amount_after_discount = subtotal - discount_amount
        
        # Apply VAT
        vat_amount = amount_after_discount * self.tax_rates["vat"]
        
        # Calculate final amount
        final_amount = amount_after_discount + vat_amount
        
        return round(final_amount, 2)
    
    def _update_crm_with_payment(self, transaction):
        """
        Update CRM system with payment information
        
        Args:
            transaction (dict): Transaction information
        """
        # In a real implementation, this would integrate with the CRM system
        self.logger.info(f"Updating CRM with transaction {transaction['transaction_id']}")
        
        # Simulate CRM update
        # In production, this would call the CRM API
        crm_data = {
            "action": "payment_recorded",
            "transaction_id": transaction["transaction_id"],
            "order_id": transaction["order_id"],
            "customer_id": transaction["customer_id"],
            "amount": transaction["amount"],
            "payment_method": transaction["payment_method"],
            "status": transaction["status"],
            "timestamp": transaction["timestamp"]
        }
        
        # Log the CRM update data
        self.logger.debug(f"CRM update data: {json.dumps(crm_data)}")
        
        return True
    
    def generate_invoice(self, order_data, transaction):
        """
        Generate invoice for an order
        
        Args:
            order_data (dict): Order information
            transaction (dict): Transaction information
            
        Returns:
            str: Invoice ID
        """
        self.logger.info(f"Generating invoice for order {order_data['order_id']}")
        
        # Generate invoice ID
        invoice_id = f"INV-{datetime.now().strftime('%Y%m%d')}-{order_data['order_id']}"
        
        # Select invoice template
        template = self.invoice_templates["standard"]
        if order_data.get("invoice_type") in self.invoice_templates:
            template = self.invoice_templates[order_data["invoice_type"]]
        
        # In a real implementation, this would generate an actual invoice document
        # using the selected template and order/transaction data
        
        # Record invoice generation
        invoice_data = {
            "invoice_id": invoice_id,
            "order_id": order_data["order_id"],
            "customer_id": order_data["customer_id"],
            "transaction_id": transaction["transaction_id"],
            "amount": transaction["amount"],
            "items": order_data["items"],
            "tax_details": {
                "vat_rate": self.tax_rates["vat"],
                "vat_amount": transaction["amount"] * self.tax_rates["vat"] / (1 + self.tax_rates["vat"])
            },
            "generated_date": datetime.now().isoformat(),
            "template_used": template
        }
        
        # Log the invoice data
        self.logger.debug(f"Invoice data: {json.dumps(invoice_data)}")
        
        # Update CRM with invoice information
        self._update_crm_with_invoice(invoice_data)
        
        return invoice_id
    
    def _update_crm_with_invoice(self, invoice_data):
        """
        Update CRM system with invoice information
        
        Args:
            invoice_data (dict): Invoice information
        """
        # In a real implementation, this would integrate with the CRM system
        self.logger.info(f"Updating CRM with invoice {invoice_data['invoice_id']}")
        
        # Simulate CRM update
        # In production, this would call the CRM API
        crm_data = {
            "action": "invoice_generated",
            "invoice_id": invoice_data["invoice_id"],
            "order_id": invoice_data["order_id"],
            "customer_id": invoice_data["customer_id"],
            "transaction_id": invoice_data["transaction_id"],
            "amount": invoice_data["amount"],
            "generated_date": invoice_data["generated_date"]
        }
        
        # Log the CRM update data
        self.logger.debug(f"CRM update data: {json.dumps(crm_data)}")
        
        return True
    
    def process_refund(self, order_id, refund_amount, reason):
        """
        Process refund for an order
        
        Args:
            order_id (str): Order ID
            refund_amount (float): Amount to refund
            reason (str): Reason for refund
            
        Returns:
            dict: Refund result with refund ID and status
        """
        self.logger.info(f"Processing refund of {refund_amount} for order {order_id}")
        
        # Find original transaction
        original_transaction = next(
            (t for t in self.transaction_history if t["order_id"] == order_id),
            None
        )
        
        if not original_transaction:
            self.logger.error(f"No transaction found for order {order_id}")
            return {
                "success": False,
                "error": "No transaction found for this order",
                "order_id": order_id
            }
        
        # Validate refund amount
        if refund_amount > original_transaction["amount"]:
            self.logger.error(f"Refund amount {refund_amount} exceeds original amount {original_transaction['amount']}")
            return {
                "success": False,
                "error": "Refund amount exceeds original payment amount",
                "order_id": order_id
            }
        
        # Process refund
        # In a real implementation, this would integrate with payment processors
        refund_id = f"REF-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        # Record refund transaction
        refund_transaction = {
            "refund_id": refund_id,
            "original_transaction_id": original_transaction["transaction_id"],
            "order_id": order_id,
            "customer_id": original_transaction["customer_id"],
            "amount": refund_amount,
            "reason": reason,
            "status": "completed",
            "timestamp": datetime.now().isoformat()
        }
        self.transaction_history.append(refund_transaction)
        
        # Update CRM with refund information
        self._update_crm_with_refund(refund_transaction)
        
        # Generate credit note
        credit_note_id = self.generate_credit_note(order_id, refund_transaction)
        
        return {
            "success": True,
            "refund_id": refund_id,
            "status": "completed",
            "amount": refund_amount,
            "credit_note_id": credit_note_id
        }
    
    def _update_crm_with_refund(self, refund_transaction):
        """
        Update CRM system with refund information
        
        Args:
            refund_transaction (dict): Refund transaction information
        """
        # In a real implementation, this would integrate with the CRM system
        self.logger.info(f"Updating CRM with refund {refund_transaction['refund_id']}")
        
        # Simulate CRM update
        # In production, this would call the CRM API
        crm_data = {
            "action": "refund_processed",
            "refund_id": refund_transaction["refund_id"],
            "original_transaction_id": refund_transaction["original_transaction_id"],
            "order_id": refund_transaction["order_id"],
            "customer_id": refund_transaction["customer_id"],
            "amount": refund_transaction["amount"],
            "reason": refund_transaction["reason"],
            "status": refund_transaction["status"],
            "timestamp": refund_transaction["timestamp"]
        }
        
        # Log the CRM update data
        self.logger.debug(f"CRM update data: {json.dumps(crm_data)}")
        
        return True
    
    def generate_credit_note(self, order_id, refund_transaction):
        """
        Generate credit note for a refund
        
        Args:
            order_id (str): Order ID
            refund_transaction (dict): Refund transaction information
            
        Returns:
            str: Credit note ID
        """
        self.logger.info(f"Generating credit note for refund {refund_transaction['refund_id']}")
        
        # Generate credit note ID
        credit_note_id = f"CN-{datetime.now().strftime('%Y%m%d')}-{order_id}"
        
        # In a real implementation, this would generate an actual credit note document
        
        # Record credit note generation
        credit_note_data = {
            "credit_note_id": credit_note_id,
            "refund_id": refund_transaction["refund_id"],
            "order_id": order_id,
            "customer_id": refund_transaction["customer_id"],
            "amount": refund_transaction["amount"],
            "reason": refund_transaction["reason"],
            "generated_date": datetime.now().isoformat()
        }
        
        # Log the credit note data
        self.logger.debug(f"Credit note data: {json.dumps(credit_note_data)}")
        
        # Update CRM with credit note information
        self._update_crm_with_credit_note(credit_note_data)
        
        return credit_note_id
    
    def _update_crm_with_credit_note(self, credit_note_data):
        """
        Update CRM system with credit note information
        
        Args:
            credit_note_data (dict): Credit note information
        """
        # In a real implementation, this would integrate with the CRM system
        self.logger.info(f"Updating CRM with credit note {credit_note_data['credit_note_id']}")
        
        # Simulate CRM update
        # In production, this would call the CRM API
        crm_data = {
            "action": "credit_note_generated",
            "credit_note_id": credit_note_data["credit_note_id"],
            "refund_id": credit_note_data["refund_id"],
            "order_id": credit_note_data["order_id"],
            "customer_id": credit_note_data["customer_id"],
            "amount": credit_note_data["amount"],
            "reason": credit_note_data["reason"],
            "generated_date": credit_note_data["generated_date"]
        }
        
        # Log the CRM update data
        self.logger.debug(f"CRM update data: {json.dumps(crm_data)}")
        
        return True
    
    def get_transaction_history(self, filters=None):
        """
        Get transaction history with optional filters
        
        Args:
            filters (dict): Filters to apply
            
        Returns:
            list: Filtered transaction history
        """
        if not filters:
            return self.transaction_history
        
        filtered_history = self.transaction_history
        
        # Apply filters
        if "customer_id" in filters:
            filtered_history = [t for t in filtered_history if t["customer_id"] == filters["customer_id"]]
        
        if "order_id" in filters:
            filtered_history = [t for t in filtered_history if t["order_id"] == filters["order_id"]]
        
        if "date_from" in filters:
            date_from = datetime.fromisoformat(filters["date_from"])
            filtered_history = [
                t for t in filtered_history 
                if datetime.fromisoformat(t["timestamp"]) >= date_from
            ]
        
        if "date_to" in filters:
            date_to = datetime.fromisoformat(filters["date_to"])
            filtered_history = [
                t for t in filtered_history 
                if datetime.fromisoformat(t["timestamp"]) <= date_to
            ]
        
        return filtered_history
    
    def generate_financial_report(self, report_type, period_start, period_end):
        """
        Generate financial report
        
        Args:
            report_type (str): Type of report (sales, refunds, taxes, etc.)
            period_start (str): Start date in ISO format
            period_end (str): End date in ISO format
            
        Returns:
            dict: Report data
        """
        self.logger.info(f"Generating {report_type} report from {period_start} to {period_end}")
        
        # Convert dates to datetime objects
        start_date = datetime.fromisoformat(period_start)
        end_date = datetime.fromisoformat(period_end)
        
        # Filter transactions by date range
        transactions = [
            t for t in self.transaction_history 
            if start_date <= datetime.fromisoformat(t["timestamp"]) <= end_date
        ]
        
        # Generate report based on type
        if report_type == "sales":
            return self._generate_sales_report(transactions)
        elif report_type == "refunds":
            return self._generate_refunds_report(transactions)
        elif report_type == "taxes":
            return self._generate_tax_report(transactions)
        else:
            self.logger.error(f"Unsupported report type: {report_type}")
            return {
                "success": False,
                "error": f"Unsupported report type: {report_type}"
            }
    
    def _generate_sales_report(self, transactions):
        """Generate sales report from transactions"""
        # Filter only payment transactions (not refunds)
        payment_transactions = [t for t in transactions if "refund_id" not in t]
        
        # Calculate total sales
        total_sales = sum(t["amount"] for t in payment_transactions)
        
        # Group by payment method
        sales_by_method = {}
        for t in payment_transactions:
            method = t.get("payment_method", "unknown")
            if method not in sales_by_method:
                sales_by_method[method] = 0
            sales_by_method[method] += t["amount"]
        
        # Group by day
        sales_by_day = {}
        for t in payment_transactions:
            day = datetime.fromisoformat(t["timestamp"]).strftime("%Y-%m-%d")
            if day not in sales_by_day:
                sales_by_day[day] = 0
            sales_by_day[day] += t["amount"]
        
        return {
            "report_type": "sales",
            "total_sales": total_sales,
            "transaction_count": len(payment_transactions),
            "sales_by_payment_method": sales_by_method,
            "sales_by_day": sales_by_day,
            "average_transaction_value": total_sales / len(payment_transactions) if payment_transactions else 0
        }
    
    def _generate_refunds_report(self, transactions):
        """Generate refunds report from transactions"""
        # Filter only refund transactions
        refund_transactions = [t for t in transactions if "refund_id" in t]
        
        # Calculate total refunds
        total_refunds = sum(t["amount"] for t in refund_transactions)
        
        # Group by reason
        refunds_by_reason = {}
        for t in refund_transactions:
            reason = t.get("reason", "unknown")
            if reason not in refunds_by_reason:
                refunds_by_reason[reason] = 0
            refunds_by_reason[reason] += t["amount"]
        
        # Group by day
        refunds_by_day = {}
        for t in refund_transactions:
            day = datetime.fromisoformat(t["timestamp"]).strftime("%Y-%m-%d")
            if day not in refunds_by_day:
                refunds_by_day[day] = 0
            refunds_by_day[day] += t["amount"]
        
        return {
            "report_type": "refunds",
            "total_refunds": total_refunds,
            "refund_count": len(refund_transactions),
            "refunds_by_reason": refunds_by_reason,
            "refunds_by_day": refunds_by_day,
            "average_refund_value": total_refunds / len(refund_transactions) if refund_transactions else 0
        }
    
    def _generate_tax_report(self, transactions):
        """Generate tax report from transactions"""
        # Filter only payment transactions (not refunds)
        payment_transactions = [t for t in transactions if "refund_id" not in t]
        
        # Calculate total sales
        total_sales = sum(t["amount"] for t in payment_transactions)
        
        # Calculate VAT
        vat_rate = self.tax_rates["vat"]
        total_vat = total_sales * vat_rate / (1 + vat_rate)
        
        return {
            "report_type": "taxes",
            "total_sales": total_sales,
            "vat_rate": vat_rate,
            "total_vat": total_vat,
            "net_sales": total_sales - total_vat
        }
from datetime import datetime
import os
import uuid
from .base_agent import AIAgent

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class FinanceAgent(AIAgent):
    """
    Finance Agent for AutoSpareFinder system.
    Handles payments, credits, invoicing, and financial record-keeping in the CRM.
    """
    
    def __init__(self, agent_id=None, name="Finance Agent", model_type="gpt-4", config=None):
        """
        Initialize the Finance Agent
        
        Args:
            agent_id (str): Unique identifier for the agent
            name (str): Name of the agent
            model_type (str): Type of AI model to use
            config (dict): Configuration parameters for the agent
        """
        # Initialize finance-specific attributes before calling parent constructor
        self.transaction_history = []
        self.invoice_registry = {}
        self.payment_methods = {}
        self.tax_rates = {}
        self.discount_rules = {}
        self.crm_interface = None
        
        # Now call parent constructor which will call _initialize_components
        super().__init__(agent_id, name, model_type, config)
        
        logger.info(f"Finance Agent {self.name} initialized with {len(self.payment_methods)} payment methods")
    
    def _initialize_components(self):
        """Initialize agent-specific components"""
        # Set up payment methods
        default_payment_methods = {
            'credit_card': {
                'enabled': True,
                'fee_percentage': 2.5,
                'processors': ['stripe', 'paypal']
            },
            'bank_transfer': {
                'enabled': True,
                'fee_percentage': 0.5,
                'processing_days': 2
            },
            'cash': {
                'enabled': True,
                'fee_percentage': 0
            }
        }
        
        # Set up tax rates
        default_tax_rates = {
            'standard': 17.0,  # Standard VAT in Israel
            'reduced': 0.0,    # Some items might be tax exempt
        }
        
        # Set up discount rules
        default_discount_rules = {
            'volume': {
                'threshold': 5,  # Number of items
                'discount_percentage': 5.0
            },
            'loyalty': {
                'threshold': 3,  # Number of previous orders
                'discount_percentage': 7.0
            },
            'seasonal': {
                'active': False,
                'start_date': None,
                'end_date': None,
                'discount_percentage': 10.0
            }
        }
        
        # Load configuration or use defaults
        self.payment_methods = self.config.get('payment_methods', default_payment_methods) if self.config else default_payment_methods
        self.tax_rates = self.config.get('tax_rates', default_tax_rates) if self.config else default_tax_rates
        self.discount_rules = self.config.get('discount_rules', default_discount_rules) if self.config else default_discount_rules
        
        # Set up CRM interface if provided in config
        if self.config and 'crm_interface' in self.config:
            self.crm_interface = self.config['crm_interface']
            logger.info("CRM interface connected to Finance Agent")
        
        logger.info(f"Finance Agent components initialized with {len(self.payment_methods)} payment methods, {len(self.tax_rates)} tax rates, and {len(self.discount_rules)} discount rules")
    
    def process(self, input_data):
        """
        Process a finance-related request
        
        Args:
            input_data (dict): Request data containing finance operation details
            
        Returns:
            dict: Response with operation results
        """
        self.update_status("processing")
        
        try:
            request_type = input_data.get('request_type', '')
            
            if request_type == 'process_payment':
                return self._process_payment(input_data)
            elif request_type == 'issue_refund':
                return self._issue_refund(input_data)
            elif request_type == 'generate_invoice':
                return self._generate_invoice(input_data)
            elif request_type == 'calculate_quote':
                return self._calculate_quote(input_data)
            elif request_type == 'check_payment_status':
                return self._check_payment_status(input_data)
            elif request_type == 'get_transaction_history':
                return self._get_transaction_history(input_data)
            else:
                logger.warning(f"Unknown request type: {request_type}")
                return {
                    'status': 'error',
                    'message': f"Unknown request type: {request_type}"
                }
        except Exception as e:
            logger.error(f"Error processing finance request: {e}")
            return {
                'status': 'error',
                'message': str(e)
            }
        finally:
            self.update_status("idle")
    
    def _process_payment(self, input_data):
        """
        Process a payment for an order
        
        Args:
            input_data (dict): Payment details
            
        Returns:
            dict: Payment processing result
        """
        # Extract payment details
        order_id = input_data.get('order_id', '')
        amount = input_data.get('amount', 0.0)
        payment_method = input_data.get('payment_method', 'credit_card')
        customer_id = input_data.get('customer_id', '')
        payment_details = input_data.get('payment_details', {})
        
        # Validate input
        if not order_id:
            return {'status': 'error', 'message': 'Order ID is required'}
        if amount <= 0:
            return {'status': 'error', 'message': 'Payment amount must be greater than zero'}
        if payment_method not in self.payment_methods:
            return {'status': 'error', 'message': f'Unsupported payment method: {payment_method}'}
        if not self.payment_methods[payment_method].get('enabled', False):
            return {'status': 'error', 'message': f'Payment method {payment_method} is currently disabled'}
        
        # Generate transaction ID
        transaction_id = f"TXN-{datetime.now().strftime('%Y%m%d%H%M%S')}-{str(uuid.uuid4())[:8]}"
        
        # Calculate fees
        fee_percentage = self.payment_methods[payment_method].get('fee_percentage', 0)
        fee_amount = (amount * fee_percentage) / 100
        
        # In a real implementation, this would integrate with payment processors
        # For now, we'll simulate a successful payment
        
        # Create transaction record
        transaction = {
            'transaction_id': transaction_id,
            'order_id': order_id,
            'customer_id': customer_id,
            'amount': amount,
            'fee_amount': fee_amount,
            'net_amount': amount - fee_amount,
            'payment_method': payment_method,
            'status': 'completed',
            'timestamp': datetime.now().isoformat(),
            'details': payment_details
        }
        
        # Add to transaction history
        self.transaction_history.append(transaction)
        
        # Update CRM if available
        if self.crm_interface:
            crm_update = {
                'customer_id': customer_id,
                'transaction_id': transaction_id,
                'order_id': order_id,
                'amount': amount,
                'payment_method': payment_method,
                'status': 'completed',
                'timestamp': transaction['timestamp']
            }
            
            try:
                self.crm_interface.update_financial_record(crm_update)
                logger.info(f"Updated CRM with transaction {transaction_id}")
            except Exception as e:
                logger.error(f"Error updating CRM: {e}")
        
        logger.info(f"Processed payment for order {order_id}: {amount} via {payment_method}")
        
        return {
            'status': 'success',
            'message': 'Payment processed successfully',
            'transaction_id': transaction_id,
            'order_id': order_id,
            'amount': amount,
            'fee_amount': fee_amount,
            'net_amount': transaction['net_amount'],
            'timestamp': transaction['timestamp']
        }
    
    def _issue_refund(self, input_data):
        """
        Issue a refund for a previous payment
        
        Args:
            input_data (dict): Refund details
            
        Returns:
            dict: Refund processing result
        """
        # Extract refund details
        transaction_id = input_data.get('transaction_id', '')
        amount = input_data.get('amount', 0.0)
        reason = input_data.get('reason', '')
        
        # Validate input
        if not transaction_id:
            return {'status': 'error', 'message': 'Transaction ID is required'}
        
        # Find the original transaction
        original_transaction = None
        for transaction in self.transaction_history:
            if transaction['transaction_id'] == transaction_id:
                original_transaction = transaction
                break
        
        if not original_transaction:
            return {'status': 'error', 'message': f'Transaction {transaction_id} not found'}
        
        # Validate refund amount
        if amount <= 0:
            return {'status': 'error', 'message': 'Refund amount must be greater than zero'}
        if amount > original_transaction['amount']:
            return {'status': 'error', 'message': 'Refund amount cannot exceed original payment amount'}
        
        # Generate refund transaction ID
        refund_id = f"REF-{datetime.now().strftime('%Y%m%d%H%M%S')}-{str(uuid.uuid4())[:8]}"
        
        # In a real implementation, this would integrate with payment processors
        # For now, we'll simulate a successful refund
        
        # Create refund transaction record
        refund_transaction = {
            'transaction_id': refund_id,
            'reference_transaction_id': transaction_id,
            'order_id': original_transaction['order_id'],
            'customer_id': original_transaction['customer_id'],
            'amount': -amount,  # Negative amount for refunds
            'payment_method': original_transaction['payment_method'],
            'status': 'completed',
            'timestamp': datetime.now().isoformat(),
            'reason': reason,
            'details': {
                'original_transaction': transaction_id,
                'refund_reason': reason
            }
        }
        
        # Add to transaction history
        self.transaction_history.append(refund_transaction)
        
        # Update CRM if available
        if self.crm_interface:
            crm_update = {
                'customer_id': original_transaction['customer_id'],
                'transaction_id': refund_id,
                'reference_transaction_id': transaction_id,
                'order_id': original_transaction['order_id'],
                'amount': -amount,
                'status': 'completed',
                'timestamp': refund_transaction['timestamp'],
                'reason': reason
            }
            
            try:
                self.crm_interface.update_financial_record(crm_update)
                logger.info(f"Updated CRM with refund {refund_id}")
            except Exception as e:
                logger.error(f"Error updating CRM: {e}")
        
        logger.info(f"Issued refund {refund_id} for transaction {transaction_id}: {amount}")
        
        return {
            'status': 'success',
            'message': 'Refund processed successfully',
            'refund_id': refund_id,
            'original_transaction_id': transaction_id,
            'amount': amount,
            'timestamp': refund_transaction['timestamp']
        }
    
    def _generate_invoice(self, input_data):
        """
        Generate an invoice for an order
        
        Args:
            input_data (dict): Invoice details
            
        Returns:
            dict: Invoice generation result
        """
        # Extract invoice details
        order_id = input_data.get('order_id', '')
        customer_id = input_data.get('customer_id', '')
        customer_details = input_data.get('customer_details', {})
        items = input_data.get('items', [])
        transaction_id = input_data.get('transaction_id', '')
        
        # Validate input
        if not order_id:
            return {'status': 'error', 'message': 'Order ID is required'}
        if not items:
            return {'status': 'error', 'message': 'No items specified for invoice'}
        
        # Generate invoice number
        invoice_number = f"INV-{datetime.now().strftime('%Y%m%d')}-{str(uuid.uuid4())[:6]}"
        
        # Calculate totals
        subtotal = sum(item.get('price', 0) * item.get('quantity', 1) for item in items)
        
        # Apply discounts if applicable
        discount_amount = 0
        discount_description = ""
        
        # Volume discount
        if len(items) >= self.discount_rules.get('volume', {}).get('threshold', 0):
            volume_discount_percentage = self.discount_rules.get('volume', {}).get('discount_percentage', 0)
            volume_discount = (subtotal * volume_discount_percentage) / 100
            discount_amount += volume_discount
            discount_description += f"Volume discount ({volume_discount_percentage}%): {volume_discount:.2f}\n"
        
        # Loyalty discount (would check customer history in a real implementation)
        if customer_id and self.crm_interface:
            try:
                customer_orders = self.crm_interface.get_customer_orders(customer_id)
                if len(customer_orders) >= self.discount_rules.get('loyalty', {}).get('threshold', 0):
                    loyalty_discount_percentage = self.discount_rules.get('loyalty', {}).get('discount_percentage', 0)
                    loyalty_discount = (subtotal * loyalty_discount_percentage) / 100
                    discount_amount += loyalty_discount
                    discount_description += f"Loyalty discount ({loyalty_discount_percentage}%): {loyalty_discount:.2f}\n"
            except Exception as e:
                logger.error(f"Error checking customer history for loyalty discount: {e}")
        
        # Seasonal discount
        seasonal = self.discount_rules.get('seasonal', {})
        if seasonal.get('active', False):
            now = datetime.now()
            start_date = datetime.fromisoformat(seasonal.get('start_date')) if seasonal.get('start_date') else None
            end_date = datetime.fromisoformat(seasonal.get('end_date')) if seasonal.get('end_date') else None
            
            if (not start_date or now >= start_date) and (not end_date or now <= end_date):
                seasonal_discount_percentage = seasonal.get('discount_percentage', 0)
                seasonal_discount = (subtotal * seasonal_discount_percentage) / 100
                discount_amount += seasonal_discount
                discount_description += f"Seasonal discount ({seasonal_discount_percentage}%): {seasonal_discount:.2f}\n"
        
        # Calculate tax
        tax_rate = self.tax_rates.get('standard', 0)
        tax_amount = ((subtotal - discount_amount) * tax_rate) / 100
        
        # Calculate total
        total = subtotal - discount_amount + tax_amount
        
        # Create invoice
        invoice = {
            'invoice_number': invoice_number,
            'order_id': order_id,
            'customer_id': customer_id,
            'customer_details': customer_details,
            'transaction_id': transaction_id,
            'items': items,
            'subtotal': subtotal,
            'discount_amount': discount_amount,
            'discount_description': discount_description.strip(),
            'tax_rate': tax_rate,
            'tax_amount': tax_amount,
            'total': total,
            'status': 'issued',
            'issue_date': datetime.now().isoformat(),
            'due_date': None,  # For prepaid orders
            'notes': ''
        }
        
        # Store in invoice registry
        self.invoice_registry[invoice_number] = invoice
        
        # Update CRM if available
        if self.crm_interface:
            crm_update = {
                'customer_id': customer_id,
                'invoice_number': invoice_number,
                'order_id': order_id,
                'transaction_id': transaction_id,
                'total': total,
                'status': 'issued',
                'issue_date': invoice['issue_date']
            }
            
            try:
                self.crm_interface.update_invoice_record(crm_update)
                logger.info(f"Updated CRM with invoice {invoice_number}")
            except Exception as e:
                logger.error(f"Error updating CRM: {e}")
        
        logger.info(f"Generated invoice {invoice_number} for order {order_id}: {total}")
        
        return {
            'status': 'success',
            'message': 'Invoice generated successfully',
            'invoice_number': invoice_number,
            'order_id': order_id,
            'total': total,
            'invoice': invoice
        }
    
    def _calculate_quote(self, input_data):
        """
        Calculate a price quote for a potential order
        
        Args:
            input_data (dict): Quote details
            
        Returns:
            dict: Quote calculation result
        """
        # Extract quote details
        items = input_data.get('items', [])
        customer_id = input_data.get('customer_id', '')
        
        # Validate input
        if not items:
            return {'status': 'error', 'message': 'No items specified for quote'}
        
        # Calculate subtotal
        subtotal = sum(item.get('price', 0) * item.get('quantity', 1) for item in items)
        
        # Apply discounts if applicable
        discount_amount = 0
        discount_breakdown = []
        
        # Volume discount
        if len(items) >= self.discount_rules.get('volume', {}).get('threshold', 0):
            volume_discount_percentage = self.discount_rules.get('volume', {}).get('discount_percentage', 0)
            volume_discount = (subtotal * volume_discount_percentage) / 100
            discount_amount += volume_discount
            discount_breakdown.append({
                'type': 'volume',
                'percentage': volume_discount_percentage,
                'amount': volume_discount
            })
        
        # Loyalty discount (would check customer history in a real implementation)
        if customer_id and self.crm_interface:
            try:
                customer_orders = self.crm_interface.get_customer_orders(customer_id)
                if len(customer_orders) >= self.discount_rules.get('loyalty', {}).get('threshold', 0):
                    loyalty_discount_percentage = self.discount_rules.get('loyalty', {}).get('discount_percentage', 0)
                    loyalty_discount = (subtotal * loyalty_discount_percentage) / 100
                    discount_amount += loyalty_discount
                    discount_breakdown.append({
                        'type': 'loyalty',
                        'percentage': loyalty_discount_percentage,
                        'amount': loyalty_discount
                    })
            except Exception as e:
                logger.error(f"Error checking customer history for loyalty discount: {e}")
        
        # Seasonal discount
        seasonal = self.discount_rules.get('seasonal', {})
        if seasonal.get('active', False):
            now = datetime.now()
            start_date = datetime.fromisoformat(seasonal.get('start_date')) if seasonal.get('start_date') else None
            end_date = datetime.fromisoformat(seasonal.get('end_date')) if seasonal.get('end_date') else None
            
            if (not start_date or now >= start_date) and (not end_date or now <= end_date):
                seasonal_discount_percentage = seasonal.get('discount_percentage', 0)
                seasonal_discount = (subtotal * seasonal_discount_percentage) / 100
                discount_amount += seasonal_discount
                discount_breakdown.append({
                    'type': 'seasonal',
                    'percentage': seasonal_discount_percentage,
                    'amount': seasonal_discount
                })
        
        # Calculate tax
        tax_rate = self.tax_rates.get('standard', 0)
        tax_amount = ((subtotal - discount_amount) * tax_rate) / 100
        
        # Calculate total
        total = subtotal - discount_amount + tax_amount
        
        # Create quote
        quote = {
            'items': items,
            'subtotal': subtotal,
            'discount_amount': discount_amount,
            'discount_breakdown': discount_breakdown,
            'tax_rate': tax_rate,
            'tax_amount': tax_amount,
            'total': total,
            'valid_until': (datetime.now() + datetime.timedelta(days=7)).isoformat(),  # Valid for 7 days
            'timestamp': datetime.now().isoformat()
        }
        
        logger.info(f"Calculated quote: {total}")
        
        return {
            'status': 'success',
            'message': 'Quote calculated successfully',
            'quote': quote
        }
    
    def _check_payment_status(self, input_data):
        """
        Check the status of a payment
        
        Args:
            input_data (dict): Payment identifier
            
        Returns:
            dict: Payment status information
        """
        # Extract payment details
        transaction_id = input_data.get('transaction_id', '')
        order_id = input_data.get('order_id', '')
        
        # Validate input
        if not transaction_id and not order_id:
            return {'status': 'error', 'message': 'Either transaction ID or order ID is required'}
        
        # Find the transaction
        transaction = None
        
        if transaction_id:
            for txn in self.transaction_history:
                if txn['transaction_id'] == transaction_id:
                    transaction = txn
                    break
        elif order_id:
            # Find the most recent transaction for this order
            for txn in reversed(self.transaction_history):
                if txn['order_id'] == order_id:
                    transaction = txn
                    break
        
        if not transaction:
            return {'status': 'error', 'message': 'Transaction not found'}
        
        logger.info(f"Checked payment status for transaction {transaction['transaction_id']}: {transaction['status']}")
        
        return {
            'status': 'success',
            'transaction_id': transaction['transaction_id'],
            'order_id': transaction['order_id'],
            'payment_status': transaction['status'],
            'amount': transaction['amount'],
            'payment_method': transaction['payment_method'],
            'timestamp': transaction['timestamp']
        }
    
    def _get_transaction_history(self, input_data):
        """
        Get transaction history for a customer or order
        
        Args:
            input_data (dict): Filter criteria
            
        Returns:
            dict: Transaction history
        """
        # Extract filter criteria
        customer_id = input_data.get('customer_id', '')
        order_id = input_data.get('order_id', '')
        start_date = input_data.get('start_date', '')
        end_date = input_data.get('end_date', '')
        limit = input_data.get('limit', 100)
        
        # Filter transactions
        filtered_transactions = self.transaction_history
        
        if customer_id:
            filtered_transactions = [t for t in filtered_transactions if t.get('customer_id') == customer_id]
        
        if order_id:
            filtered_transactions = [t for t in filtered_transactions if t.get('order_id') == order_id]
        
        if start_date:
            start = datetime.fromisoformat(start_date)
            filtered_transactions = [
                t for t in filtered_transactions 
                if datetime.fromisoformat(t['timestamp']) >= start
            ]
        
        if end_date:
            end = datetime.fromisoformat(end_date)
            filtered_transactions = [
                t for t in filtered_transactions 
                if datetime.fromisoformat(t['timestamp']) <= end
            ]
        
        # Sort by timestamp (newest first) and limit
        filtered_transactions = sorted(
            filtered_transactions, 
            key=lambda t: t['timestamp'], 
            reverse=True
        )[:limit]
        
        logger.info(f"Retrieved {len(filtered_transactions)} transaction records")
        
        return {
            'status': 'success',
            'transactions': filtered_transactions
        }
    
    def get_state(self):
        """
        Get the agent's current state
        
        Returns:
            dict: Agent state
        """
        # Get base state from parent class
        state = super().get_state()
        
        # Add finance agent specific state
        state.update({
            'transaction_history': self.transaction_history,
            'invoice_registry': self.invoice_registry,
            'payment_methods': self.payment_methods,
            'tax_rates': self.tax_rates,
            'discount_rules': self.discount_rules
        })
        
        return state
    
    def set_state(self, state):
        """
        Set the agent's state
        
        Args:
            state (dict): Agent state
        """
        # Set base state from parent class
        super().set_state(state)
        
        # Set finance agent specific state
        self.transaction_history = state.get('transaction_history', [])
        self.invoice_registry = state.get('invoice_registry', {})
        self.payment_methods = state.get('payment_methods', {})
        self.tax_rates = state.get('tax_rates', {})
        self.discount_rules = state.get('discount_rules', {})

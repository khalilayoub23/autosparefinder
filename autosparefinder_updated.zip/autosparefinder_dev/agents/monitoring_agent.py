import logging
import json
from datetime import datetime
from .base_agent import AIAgent

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class MonitoringAgent(AIAgent):
    """
    Monitoring Agent (Shira) - Responsible for real-time monitoring, 
    anomaly detection, and system health tracking.
    """
    
    def __init__(self, agent_id, name="Shira", model_type="gpt-4", config=None):
        """
        Initialize the Monitoring Agent
        
        Args:
            agent_id (str): Unique identifier for the agent
            name (str): Human-readable name for the agent
            model_type (str): Type of AI model to use
            config (dict, optional): Configuration parameters for the agent
        """
        super().__init__(agent_id, name, model_type, config)
        
        # Monitoring agent specific attributes
        self.alert_thresholds = self.config.get('alert_thresholds', {
            'critical': 90,
            'warning': 70,
            'info': 50
        })
        self.monitoring_history = []
        self.active_alerts = []
        
        logger.info(f"Monitoring Agent {self.name} initialized with {len(self.alert_thresholds)} alert thresholds")
    
    def _initialize_components(self):
        """Initialize agent-specific components"""
        # Set up monitoring rules
        self.monitoring_rules = {
            'system_metrics': {
                'cpu_usage': {'warning': 80, 'critical': 95},
                'memory_usage': {'warning': 85, 'critical': 95},
                'disk_usage': {'warning': 85, 'critical': 95},
                'response_time': {'warning': 2000, 'critical': 5000}  # in ms
            },
            'business_metrics': {
                'order_failure_rate': {'warning': 5, 'critical': 10},  # percentage
                'inventory_accuracy': {'warning': 90, 'critical': 80},  # percentage (below is bad)
                'customer_satisfaction': {'warning': 80, 'critical': 70}  # percentage (below is bad)
            },
            'security_metrics': {
                'failed_login_attempts': {'warning': 5, 'critical': 10},
                'unusual_access_patterns': {'warning': 3, 'critical': 5}
            }
        }
        
        logger.info(f"Monitoring Agent components initialized with {len(self.monitoring_rules)} rule categories")
    
    def process(self, input_data):
        """
        Process monitoring requests
        
        Args:
            input_data (dict): Input data containing monitoring information or request
            
        Returns:
            dict: Processing result
        """
        self.update_status("processing")
        
        try:
            request_type = input_data.get('request_type', '')
            
            if request_type == 'system_health':
                return self._check_system_health(input_data.get('metrics', {}))
            elif request_type == 'anomaly_detection':
                return self._detect_anomalies(input_data.get('data', {}))
            elif request_type == 'alert_management':
                return self._manage_alerts(input_data)
            elif request_type == 'get_monitoring_history':
                return self._get_monitoring_history(input_data)
            else:
                logger.warning(f"Unknown request type: {request_type}")
                return {
                    'status': 'error',
                    'message': f"Unknown request type: {request_type}"
                }
        
        except Exception as e:
            logger.error(f"Error processing monitoring request: {e}")
            return {
                'status': 'error',
                'message': str(e)
            }
        finally:
            self.update_status("idle")
    
    def _check_system_health(self, metrics):
        """
        Check system health based on provided metrics
        
        Args:
            metrics (dict): System metrics to check
            
        Returns:
            dict: System health assessment
        """
        if not metrics:
            return {
                'status': 'error',
                'message': 'No metrics provided for system health check'
            }
        
        issues = []
        warnings = []
        health_score = 100
        alert_level = "normal"
        
        # Check system metrics
        for metric_name, metric_value in metrics.items():
            category = None
            metric_key = metric_name
            
            # Determine the category and specific metric
            if '.' in metric_name:
                parts = metric_name.split('.')
                category = parts[0]
                metric_key = parts[1]
            
            # Check if we have rules for this metric
            rules = None
            if category and category in self.monitoring_rules and metric_key in self.monitoring_rules[category]:
                rules = self.monitoring_rules[category][metric_key]
            elif metric_name in self.monitoring_rules.get('system_metrics', {}):
                rules = self.monitoring_rules['system_metrics'][metric_name]
            
            if rules:
                # Check against thresholds
                if 'critical' in rules and self._compare_metric(metric_value, rules['critical'], metric_name):
                    issues.append(f"{metric_name}: {metric_value} (Critical threshold: {rules['critical']})")
                    health_score -= 20
                    alert_level = "critical"
                elif 'warning' in rules and self._compare_metric(metric_value, rules['warning'], metric_name):
                    warnings.append(f"{metric_name}: {metric_value} (Warning threshold: {rules['warning']})")
                    health_score -= 10
                    if alert_level != "critical":
                        alert_level = "warning"
        
        # Ensure health score is within bounds
        health_score = max(0, min(100, health_score))
        
        # Create a monitoring record
        timestamp = datetime.now().isoformat()
        monitoring_record = {
            'timestamp': timestamp,
            'metrics': metrics,
            'health_score': health_score,
            'alert_level': alert_level,
            'issues': issues,
            'warnings': warnings
        }
        
        # Add to monitoring history
        self.monitoring_history.append(monitoring_record)
        
        # Create alerts if needed
        if alert_level != "normal":
            alert = {
                'id': f"alert-{timestamp}",
                'timestamp': timestamp,
                'level': alert_level,
                'message': f"System health issues detected: {', '.join(issues) if issues else ', '.join(warnings)}",
                'metrics': metrics
            }
            self.active_alerts.append(alert)
        
        logger.info(f"System health check: Score {health_score}, Alert level {alert_level}")
        
        return {
            'status': 'success',
            'health_score': health_score,
            'alert_level': alert_level,
            'issues': issues,
            'warnings': warnings,
            'timestamp': timestamp
        }
    
    def _compare_metric(self, value, threshold, metric_name):
        """
        Compare a metric value against a threshold
        
        Args:
            value: The metric value
            threshold: The threshold to compare against
            metric_name: The name of the metric
            
        Returns:
            bool: True if threshold is exceeded, False otherwise
        """
        # For most metrics, higher values are worse (e.g., CPU usage)
        # But for some metrics, lower values are worse (e.g., customer satisfaction)
        inverse_metrics = [
            'inventory_accuracy', 
            'customer_satisfaction'
        ]
        
        is_inverse = any(inv_metric in metric_name for inv_metric in inverse_metrics)
        
        if is_inverse:
            return value < threshold
        else:
            return value > threshold
    
    def _detect_anomalies(self, data):
        """
        Detect anomalies in the provided data
        
        Args:
            data (dict): Data to analyze for anomalies
            
        Returns:
            dict: Anomaly detection results
        """
        if not data:
            return {
                'status': 'error',
                'message': 'No data provided for anomaly detection'
            }
        
        anomalies = []
        timestamp = datetime.now().isoformat()
        
        # Simple anomaly detection based on z-score
        # In a real implementation, this would use more sophisticated algorithms
        for metric_name, values in data.items():
            if isinstance(values, list) and len(values) > 5:
                # Calculate mean and standard deviation
                mean = sum(values) / len(values)
                std_dev = (sum((x - mean) ** 2 for x in values) / len(values)) ** 0.5
                
                if std_dev > 0:
                    # Check the latest value
                    latest = values[-1]
                    z_score = abs(latest - mean) / std_dev
                    
                    if z_score > 3:  # More than 3 standard deviations
                        anomalies.append({
                            'metric': metric_name,
                            'value': latest,
                            'z_score': z_score,
                            'mean': mean,
                            'std_dev': std_dev
                        })
        
        # Add to monitoring history
        self.monitoring_history.append({
            'timestamp': timestamp,
            'type': 'anomaly_detection',
            'data': data,
            'anomalies': anomalies
        })
        
        # Create alerts for anomalies
        if anomalies:
            alert = {
                'id': f"alert-{timestamp}",
                'timestamp': timestamp,
                'level': 'warning',
                'message': f"Anomalies detected in {len(anomalies)} metrics",
                'anomalies': anomalies
            }
            self.active_alerts.append(alert)
        
        logger.info(f"Anomaly detection: Found {len(anomalies)} anomalies")
        
        return {
            'status': 'success',
            'anomalies': anomalies,
            'timestamp': timestamp
        }
    
    def _manage_alerts(self, input_data):
        """
        Manage alerts (acknowledge, resolve, etc.)
        
        Args:
            input_data (dict): Alert management request
            
        Returns:
            dict: Alert management result
        """
        action = input_data.get('action', '')
        alert_id = input_data.get('alert_id', '')
        
        if not action:
            return {
                'status': 'error',
                'message': 'No action specified for alert management'
            }
        
        if action == 'get_active':
            return {
                'status': 'success',
                'active_alerts': self.active_alerts
            }
        
        if not alert_id:
            return {
                'status': 'error',
                'message': 'No alert ID specified'
            }
        
        # Find the alert
        alert = None
        for a in self.active_alerts:
            if a['id'] == alert_id:
                alert = a
                break
        
        if not alert:
            return {
                'status': 'error',
                'message': f'Alert not found: {alert_id}'
            }
        
        if action == 'acknowledge':
            alert['acknowledged'] = True
            alert['acknowledged_at'] = datetime.now().isoformat()
            alert['acknowledged_by'] = input_data.get('user', 'unknown')
            
            logger.info(f"Alert {alert_id} acknowledged by {alert['acknowledged_by']}")
            
            return {
                'status': 'success',
                'message': f'Alert {alert_id} acknowledged',
                'alert': alert
            }
        
        elif action == 'resolve':
            # Remove from active alerts
            self.active_alerts = [a for a in self.active_alerts if a['id'] != alert_id]
            
            # Add resolution info
            alert['resolved'] = True
            alert['resolved_at'] = datetime.now().isoformat()
            alert['resolved_by'] = input_data.get('user', 'unknown')
            alert['resolution_notes'] = input_data.get('notes', '')
            
            logger.info(f"Alert {alert_id} resolved by {alert['resolved_by']}")
            
            return {
                'status': 'success',
                'message': f'Alert {alert_id} resolved',
                'alert': alert
            }
        
        else:
            return {
                'status': 'error',
                'message': f'Unknown action: {action}'
            }
    
    def _get_monitoring_history(self, input_data):
        """
        Get monitoring history
        
        Args:
            input_data (dict): History request parameters
            
        Returns:
            dict: Monitoring history
        """
        limit = input_data.get('limit', 100)
        metric_filter = input_data.get('metric', None)
        from_time = input_data.get('from', None)
        to_time = input_data.get('to', None)
        
        # Filter history
        filtered_history = self.monitoring_history
        
        if metric_filter:
            filtered_history = [
                h for h in filtered_history 
                if 'metrics' in h and metric_filter in h['metrics']
            ]
        
        if from_time:
            filtered_history = [
                h for h in filtered_history 
                if h['timestamp'] >= from_time
            ]
        
        if to_time:
            filtered_history = [
                h for h in filtered_history 
                if h['timestamp'] <= to_time
            ]
        
        # Sort by timestamp (newest first) and limit
        filtered_history = sorted(
            filtered_history, 
            key=lambda h: h['timestamp'], 
            reverse=True
        )[:limit]
        
        logger.info(f"Retrieved {len(filtered_history)} monitoring history records")
        
        return {
            'status': 'success',
            'history': filtered_history
        }
    
    def get_state(self):
        """
        Get the agent's current state
        
        Returns:
            dict: Agent state
        """
        # Get base state from parent class
        state = super().get_state()
        
        # Add monitoring agent specific state
        state.update({
            'alert_thresholds': self.alert_thresholds,
            'active_alerts': self.active_alerts,
            'monitoring_history': self.monitoring_history[-100:] if self.monitoring_history else []  # Keep last 100 records
        })
        
        return state
    
    def set_state(self, state):
        """
        Set the agent's state
        
        Args:
            state (dict): Agent state
        """
        # Set base state from parent class
        super().set_state(state)
        
        # Set monitoring agent specific state
        self.alert_thresholds = state.get('alert_thresholds', self.alert_thresholds)
        self.active_alerts = state.get('active_alerts', [])
        self.monitoring_history = state.get('monitoring_history', [])

"""
agents/owner_console.py — the OWNER's private command console over WhatsApp.

When Khalil (OWNER_WHATSAPP_PHONE) messages the platform's WhatsApp, he is NOT a customer:
his messages are routed here (by routes/webhooks.py) instead of the customer sales brain
(process_user_message). This lets him hold a real two-way conversation with his agents —
AVI (the orchestrator/router) and NOA (social/marketing) — ask them about the live system,
give them tasks, and act on their notifications (e.g. approve/reject the NOA posts they send
him for approval) simply by replying.

Design:
  • Deterministic commands (fast, reliable, bilingual HE/EN) for the high-value actions:
      status | סטטוס            → full live system review
      harvester | שאיבה         → harvest-queue progress
      posts | פוסטים            → list NOA posts waiting for approval
      approve [id] | אשר        → approve + PUBLISH a pending NOA post (registry.dispatch)
      reject [id] | דחה         → reject a pending NOA post
      help | עזרה               → the command menu
  • Anything else → a real conversation with the chosen agent (prefix "noa"/"נועה" → NOA,
    else AVI), run in OWNER MODE: the agent is told it's talking to the owner (not a customer)
    and is given a LIVE system-status block so its answers are grounded, plus a short rolling
    history (Redis) so the conversation has memory.

Owner replies are sent back over WhatsApp by the webhook that calls this.
Last Updated: 2026-07-23
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from typing import Any, Dict, List

log = logging.getLogger("owner_console")

from sqlalchemy import text as _sql

# Module-level imports for _trigger_task's post-condition verifier so tests can
# patch them via agents.owner_console.{name} without relying on lazy-import timing.
from BACKEND_DATABASE_MODELS import async_session_factory  # noqa: E402
from resilience import job_registry_start, job_registry_finish  # noqa: E402

OWNER_PHONE = (os.getenv("OWNER_WHATSAPP_PHONE", "") or "").strip()
# WhatsApp now routes some contacts by a stable LID ("<digits>@lid") instead of the phone
# number (privacy update). The owner's device sends as a LID, so phone-only matching missed
# him and his messages fell through to the customer bot (found 2026-07-23: his inbound arrived
# as 98058566160397@lid, not +972586050155). Match the LID too. Comma-separated digits/LIDs OK.
OWNER_LIDS = {re.sub(r"[^\d]", "", x) for x in os.getenv("OWNER_WHATSAPP_LID", "").split(",") if x.strip()}
_HISTORY_KEY = "owner:console:history"
_HISTORY_MAX = 12  # turns kept for conversational memory


def _norm_phone(p: str) -> str:
    return re.sub(r"[^\d]", "", (p or "").replace("whatsapp:", ""))


def is_owner(phone: str) -> bool:
    """True if this sender is the platform owner — by phone OR by his WhatsApp LID. Never
    matches the platform's OWN number (that would be a self-loop); OWNER_PHONE is
    +972586050155, the platform account is a different number (see [[status-update-loop]])."""
    norm = _norm_phone(phone)
    if not norm:
        return False
    if OWNER_PHONE and norm == _norm_phone(OWNER_PHONE):
        return True
    if norm in OWNER_LIDS:
        return True
    return False


# ── live system status ────────────────────────────────────────────────────────
async def _harvest_stats(db) -> Dict[str, Any]:
    row = (await db.execute(_sql("""
        SELECT COUNT(*) FILTER (WHERE status IN ('done','empty')) done,
               COUNT(*) total,
               COUNT(DISTINCT brand_en) FILTER (WHERE status='done') bdone,
               COUNT(DISTINCT brand_en) btot,
               COUNT(*) FILTER (WHERE status='pending') pending,
               COUNT(*) FILTER (WHERE status='in_progress') in_progress,
               COALESCE(SUM(parts_found),0) parts
        FROM harvest_queue"""))).fetchone()
    if not row:
        return {}
    done, total, bdone, btot, pending, inprog, parts = row
    return {"done": done, "total": total, "pct": round(done * 100.0 / total, 1) if total else 0,
            "bdone": bdone, "btot": btot, "pending": pending, "in_progress": inprog, "parts": parts}


async def _catalog_stats(db) -> Dict[str, Any]:
    try:
        row = (await db.execute(_sql("""
            SELECT COUNT(*) FILTER (WHERE is_active) total,
                   COUNT(*) FILTER (WHERE is_active AND importer_price_ils>0) priced
            FROM parts_catalog"""))).fetchone()
        return {"total": row[0], "priced": row[1]} if row else {}
    except Exception:
        return {}


async def _agent_health(db) -> Dict[str, Any]:
    """Recent worker failures (real ones only — restart-orphans excluded by the guard)."""
    try:
        rows = (await db.execute(_sql("""
            SELECT split_part(job_id,':',1) job, status
            FROM job_registry
            WHERE started_at > NOW() - INTERVAL '3h' AND status IN ('failed','dead')
            ORDER BY started_at DESC LIMIT 6"""))).fetchall()
        return {"recent_failures": [f"{r[0]} ({r[1]})" for r in rows]}
    except Exception:
        return {"recent_failures": []}


async def build_status_snapshot(db, *, brief: bool = False) -> str:
    h = await _harvest_stats(db)
    parts_line = ""
    if h:
        parts_line = (f"🔧 שאיבת קטלוג: {h['done']:,}/{h['total']:,} דגמים ({h['pct']}%) · "
                      f"{h['bdone']}/{h['btot']} מותגים · בתהליך {h['in_progress']} · "
                      f"ממתינים {h['pending']:,} · חלקים {h['parts']:,}")
    if brief:
        return parts_line
    c = await _catalog_stats(db)
    cat_line = (f"📦 קטלוג פעיל: {c['total']:,} חלקים · עם מחיר {c['priced']:,}"
                if c else "")
    a = await _agent_health(db)
    fails = a.get("recent_failures") or []
    fail_line = ("✅ סוכנים ועובדים: אין כשלים ב-3 השעות האחרונות"
                 if not fails else "⚠️ כשלים אחרונים: " + ", ".join(fails))
    import subprocess
    try:
        load = subprocess.check_output(["cat", "/proc/loadavg"], timeout=5).decode().split()[0]
        load_line = f"🖥️ עומס מערכת (1דק'): {load} (6 ליבות)"
    except Exception:
        load_line = ""
    return "\n".join(x for x in [parts_line, cat_line, fail_line, load_line] if x)


# ── NOA post queue actions ────────────────────────────────────────────────────
async def _list_pending_posts(db, limit: int = 8) -> List[Dict[str, Any]]:
    rows = (await db.execute(_sql("""
        SELECT id, content, platforms, created_at
        FROM social_posts WHERE status='pending_approval'
        ORDER BY created_at DESC LIMIT :lim"""), {"lim": limit})).fetchall()
    out = []
    for r in rows:
        plats = r[2] if isinstance(r[2], list) else (json.loads(r[2]) if r[2] else [])
        out.append({"id": str(r[0]), "content": r[1] or "", "platforms": plats})
    return out


def _short(pid: str) -> str:
    return pid.replace("-", "")[:8]


async def _resolve_post(db, token: str):
    """Find a pending post by short-id token, or the newest pending if token empty."""
    token = (token or "").strip()
    rows = await _list_pending_posts(db, limit=25)
    if not rows:
        return None
    if not token:
        return rows[0]
    for p in rows:
        if _short(p["id"]).startswith(token.lower()) or p["id"].startswith(token.lower()):
            return p
    return None


async def _resolve_campaign(db, token: str):
    """Find a campaign by short-id token, or the newest campaign if token empty.
    Mirrors _resolve_post's convention so owner-console commands stay uniform."""
    token = (token or "").strip()
    rows = (await db.execute(_sql(
        "SELECT id FROM campaigns ORDER BY created_at DESC LIMIT 25"
    ))).fetchall()
    if not rows:
        return None
    if not token:
        return str(rows[0].id)
    for r in rows:
        cid = str(r.id)
        if _short(cid).startswith(token.lower()) or cid.startswith(token.lower()):
            return cid
    return None


async def _create_campaign_via_shira(db, topic: str) -> str:
    """Owner-console command: 'קמפיין <topic>' / 'campaign <topic>'.

    2026-08-15d (Digital Department merge audit): the ONLY existing path that
    could create a real campaign was the admin HTTP API
    (routes/campaigns.py POST /api/v1/campaigns, routes/admin.py), which calls
    SocialMediaManagerAgent.generate_campaign_plan() directly — bypassing
    MarketingAgent (SHIRA) and her real, tested, previously-orphaned
    delegate_to_social_campaign() entirely. The owner console had ZERO
    campaign-creation command at all (only approve/reject of ALREADY
    generated content). This is a genuine missing connection, not a
    cosmetic one: it's the one place SHIRA's real delegation method can run
    without touching the customer-facing safety boundary that deliberately
    keeps it unreachable from chat (see delegate_to_social_campaign's own
    docstring, BACKEND_AI_AGENTS.py).

    Why this is safe: this command only fires inside the owner's own
    authenticated WhatsApp console (never reachable by a customer). It does
    NOT bypass the SocialPost approval gate — delegate_to_social_campaign()
    -> NOA.execute_campaign() stores generated posts as
    status='pending_approval' (never publishes), so the existing *פוסטים*/
    *אשר*/*דחה* review flow is still the only way anything actually
    publishes. No approval gate is weakened.
    """
    topic = (topic or "").strip()
    if not topic:
        return ("כתוב נושא לקמפיין, למשל: *קמפיין בלמים לחורף*\n"
                "SHIRA תבנה תוכנית קמפיין, NOA תייצר תוכן, ותקבל אותו לאישור "
                "כמו כל פוסט אחר (*פוסטים*).")
    try:
        from BACKEND_AI_AGENTS import get_agent
        from social import registry as _reg
        platforms = _reg.configured_platforms() or ["facebook", "telegram"]
        shira = get_agent("marketing_agent")
        result = await shira.delegate_to_social_campaign(
            objective=topic, platforms=platforms, db=db,
        )
        campaign = result.get("campaign") or {}
        execution = result.get("execution") or {}
        cid = str(campaign.get("id") or "")
        queued = execution.get("posts_queued", 0)
        return (
            f"✅ SHIRA בנתה קמפיין: *{topic}*\n"
            f"🆔 {_short(cid)} · פלטפורמות: {', '.join(platforms)}\n"
            f"📝 NOA ייצרה {queued} פוסטים — ממתינים לאישורך.\n"
            f"לצפייה: כתוב *פוסטים*"
        )
    except Exception as exc:
        return f"⚠️ יצירת הקמפיין נכשלה: {str(exc)[:150]}"


async def _evaluate_campaign_via_shira(db, token: str) -> str:
    """Owner-console command: 'ביצועים [מזהה]' / 'performance [id]'.

    2026-08-15e (SHIRA-management acceptance audit): the real, missing
    connection in the SHIRA -> NOA -> Feedback -> SHIRA loop. Real
    engagement data was already collected (engagement_events) and already
    fed NOA's own topic weighting, but never reached a SHIRA-owned
    decision anywhere in the codebase. This command is the owner-facing
    entry point to MarketingAgent.evaluate_campaign_performance() — the one
    method that closes that loop, reusing the existing
    feedback_analyzer.generate_analytics_report() for real numbers and
    SHIRA's own persona for the resulting decision. Read-only against
    campaign content: it does not create, modify, approve, or publish
    anything — only evaluates and reports.
    """
    cid = await _resolve_campaign(db, token)
    if not cid:
        return "לא מצאתי קמפיין. צור אחד קודם עם *קמפיין [נושא]*."
    try:
        from BACKEND_AI_AGENTS import get_agent
        shira = get_agent("marketing_agent")
        result = await shira.evaluate_campaign_performance(cid, db)
        raw = result["raw_data"]
        return (
            f"📊 *ניתוח ביצועים — SHIRA* ({_short(cid)})\n"
            f"טווח הגעה: {raw['total_reach']} · מעורבות: {raw['total_engagement']} · "
            f"קליקים: {raw['total_clicks']} · לידים: {raw['total_leads']}\n\n"
            f"🎯 *החלטה:* {result['decision']}\n"
            f"💬 {result['reasoning']}"
        )
    except Exception as exc:
        return f"⚠️ ניתוח הביצועים נכשל: {str(exc)[:150]}"


async def _tiktok_auth_status(db) -> str:
    """Owner-console command: 'טוקן טיקטוק' / 'tiktok auth'.

    2026-08-16 (deep TikTok capability verification): the ONLY missing piece
    for real TikTok engagement collection is the owner's one-time consent
    click — the OAuth infrastructure (routes/webhooks.py's tiktok-oauth
    callback, already registered with TikTok's Developer Portal) and token
    persistence (tiktok_publisher.store_user_token, fixed this pass) are
    both real and wired. Reports current status honestly and, if not yet
    authorized, returns the exact real consent URL to open — never
    simulates or invents having done this step.
    """
    from social.tiktok_publisher import get_stored_user_token, get_authorize_url
    tok = await get_stored_user_token(db)
    if tok:
        return (
            f"✅ טיקטוק מאושר לניתוח ביצועים (open_id: {tok.get('open_id','?')[:12]}…)\n"
            f"scope: {tok.get('scope','')}\n"
            f"איסוף ביצועים אמיתי פעיל במחזור הבא."
        )
    url = get_authorize_url(state="owner_console")
    return (
        "⚠️ טיקטוק עדיין לא מאושר לאיסוף נתוני ביצועים (פרסום כן עובד — זה נפרד).\n"
        "כדי להפעיל, פתח את הקישור הזה ואשר בטיקטוק:\n"
        f"{url}\n\n"
        "לאחר האישור, המערכת תתחיל לאסוף צפיות/לייקים/תגובות אוטומטית."
    )


async def _approve_and_publish(db, post: Dict[str, Any]) -> str:
    """Mark approved + publish to each platform via the registry (same path the admin
    panel uses). Honest per-platform result back to the owner.

    2026-08-16 (operational readiness audit): this used to hand-roll its own
    UPDATE with approved_by=:who bound to the plain string "owner_whatsapp" —
    but social_posts.approved_by is a UUID column (unlike campaigns.created_by
    and group_targets.approved_by, which were migrated UUID->TEXT in
    0056_social_campaign_audit_columns.py for exactly this reason;
    social_posts was missed). Every real owner-console "אשר <id>" approval
    crashed with asyncpg.exceptions.DataError before ever reaching the
    publish step below — the human approval mechanism itself was broken.
    Fixed by reusing the EXISTING, already-correct
    campaign_manager.approve_post_content() (validates approved_by as a real
    UUID, falls back to a system placeholder UUID otherwise, also sets
    approved_at and guards status='pending_approval' so a second approval
    attempt is a safe no-op rather than a duplicate write) instead of
    reinventing the SQL.
    """
    from social.campaign_manager import approve_post_content
    pid = post["id"]
    was_approved = await approve_post_content(db, post_id=pid, approved_by="owner_whatsapp")
    if not was_approved:
        # approve_post_content only updates rows still in 'pending_approval' —
        # a False return means this post was already approved/published/rejected
        # since _resolve_post's list was fetched. Report the real state instead
        # of blindly re-dispatching to the live platforms (would double-publish).
        cur = (await db.execute(_sql("SELECT status FROM social_posts WHERE id=:id"), {"id": pid})).scalar()
        return f"⚠️ הפוסט ({_short(pid)}) כבר במצב '{cur}' — לא בוצע פרסום כפול."
    content = post["content"]
    platforms = post.get("platforms") or []
    # media/link best-effort from the app's meta helper (image-required platforms need it)
    media_url = link = None
    try:
        from BACKEND_API_ROUTES import _social_meta  # type: ignore
        res = await db.execute(_sql("SELECT * FROM social_posts WHERE id=:id"), {"id": pid})
        meta = _social_meta(res.fetchone())
        media_url = (meta or {}).get("media_url") or (meta or {}).get("image_url")
        link = (meta or {}).get("link") or (meta or {}).get("cta_url")
    except Exception:
        pass
    from social import registry
    hashtags = [f"#{m.group(1)}" for m in re.finditer(r"#([A-Za-z0-9_֐-׿؀-ۿ]+)", content)]
    results = []
    published = {}
    for p in platforms:
        p = str(p).strip().lower()
        # TikTok is exempt from the media-required skip: registry.dispatch()
        # auto-generates a branded product video when no media_url is given
        # (social/registry.py's "tiktok" branch) — it must never be skipped
        # for "media required" the way instagram genuinely must be. This
        # exception existed in the Telegram-callback webhook's OWN divergent
        # publish logic (routes/webhooks.py) before that logic was
        # consolidated into this function (2026-09-19, FIXES_TRACKER #28) —
        # ported here so unifying the two approval channels doesn't silently
        # regress TikTok's existing no-media capability.
        if p in registry.MEDIA_REQUIRED and not media_url and p != "tiktok":
            results.append(f"• {p}: ⏭️ דורש תמונה (אין מדיה)")
            continue
        if not registry.is_configured(p):
            results.append(f"• {p}: ⚠️ לא מוגדר")
            continue
        try:
            r = await registry.dispatch(p, content, media_url=media_url, hashtags=hashtags, link=link)
            if r.get("ok"):
                published[p] = r.get("id")
                results.append(f"• {p}: ✅ פורסם")
            else:
                results.append(f"• {p}: ❌ {str(r.get('error'))[:80]}")
        except Exception as e:
            results.append(f"• {p}: ❌ {str(e)[:80]}")
    if published:
        try:
            # JSONB MERGE (2026-08-16, operational-loop audit), not overwrite:
            # a plain `external_post_ids=:ext` destroyed the "__campaign_id__"
            # (and "__utm"/"__scheduled_at__") keys prepare_campaign_content()
            # sets at creation — silently orphaning campaign attribution for
            # every post approved through this, the REAL owner "אשר <id>"
            # command. social_posts.campaign_id (the FK column) was never
            # affected and is now the authoritative source
            # (feedback_analyzer._collect_facebook reads it directly), but
            # this merge also protects any other __-prefixed metadata from
            # the same class of loss going forward.
            await db.execute(_sql("""UPDATE social_posts SET status='published',
                                     published_at=NOW(),
                                     external_post_ids = external_post_ids || CAST(:ext AS jsonb),
                                     updated_at=NOW()
                                     WHERE id=:id"""),
                             {"ext": json.dumps(published), "id": pid})
            await db.commit()
        except Exception:
            await db.rollback()
    head = f"✅ אושר ופורסם ({_short(pid)}):" if published else f"אושר ({_short(pid)}) אך הפרסום נכשל:"
    return head + "\n" + "\n".join(results)


async def _reject_post(db, post: Dict[str, Any], reason: str = "") -> str:
    """2026-08-16: same approved_by/uuid defect as _approve_and_publish (this
    function bound the string "owner_whatsapp" to social_posts.approved_by,
    a UUID column) — every real owner-console "דחה <id>" also crashed. Fixed
    the same way: reuse the existing campaign_manager.reject_post_content()."""
    from social.campaign_manager import reject_post_content
    await reject_post_content(
        db, post_id=post["id"],
        reason=reason or "נדחה ע\"י הבעלים ב-WhatsApp",
        rejected_by="owner_whatsapp",
    )
    return f"🚫 הפוסט נדחה ({_short(post['id'])})."


# ── rolling conversation memory (Redis) ───────────────────────────────────────
async def _load_history() -> List[Dict[str, str]]:
    try:
        from BACKEND_AUTH_SECURITY import get_redis
        r = await get_redis()
        raw = await r.get(_HISTORY_KEY)
        return json.loads(raw) if raw else []
    except Exception:
        return []


async def _save_history(hist: List[Dict[str, str]]) -> None:
    try:
        from BACKEND_AUTH_SECURITY import get_redis
        r = await get_redis()
        await r.set(_HISTORY_KEY, json.dumps(hist[-_HISTORY_MAX:], ensure_ascii=False), ex=86400)
    except Exception:
        pass


# ── Sticky agent session (owner request 2026-08-04) ──────────────────────────
# The console used to route EVERY unprefixed message to AVI, so "@נועה ..." then a
# follow-up without the prefix was answered by AVI — "I call NOA and AVI answers".
# We now remember the active agent per owner in Redis: once you address an agent you
# STAY with them until you @-switch or type יציאה. Idle-expires so a stale session
# never traps you.
_ACTIVE_AGENT_KEY = "owner:console:active_agent"
_ACTIVE_AGENT_TTL_S = int(os.getenv("OWNER_ACTIVE_AGENT_TTL_S", "3600"))  # 60 min idle


async def _get_active_agent() -> "str | None":
    try:
        from BACKEND_AUTH_SECURITY import get_redis
        r = await get_redis()
        v = await r.get(_ACTIVE_AGENT_KEY)
        if v is None:
            return None
        return v.decode() if isinstance(v, (bytes, bytearray)) else str(v)
    except Exception:
        return None


async def _set_active_agent(agent_key: str) -> None:
    try:
        from BACKEND_AUTH_SECURITY import get_redis
        r = await get_redis()
        await r.set(_ACTIVE_AGENT_KEY, agent_key, ex=_ACTIVE_AGENT_TTL_S)
    except Exception:
        pass


async def _clear_active_agent() -> None:
    try:
        from BACKEND_AUTH_SECURITY import get_redis
        r = await get_redis()
        await r.delete(_ACTIVE_AGENT_KEY)
    except Exception:
        pass


# ── Updates group (system/agent updates → a dedicated WhatsApp group) ─────────
_UPDATES_GROUP_KEY = "owner:updates_group_jid"
_UPDATES_GROUP_LIST_KEY = "owner:updates_group_choices"  # index → jid, for "קבוצת עדכונים <n>"


async def _bridge_groups() -> list:
    """Fetch the WhatsApp groups this account is in, from the Baileys bridge."""
    import httpx
    base = os.getenv("WHATSAPP_BRIDGE_URL", "http://whatsapp-bridge:3001/send").rsplit("/", 1)[0]
    async with httpx.AsyncClient(timeout=15.0) as c:
        r = await c.get(f"{base}/groups")
        data = r.json()
    return data.get("groups", []) if data.get("ok") else []


async def _list_updates_groups() -> str:
    try:
        groups = await _bridge_groups()
    except Exception as e:
        return f"⚠️ לא הצלחתי לקרוא את רשימת הקבוצות מהגשר: {str(e)[:100]}"
    if not groups:
        return ("לא נמצאו קבוצות. צור קבוצת וואטסאפ (למשל \"AutoSpareFinder עדכונים\"), "
                "הוסף אליה את המספר של הפלטפורמה, ואז כתוב שוב *קבוצות*.")
    from BACKEND_AUTH_SECURITY import get_redis
    r = await get_redis()
    current = await r.get(_UPDATES_GROUP_KEY)
    current = (current.decode() if isinstance(current, (bytes, bytearray)) else current) or ""
    idx_map = {}
    lines = ["📋 *קבוצות וואטסאפ:*"]
    for i, g in enumerate(groups, 1):
        idx_map[str(i)] = g["jid"]
        mark = " ✅ (קבוצת העדכונים הנוכחית)" if g["jid"] == current else ""
        lines.append(f"{i}. {g.get('subject') or '(ללא שם)'} · {g.get('size', 0)} חברים{mark}")
    await r.set(_UPDATES_GROUP_LIST_KEY, json.dumps(idx_map), ex=1800)
    lines.append("\nלהגדרת קבוצת העדכונים: *קבוצת עדכונים <מספר>*")
    return "\n".join(lines)


async def _set_updates_group(arg: str) -> str:
    arg = (arg or "").strip()
    if not arg:
        return "כתוב *קבוצת עדכונים <מספר>* (מספר מהרשימה ב*קבוצות*)."
    from BACKEND_AUTH_SECURITY import get_redis
    r = await get_redis()
    jid = arg
    if "@" not in arg:  # an index from the last listing
        raw = await r.get(_UPDATES_GROUP_LIST_KEY)
        idx_map = json.loads(raw) if raw else {}
        jid = idx_map.get(arg, "")
        if not jid:
            return "מספר לא מוכר. כתוב *קבוצות* לרשימה מעודכנת ואז *קבוצת עדכונים <מספר>*."
    await r.set(_UPDATES_GROUP_KEY, jid)
    return (f"✅ עדכוני המערכת והסוכנים יישלחו מעכשיו לקבוצה הזו.\n"
            f"(השיחה איתך כאן נשארת לצ׳אט עם הסוכנים בלבד.)\n🆔 {jid}")


# ── 3 control-panel menus (owner request 2026-08-06) ──────────────────────────
# Every list here is DETERMINISTIC (a dict's insertion order / a sorted directory
# listing / a sorted dict of live tasks), so numbering needs no Redis round-trip —
# "משימה 7" always means the same task on every call, this session or the next.
from pathlib import Path as _Path

_BACKEND_ROOT = _Path(__file__).resolve().parent.parent  # /app
_HARVESTERS_DIR = _BACKEND_ROOT / "harvesters"
_IMPORTERS_DIR = _BACKEND_ROOT / "importers"


def _task_names() -> List[str]:
    import db_update_agent as _dua
    return [n for n in _dua.TASK_REGISTRY if n not in _dua.OOM_BLOCKED_TASKS]


def _harvester_names() -> List[str]:
    return sorted(p.stem for p in _HARVESTERS_DIR.glob("*.py") if not p.stem.startswith("_"))


def _importer_names() -> List[str]:
    return sorted(p.stem for p in _IMPORTERS_DIR.glob("*.py") if not p.stem.startswith("_"))




def _resolve_token(token: str, names: List[str]) -> "str | None":
    """token is either a 1-based index into `names`, or an exact/prefix name match."""
    token = (token or "").strip()
    if not token:
        return None
    if token.isdigit():
        i = int(token)
        return names[i - 1] if 1 <= i <= len(names) else None
    low = token.lower()
    for n in names:
        if n.lower() == low:
            return n
    hits = [n for n in names if n.lower().startswith(low)]
    return hits[0] if len(hits) == 1 else None


# ── Menu 1 — data-quality TASKS (db_update_agent.TASK_REGISTRY) ───────────────
def _menu_tasks_text() -> str:
    names = _task_names()
    lines = ["📋 *משימות איכות נתונים* (32):"]
    for i, n in enumerate(names, 1):
        lines.append(f"{i}. {n}")
    lines.append("\nלהרצת משימה בודדת: *הרץ משימה <מספר או שם>*")
    return "\n".join(lines)


async def _trigger_task(token: str) -> str:
    names = _task_names()
    name = _resolve_token(token, names)
    if not name:
        return "לא זיהיתי את המשימה. כתוב *משימות* לרשימה, ואז *הרץ משימה <מספר>*."
    import uuid as _uuid
    from datetime import datetime, timezone
    import db_update_agent as _dua
    from sqlalchemy import text as _sqla_text

    # Unique execution ID for THIS specific invocation — the post-condition verifier
    # checks for this exact ID so stale/prior job_registry rows cannot pass the gate.
    jid = f"owner_trigger:{name}:{_uuid.uuid4().hex[:16]}"
    call_started = datetime.now(timezone.utc)

    try:
        async with async_session_factory() as db:
            # Register the execution BEFORE running the task so the post-condition
            # read-back is tied to this invocation, not a prior cycle.
            try:
                await job_registry_start(db, name, ttl_seconds=660, job_id=jid)
            except Exception:
                pass  # DB write failure → read-back will return nothing → NOT_VERIFIED

            report = await asyncio.wait_for(_dua.run_task(name, db), timeout=600)

            status = report.get("status", "?")

            # Finish the registry row on success so the read-back can confirm it.
            if status == "ok":
                try:
                    await job_registry_finish(db, jid, status="completed")
                except Exception:
                    pass  # Handled: read-back will find nothing → NOT_VERIFIED
    except asyncio.TimeoutError:
        return f"⏳ *{name}* עדיין רצה אחרי 10 דקות — ממשיכה ברקע, בדוק *סטטוס* בהמשך."
    except Exception as exc:
        return f"❌ *{name}* נכשלה: {str(exc)[:200]}"

    icon = "✅" if status == "ok" else ("⏭️" if status == "skipped" else "❌")
    extra = ", ".join(
        f"{k}={v}" for k, v in report.items()
        if k not in ("task", "status", "error") and not isinstance(v, (list, dict))
    )
    msg = f"{icon} *{name}*: {status}"
    if extra:
        msg += f"\n{extra}"
    if report.get("error"):
        msg += f"\n⚠️ {str(report['error'])[:200]}"

    # Independent post-condition: for "ok" outcomes only (skipped/error are honest and
    # carry no success claim requiring verification).
    # Open a SEPARATE session so the read-back is a genuine DB round-trip, not an
    # in-memory view — this rules out silent commit failures.
    if status == "ok":
        verified = False
        try:
            async with async_session_factory() as verify_db:
                row = await verify_db.execute(
                    _sqla_text(
                        "SELECT 1 FROM job_registry "
                        "WHERE job_id = :jid AND status = 'completed' "
                        "AND completed_at >= :since"
                    ),
                    {"jid": jid, "since": call_started},
                )
                verified = row.fetchone() is not None
        except Exception:
            verified = False  # verifier exception → NOT_VERIFIED

        if verified:
            msg += "\n🔍 *[VERIFIED]* — הושלם ואומת בבסיס הנתונים."
        else:
            msg = (
                f"⚠️ *[NOT_VERIFIED]* — *{name}* דיווחה הצלחה "
                f"אך לא נמצא רשומת השלמה בבסיס הנתונים עבור הריצה הזו "
                f"(job_id={jid[:32]}…).\n"
                f"ייתכן שה-commit נכשל. בדוק: `docker logs autospare_backend`."
            )

    return msg


# ── Menu 2 — HARVESTERS + IMPORTERS ────────────────────────────────────────────
def _menu_harvesters_importers_text() -> str:
    hv, im = _harvester_names(), _importer_names()
    lines = [f"🌐 *שאיבות* ({len(hv)}):"]
    for i, n in enumerate(hv, 1):
        lines.append(f"h{i}. {n}")
    lines.append(f"\n📥 *ייבואים* ({len(im)}) — 10 ראשונים, כתוב *ייבואים הכל* לרשימה מלאה:")
    for i, n in enumerate(im[:10], 1):
        lines.append(f"i{i}. {n}")
    lines.append(
        "\nלהרצה: *הרץ שאיבה <h-מספר או שם>* / *הרץ ייבוא <i-מספר או שם>*"
    )
    return "\n".join(lines)


def _menu_importers_full_text() -> str:
    im = _importer_names()
    lines = [f"📥 *כל הייבואים* ({len(im)}):"]
    for i, n in enumerate(im, 1):
        lines.append(f"i{i}. {n}")
    lines.append("\nלהרצה: *הרץ ייבוא <i-מספר או שם>*")
    return "\n".join(lines)


def _strip_prefix(token: str, prefix: str) -> str:
    t = (token or "").strip()
    return t[len(prefix):] if t.lower().startswith(prefix) else t


async def _process_running(script_stem: str) -> bool:
    """True if a process for this exact script is already running (avoid piling up
    duplicate harvester/importer runs when the owner re-triggers impatiently)."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "pgrep", "-f", f"{script_stem}.py",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL,
        )
        out, _ = await proc.communicate()
        return bool(out.strip())
    except Exception:
        return False


async def _launch_script(subdir: str, script_stem: str) -> str:
    """Launch /app/<subdir>/<script_stem>.py in the background and VERIFY it started.

    Post-condition check: after a brief wait, pgrep confirms the process exists.
    Returns [VERIFIED] on confirmed start, [NOT_VERIFIED] if the post-condition
    is not met (process died immediately or pgrep failed).
    """
    if await _process_running(script_stem):
        return f"⏳ כבר רץ ברקע: *{script_stem}* — לא הפעלתי מופע כפול."
    script = str(_BACKEND_ROOT / subdir / f"{script_stem}.py")
    if not os.path.exists(script):
        return f"❌ לא נמצא הקובץ {subdir}/{script_stem}.py"
    try:
        import sys as _sys
        env = dict(os.environ)
        await asyncio.create_subprocess_exec(
            _sys.executable, script,
            stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL,
            env=env,
        )
        # Independent post-condition check: verify the process is actually running.
        # 1.5 s gives Python's interpreter enough time to start without being long
        # enough to mistake a fast-completing script for a launch failure.
        await asyncio.sleep(1.5)
        if not await _process_running(script_stem):
            return (
                f"⚠️ *[NOT_VERIFIED]* — ניסיתי להפעיל את *{script_stem}* "
                f"אך הוא לא נמצא בין התהליכים הרצים. "
                f"ייתכן שנכשל מיד. בדוק: `docker logs autospare_backend`."
            )
        return (
            f"🚀 *[VERIFIED]* — *{script_stem}* רץ ברקע (תהליך אומת). "
            f"מעקב: `docker logs autospare_backend`."
        )
    except Exception as exc:
        return f"❌ הפעלת {script_stem} נכשלה: {str(exc)[:200]}"


async def _trigger_harvester(token: str) -> str:
    names = _harvester_names()
    name = _resolve_token(_strip_prefix(token, "h"), names)
    if not name:
        return "לא זיהיתי את השאיבה. כתוב *שאיבות* לרשימה, ואז *הרץ שאיבה <h-מספר>*."
    return await _launch_script("harvesters", name)


async def _trigger_importer(token: str) -> str:
    names = _importer_names()
    name = _resolve_token(_strip_prefix(token, "i"), names)
    if not name:
        return "לא זיהיתי את הייבוא. כתוב *ייבואים הכל* לרשימה, ואז *הרץ ייבוא <i-מספר>*."
    return await _launch_script("importers", name)


# ── Menu 3 — AUTOMATED WORKERS (live status of every supervised background loop) ─
# Reuses routes/system.py's system_tasks() — the SAME live asyncio-task registry read
# already used by GET /api/v1/system/tasks — instead of re-deriving it, so the two
# never drift (2026-07-29 postmortem: log-grepping for "is it alive" was proven wrong
# for 19/29 loops; the registry read is the only correct source).
async def _menu_workers_text() -> str:
    from routes.system import system_tasks
    data = await system_tasks()
    if isinstance(data, dict) and "tasks" not in data:
        return "⚠️ לא הצלחתי לקרוא את מרשם העובדים כרגע."
    lines = [f"⚙️ *עובדים אוטומטיים* ({data['running']}/{data['total']} פעילים):"]
    icon = {"running": "🟢", "DEAD": "🔴", "cancelled": "⚪"}
    for i, t in enumerate(data["tasks"], 1):
        ln = f"{i}. {icon.get(t['state'], '❓')} {t['name']}"
        if t.get("error"):
            ln += f" — {str(t['error'])[:60]}"
        lines.append(ln)
    lines.append("\nאלו לולאות רקע קבועות (לא ניתן להריץ ידנית) — 🔴 = מתה, בדוק לוגים.")
    return "\n".join(lines)


_HELP = (
    "🎛️ *מרכז הבקרה שלך* (WhatsApp)\n\n"
    "*לפנות לסוכן — עם @:*\n"
    "• *@אבי <הודעה>* — AVI, מנהל/מתאם המערכת\n"
    "• *@שירה <הודעה>* — SHIRA, ראש המחלקה הדיגיטלית (אסטרטגיה, קמפיינים, SEO, PPC, CRO)\n"
    "• *@נועה <הודעה>* — NOA, שיווק וסושיאל (פוסטים, engagement)\n"
    "• *@Bone <הודעה>* — Bone, עוזר אישי כללי (חכם ומועיל; גם @בון / @בוני / @עוזר)\n"
    "אחרי שפנית לסוכן — *נשארים בשיחה איתו* וכל ההודעות הבאות אליו, "
    "בלי צורך ב-@ כל פעם. למעבר לסוכן אחר: *@<שם>*. ליציאה: *יציאה*.\n"
    "(בלי @ ובלי שיחה פעילה — פונה ל-AVI כברירת מחדל)\n\n"
    "*פקודות מהירות:*\n"
    "• *סטטוס* — סקירת מערכת חיה\n"
    "• *שאיבה* — התקדמות שאיבת הקטלוג\n"
    "• *הזמנות* — הזמנות אמיתיות פתוחות שאולי דורשות טיפול שלך\n"
    "• *מיילים* — מיילים שממתינים לך · *מייל [מזהה]* — פרטים וטיוטה\n"
    "• *שלחמייל [מזהה]* — שליחת הטיוטה (רק באישורך) · *סגורמייל [מזהה]* — טופל בלי לשלוח\n"
    "• *משימות מייל* · *סגורמשימה [מזהה]* — משימות שסוכן המיילים פתח לסוכנים\n"
    "• *משימות בועז* · *רכש* · *אשררכש [מזהה]* · *הוזמןידנית [מזהה] [אסמכתה]* · *אשרתשלוםספק [מזהה]*\n"
    "• *אשרפניותספקים* / *בטלפניותספקים* — הרשאה ל-NIR לפניות מידע לא מחייבות לספקים\n"
    "• *פוסטים* — פוסטים של NOA שממתינים לאישור\n"
    "• *אשר [מזהה]* / *דחה [מזהה]* — אשר/דחה פוסט\n"
    "• *קמפיין [נושא]* — SHIRA בונה קמפיין, NOA מייצרת תוכן לאישורך\n"
    "• *ביצועים [מזהה]* — SHIRA מנתחת נתוני ביצועים אמיתיים ומחליטה על צעד המשך\n"
    "• *טוקן טיקטוק* — מצב אישור טיקטוק לאיסוף ביצועים, ואם צריך — קישור לאישור\n"
    "• *תגובות* — תגובות ברשתות שממתינות לתשובה (NOA כבר ניסחה)\n"
    "• *ענה [מזהה]* / *דלג [מזהה]* — שלח את תשובת NOA / דלג\n"
    "• *הנחיות* — ההנחיות הקבועות שנתת ל-NOA\n"
    "• *ספקים* — ספקים חדשים ש-NIR מצא וממתינים לאישור\n"
    "• *מילים* — מילות סיווג שממתינות לאישורך, ברשימות ממוספרות · *מילים הבא* — הרשימה הבאה\n"
    "• *אשרהכל* / *דחההשאר* — לאשר את המילים ✅ ברשימה / לדחות את השאר · *אשרמילה 3 7* — לפי מספר\n"
    "• *מודל* — מצב מנוע הסיווג: אילו סוגי טקסט הוכיחו דיוק\n"
    "• *תור* — תור המשימות הכבדות: מה רץ, כמה נותר (נמדד מה-DB)\n"
    "• *עצור* / *המשך* — עצירה בטוחה של התור (בסוף המנה) והמשך\n"
    "• *מקורות* — NIR יחפש ספקים חדשים ברשת עכשיו\n"
    "• *אשרספק [מזהה]* / *דחהספק [מזהה]* — הפעל/דחה ספק\n"
    "• *גרופים* — קבוצות פייסבוק (ממתינות/מאושרות) · *אשרגרופ / דחהגרופ <מזהה>* — אשר/דחה קבוצה\n"
    "• *סרוק קבוצות* — NOA תגלה קבוצות + תנסח תגובות על פוסטים רלוונטיים\n"
    "• *תגובות-גרופ* — תגובות שנוסחו ממתינות לאישור · *אשרתגובה / דלגתגובה <מזהה>*\n"
    "• *מוכנות* — בדיקת מוכנות NOA למצב אוטונומי (בדיקה בלבד) · *מדדים* — מדדי הפעילות ב-24 שעות\n"
    "• *קבוצות* — הצג קבוצות וואטסאפ · *קבוצת עדכונים <מספר>* — "
    "הפנה את כל עדכוני המערכת/הסוכנים לקבוצה נפרדת (כדי שהצ׳אט כאן יישאר לשיחה בלבד)\n\n"
    "*3 תפריטי בקרה:*\n"
    "• *משימות ניקוי* — 32 משימות איכות נתונים · *הרץ משימה <מספר>* להרצה בודדת "
    "(שונה מ*תור* — זה תור המשימות הכבד)\n"
    "• *שאיבות* — שאיבות (harvesters) + ייבואים (importers) · *ייבואים הכל* לרשימה מלאה · "
    "*הרץ שאיבה <h-מספר>* / *הרץ ייבוא <i-מספר>* להפעלה\n"
    "• *עובדים* — סטטוס חי של כל לולאות הרקע האוטומטיות (🟢/🔴)\n\n"
    "• *עזרה* — התפריט הזה\n\n"
    "דוגמה: *@נועה תשמרי: 2 פוסטים ביום בשעות שיא, עם קריאה לפעולה* — "
    "וזה יישמר וייושם בפועל."
)


# ── agent chat (owner mode) ───────────────────────────────────────────────────
_AGENT_TOKENS = {
    "noa": "social_media_manager_agent", "נועה": "social_media_manager_agent",
    "avi": "router_agent", "אבי": "router_agent",
    # SHIRA — head of Digital Department (MarketingAgent). Wire into console so the
    # owner can talk directly to her about strategy, campaigns, and digital channels.
    # Root-wired 2026-08-11 per owner request: "shira is head of digital department,
    # wire to owner chat".
    "shira": "marketing_agent", "שירה": "marketing_agent",
    # Bone — a general-purpose owner assistant you can @-call (renamed from "עוזר" on
    # owner request 2026-08-04). Runs on the platform's own LLM — not the external dev
    # tool. The old aliases (עוזר/קלוד/assistant/claude) still resolve so nothing breaks.
    # Also added "בוני" — common diminutive the owner uses (was missing, causing @בוני
    # to fall through to AVI instead of Bone — root-fixed 2026-08-11).
    "bone": "assistant_agent", "בון": "assistant_agent", "בונ": "assistant_agent",
    "בוני": "assistant_agent",  # diminutive the owner actually types
    "claude": "assistant_agent", "קלוד": "assistant_agent",
    "assistant": "assistant_agent", "עוזר": "assistant_agent",
}

# Shared roster context so an agent doesn't hallucinate who the others are.
_ROSTER = (
    "\n\nצוות הסוכנים של AutoSpareFinder (לידיעתך — קונסול הבעלים): "
    "AVI (מתאם/מנהל מערכת), "
    "SHIRA (ראש המחלקה הדיגיטלית — אסטרטגיה, קמפיינים, SEO, CRO, B2B), "
    "NOA (שיווק וסושיאל — יצירת פוסטים, engagement, קבוצות), "
    "NIR (חלקים/התאמה/OEM), MAYA (מכירות/תמחור), LIOR (הזמנות), "
    "TAL (כספים/מע\"מ/חשבוניות), DANA (תמיכה/החזרות), OREN (אבטחה/הונאות), "
    "BOAZ (ספקים/סנכרון מחירים), REX (שאיבת קטלוג), Bone (עוזר אישי כללי).\n"
    "כשהסוכן הנוכחי מוזכר בהיסטוריה — ההודעות מסומנות [AVI]/[NOA]/[SHIRA]/[Bone] "
    "כדי שתוכל לקרוא מה כל סוכן אמר."
)


def _pick_agent(message: str) -> tuple[str, str, bool]:
    """Return (agent_key, stripped_message, explicit). Routing:
      • '@noa …' / '@נועה …' / '@avi …' / '@אבי …'  → that agent (explicit=True)
      • bare 'noa …' / 'avi …' prefix               → that agent (explicit=True)
      • anything else                               → AVI, the orchestrator (explicit=False)
    The '@' form is the clear way to call an agent (owner request 2026-07-25)."""
    m = message.strip()
    _toks = "|".join(re.escape(t) for t in sorted(_AGENT_TOKENS, key=len, reverse=True))
    mm = re.match(rf"^@\s*({_toks})\b[\s:,،.\-–]*", m, re.I)
    if not mm:
        mm = re.match(rf"^({_toks})\b[\s:,،.\-–]+", m, re.I)
    if mm:
        key = _AGENT_TOKENS[mm.group(1).lower()]
        rest = m[mm.end():].strip()
        return key, (rest or m), True
    return "router_agent", m, False


# NATURAL-LANGUAGE "connect/switch me to <agent>" intent (root-fixed 2026-08-12).
# Real bug found in production: the owner asked "מע עם שירה ונועה" (switch/connect with
# SHIRA and NOA) WITHOUT the @-prefix syntax. That fell through to AVI (the only agent
# without an explicit @-mention), and AVI HALLUCINATED a capability that doesn't exist —
# "I'll connect you to SHIRA and NOA... I'll forward the message, they'll answer soon" —
# TWICE, even after the owner explicitly said "I don't need you to forward it, I need them
# to answer me". There is no cross-agent message-relay mechanism; the ONLY way to reach
# another agent is the owner typing @agent themselves, which switches the sticky session.
# Real fix: detect this exact intent in plain language and DO the switch directly — the
# owner's request was clear, so make it work instead of teaching a new syntax or (worse)
# leaving AVI free to promise something impossible.
_CONNECT_INTENT_RE = re.compile(
    # מע(בר)? עם/ל — tolerates the owner's real-world typo'd shorthand ("מע עם שירה"
    # for "מעבר עם שירה"), which the first version of this regex missed entirely.
    r"(מע(בר)?\s*(ל|עם)|תחבר(י)?\s*אותי\s*(ל|עם)|תעביר(י)?\s*אותי\s*(ל|עם)|"
    r"רוצה\s*לדבר\s*עם|תדבר(י)?\s*עם|לחבר\s*אותי\s*(ל|עם)|"
    r"switch\s*(me\s*)?to|connect\s*me\s*(to|with)|talk\s*to)",
    re.I,
)


def _detect_connect_intent(message: str) -> "tuple[str, list[str]] | None":
    """If the message expresses 'connect/switch me to <agent(s)>' in plain language
    (no @-prefix), return (first_agent_key, [all_agent_names_mentioned]). None otherwise."""
    m = (message or "").strip()
    if not _CONNECT_INTENT_RE.search(m):
        return None
    _toks = "|".join(re.escape(t) for t in sorted(_AGENT_TOKENS, key=len, reverse=True))
    # optional leading "ו" (attached "and", no space — "ונועה" = "and-NOA"): same lesson as
    # the gendered-verb fix above — Hebrew attaches this conjunction directly to the word.
    mentions = re.findall(rf"(?<![א-תA-Za-z])ו?({_toks})(?![א-תA-Za-z])", m, re.I)
    if not mentions:
        return None
    seen: list[str] = []
    for name in mentions:
        low = name.lower()
        if low not in seen:
            seen.append(low)
    return _AGENT_TOKENS[seen[0]], seen


# ── NOA owner-guidelines (persisted so NOA's posting loop actually applies them) ──
_SAVE_INTENT = re.compile(
    r"תשמר|שמר[יי]?|נוהל|הנחי|מעכשיו|מעתה|תמיד תפרסמ|save|remember|guideline|from now",
    re.I)

# NATURAL-LANGUAGE requests for data the console HAS (#113, 2026-10-26). The owner asked
# "רשימת מילים לאישור" / "תבדוק מול המערכת איזה מילים מצריכות אישור" (23/10) and, replying to an
# orders alert, "תאמת את ההזמנות" (25/10). None is an exact command, so each fell to the chat LLM,
# which has no access to that data and answered "I don't have it" five times in a row — the
# capability existed one exact word away (*מילים*), and for orders it did not exist at all.
# Same rule as _CONNECT_INTENT_RE: when the request is clear, run the real command instead of
# letting an agent describe one. Narrow by design: a topic word AND an ask word must both appear,
# and the mapping never applies to an @agent message, a directive, or an approve/reject command.
_NL_TOPICS = (
    ("מילים", ("מילים", "מילות סיווג", "מילות מפתח", "מילה ", "keywords", "words")),
    ("פוסטים", ("פוסטים", "פוסט ", "posts")),
    ("הזמנות", ("הזמנות", "הזמנה", "orders", "order ")),
)
_NL_ASK = ("אישור", "לאשר", "ממתינ", "רשימ", "תבדוק", "בדוק", "תאמת", "לאמת", "אמת ", "מצריכ", "צריכ",
           "טיפול", "תקוע", "תראה", "הראה", "תציג", "איזה", "אילו", "מה המצב", "pending", "approve",
           "list", "check", "verify", "show")
_NL_SKIP_RE = re.compile(r"^\s*(אשר|דחה|ענה|דלג|approve|reject)", re.I)
_NL_CREATE_RE = re.compile(r"תכתב|תכינ|כתב[יו]|צר[יו] |תיצר|write|create|draft", re.I)


def _natural_command(message: str) -> "str | None":
    """The deterministic command a plain-language owner request maps to, or None."""
    m = (message or "").strip()
    if not m or _NL_SKIP_RE.match(m) or _SAVE_INTENT.search(m) or _CONNECT_INTENT_RE.search(m):
        return None
    if _pick_agent(m)[2]:
        return None
    low = m.lower() + " "
    if not any(a in low for a in _NL_ASK):
        return None
    for cmd, words in _NL_TOPICS:
        if any(w in low for w in words):
            if cmd == "פוסטים" and _NL_CREATE_RE.search(m):
                return None          # "write a post for approval" is work for NOA, not the pending list
            return cmd
    return None


async def _orders_attention() -> str:
    """Open orders (confirmed/paid/processing) that may need the owner, from the PII DB. Read-only.
    In production only REAL orders count (order_payment_policy, #111): a live-mode paid Stripe payment and
    a non-test customer; the rest are reported as a count, never as customer orders."""
    from datetime import datetime as _dt
    from sqlalchemy import select as _sel
    import order_payment_policy as _pol
    from BACKEND_DATABASE_MODELS import pii_session_factory as _psf, Order as _O, SupplierPayment as _SP
    open_st = ["confirmed", "paid", "processing"]
    try:
        async with _psf() as pdb:
            all_open = (await pdb.execute(_sel(_O).where(_O.status.in_(open_st))
                                          .order_by(_O.created_at))).scalars().all()
            if _pol.production_enforced():
                real_ids = set((await pdb.execute(_sel(_O.id).where(
                    _O.status.in_(open_st), _O.id.in_(_pol.live_paid_order_ids()),
                    ~_O.user_id.in_(_pol.test_customer_user_ids())))).scalars().all())
            else:
                real_ids = {o.id for o in all_open}
            real = [o for o in all_open if o.id in real_ids]
            sp: dict = {}
            if real:
                for oid, st in (await pdb.execute(_sel(_SP.order_id, _SP.status).where(
                        _SP.order_id.in_([o.id for o in real])))).all():
                    sp.setdefault(oid, []).append(st)
    except Exception as e:
        return f"⚠️ שגיאה בקריאת ההזמנות: {type(e).__name__}"
    other = len(all_open) - len(real)
    if not real:
        lines = ["📦 *הזמנות:* אין הזמנות אמיתיות פתוחות שדורשות טיפול. ✅"]
    else:
        lines = [f"📦 *הזמנות פתוחות ({len(real)}):*", ""]
        now = _dt.utcnow()
        for o in real[:15]:
            age_h = int(((now - o.created_at).total_seconds() if o.created_at else 0) // 3600)
            sup = ", ".join(sorted(set(sp.get(o.id, [])))) or "אין תשלום לספק עדיין"
            lines.append(f"• *{o.order_number}* · {o.status} · ₪{float(o.total_amount or 0):,.2f} · "
                         f"לפני {age_h} שע׳ · ספק: {sup}")
        if len(real) > 15:
            lines.append(f"…ועוד {len(real) - 15}")
    if other:
        lines.append(f"\n({other} הזמנות פתוחות נוספות הן הזמנות בדיקה / ללא תשלום חי — לא נספרות ולא מטופלות.)")
    return "\n".join(lines)


# ── AVI Execution Integrity Gate ─────────────────────────────────────────────
# The conversational LLM path (hf_text) is READ-ONLY. It has no tool-call
# capability: it generates text and returns it. Yet an LLM can emit first-
# person past-tense execution verbs ("הפעלתי", "I launched") implying it
# performed a real system action. That claim is ALWAYS false in this path.
#
# CLAUDE.md lesson: "An agent must never promise a SYSTEM ACTION that has no
# underlying mechanism." This gate enforces that mechanically so no prompt
# wording can override it.
#
# ONLY applies to the conversational hf_text() path. Deterministic command
# handlers (e.g. _trigger_task, _launch_script, _approve_and_publish) return
# their own ✅/❌ results BEFORE this code is reached, so those are unaffected.

_EXECUTION_CLAIM_RE = re.compile(
    # Hebrew first-person past-tense execution verbs (suffix -תי / -נו)
    # These mean "I did/ran/activated/completed/approved/etc."
    r'(?<![א-ת])'  # not the tail of a longer Hebrew word
    r'(?:'
    r'\bהפעלתי\b|\bביצעתי\b|\bהרצתי\b|\bהפסקתי\b|\bעצרתי\b|'
    r'\bאישרתי\b|\bפרסמתי\b|\bיצרתי\b|\bסיימתי\b|\bהשלמתי\b|'
    r'\bהתחלתי\s+ל(?:הריץ|הפעיל|בצע)\b|'
    r'\bהצלחתי\s+ל(?:הפעיל|הריץ|שלוח|לאשר|לבצע)\b|'
    # English first-person past-tense execution forms
    r'\bi\s+(?:have\s+)?(?:ran|run|executed|launched|started|triggered|'
    r'completed|finished|activated|stopped|published|approved|dispatched)\b'
    r')',
    re.I | re.UNICODE,
)

_NOT_VERIFIED_REPLY = (
    "⚠️ *[NOT_VERIFIED]* — לא ניתן לאמת ביצוע פעולה זו.\n"
    "שיחה חופשית עם AVI היא קריאה בלבד — לביצוע משימות, השתמש בפקודות:\n"
    "• *הרץ משימה <שם/מספר>* → הפעלת משימת עדכון/ניקוי\n"
    "• *הרץ שאיבה <שם/מספר>* → הפעלת שאיבה\n"
    "• *הרץ ייבוא <שם/מספר>* → הפעלת ייבוא\n"
    "• *אשר <מזהה>* → אישור פוסט ופרסום\n"
    "• *עזרה* → כל הפקודות הזמינות"
)


def _guard_avi_conversational_reply(reply: str) -> str:
    """Reject false execution claims from the conversational LLM path.

    The LLM (hf_text) can only generate text — it cannot call tools or mutate
    state. If it emits a first-person past-tense execution verb, that claim is
    false and is replaced with NOT_VERIFIED + command redirect.

    Returns the unmodified reply if no false claim is found.
    Returns _NOT_VERIFIED_REPLY if an execution claim is detected.
    """
    if _EXECUTION_CLAIM_RE.search(reply):
        return _NOT_VERIFIED_REPLY
    return reply


def _guidelines_text(raw) -> str:
    """AgentMemory.get double-decodes plain strings across processes, so we store the
    guidelines as a DICT {'text': …} (dicts round-trip correctly). Accept legacy string too."""
    if isinstance(raw, dict):
        return str(raw.get("text") or "")
    return str(raw or "")


async def _noa_guidelines_get(db) -> str:
    try:
        from agents.memory import AgentMemory, ensure_memory_table
        await ensure_memory_table(db)
        return _guidelines_text(await AgentMemory(db, agent_name="noa").get("owner_guidelines"))
    except Exception:
        return ""


async def _noa_guidelines_save(db, text: str) -> None:
    """Append a new owner directive to NOA's persisted guidelines (deduped, kept compact).
    NOA's marketing loop reads this same key and injects it into every generation."""
    try:
        from agents.memory import AgentMemory, ensure_memory_table
        await ensure_memory_table(db)
        mem = AgentMemory(db, agent_name="noa")
        try:
            cur = _guidelines_text(await mem.get("owner_guidelines"))
        except Exception:
            cur = ""   # corrupt/legacy value → start fresh (the dict form below round-trips)
        line = re.sub(r"\s+", " ", text).strip()
        if line and line not in cur:
            cur = (cur + "\n• " + line).strip()[-2000:]   # keep last ~2000 chars
        await mem.set("owner_guidelines", {"text": cur}, ttl_hours=24 * 365)  # dict → safe
    except Exception as e:
        print(f"[owner_console] guideline save failed: {e}")


# WhatsApp-facing reply rules shared by both agents. Two things ruined the earlier replies:
# (1) the fallback LLM dumped its chain-of-thought ("1. Analyze the Request… 5. Constructing
#     the Final Output") instead of the answer; (2) markdown **bold** doesn't render in
# WhatsApp (bold is a single *). These rules + the post-processor below fix both.
_WA_REPLY_RULES = (
    "\n\nכללי מענה מחייבים (וואטסאפ):\n"
    "• ענה בעברית בלבד, קצר וישיר — עד ~6 שורות. בלי הקדמות ובלי סיכומים מיותרים.\n"
    "• תן אך ורק את התשובה הסופית. אסור בהחלט להראות שלבי חשיבה/ניתוח/תכנון "
    "(אסור 'Analyze', 'Draft', 'Step', '1. …', 'Internal Monologue', רשימת שלבים).\n"
    "• עיצוב וואטסאפ: הדגשה עם כוכבית *בודדת* בלבד — לעולם לא **. בלי כותרות markdown (#).\n"
    "• השתמש בנתוני המערכת החיים למטה; אל תמציא מספרים.\n"
    "• *אסור להמציא קישורים.* הקישור היחיד המותר הוא https://autosparefinder.co.il "
    "(או קישור שנמסר לך במפורש). לעולם אל תמציא נתיב כמו /oil-filters-corolla — "
    "הוא לא קיים והלקוח יגיע לעמוד שגוי.\n"
    "• *אסור להמציא מבצעים, הנחות, קופונים או תוכניות נאמנות.* אין קופונים פעילים. "
    "אם אין מבצע אמיתי — אל תרמוז שיש.\n"
    "• אם צריך פעולה מובנית — הפנה לפקודה: סטטוס / שאיבה / פוסטים / אשר / דחה.\n"
    "• *אסור להבטיח 'אעביר הודעה לסוכן אחר' / 'אקשר אותך ל...' / 'הם יענו בקרוב'* — "
    "אין מנגנון להעברת הודעות בין סוכנים. הדרך היחידה לדבר עם סוכן אחר היא שחליל עצמו "
    "יכתוב @שם-הסוכן (למשל @שירה, @נועה) — זה מחליף מי עונה לו מיד, באותה שיחה. "
    "אם חליל מבקש לדבר עם סוכן אחר, אמור לו בפשטות לכתוב @שם-הסוכן — אל תבטיח שתעביר בעצמך.\n"
    "• *אל תניח — תבדוק לפני שאתה עונה.* כל עובדה שאתה נותן לחליל (מספר, סטטוס, "
    "האם משהו מחובר/רץ/עובד) חייבת להגיע מנתוני המערכת החיים שסופקו לך בשיחה הזו, "
    "לא מזיכרון של 'מה שבדרך כלל נכון'. אם אין לך את הנתון האמיתי — תגיד את זה "
    "בפשטות והצע לבדוק (למשל: 'סטטוס' / 'שאיבה'), אל תמלא את הפער בניחוש שנשמע סביר."
)

# Human voice — the "way NOA talks" applied to EVERY console agent (owner request
# 2026-08-04: AVI and Bone should talk like humans, not bots). Warmth + a light wit,
# never templated. Kept SEPARATE from the compliance rules above so the personality is
# explicit. The role stays each agent's own (AVI=ops, Bone=general help, NOA=marketing) —
# this only changes the TONE.
_HUMAN_VOICE = (
    "\n\nאיך לדבר (חובה — כמו בן אדם, לא כמו בוט):\n"
    "• דבר עם חליל כמו חבר-צוות אנושי: עברית מדוברת וזורמת, גוף ראשון, משפטים קצרים.\n"
    "• קצת אישיות: קריצה חכמה או הערה קלילה כשמתאים — בלי להגזים, בלי ליצנות, בלי בדיחות דחוקות.\n"
    "• פנה אליו בשמו לפעמים ('חליל, …'). אמוג'י — 1 עד 2 לכל היותר, רק כשזה מוסיף.\n"
    "• בלי ניסוחים תבניתיים ('אני כאן כדי לעזור', 'שאלה מצוינת', 'להלן'), בלי חזרתיות, "
    "בלי אותו פתיח כל פעם. תשובה אחת — טבעית וישירה — לא ניתוח.\n"
    "• תישאר מדויק: אם אתה לא בטוח, אמור זאת בפשטות במקום להמציא."
)

# When the owner ISSUES AN INSTRUCTION (rather than asking for output), the reply must
# be an acknowledgement of what will change — not a freshly generated artefact.
# Without this NOA answered "from now on always put a real price in every post" by
# writing a post, which is what reads as bot-like: it responded to the topic instead of
# to the intent. (owner, 2026-07-29: "act like agents not like bots")
_DIRECTIVE_NOTE = (
    "\n\n--- שים לב: ההודעה הזו היא הוראה/נוהל, לא בקשה לתוכן ---\n"
    "הבעלים נותן לך הנחיה קבועה. אשר בקצרה שקלטת, ונסח במשפט אחד מה ישתנה בפועל מעכשיו. "
    "אל תייצר פוסט, אל תבקש ממנו מידע שכבר יש לך במערכת, ואל תשאל שאלה מיותרת."
)
_OWNER_SYSTEM = {
    "router_agent": (
        "אתה AVI — המתאם הראשי של AutoSpareFinder, מדבר עם *חליל, הבעלים* (לא לקוח). "
        "תפקידך: לתת לו תמונת מצב מדויקת של המערכת, המלצות תפעוליות, ולנתב משימות. "
        "היה ישיר, מקצועי ומועיל — אבל אנושי, לא יבש. אל תמכור לו ואל תתייחס אליו כלקוח. "
        "כשהוא מזכיר סוכן ספציפי בשם — אשר שאתה יכול להעביר אליו, אבל אל תדמה להיות אותו סוכן. "
        "כשאתה קורא היסטוריה — ההודעות מסומנות [NOA]/[SHIRA]/[Bone] כדי שתדע מי אמר מה."
        + _ROSTER + _WA_REPLY_RULES + _HUMAN_VOICE
    ),
    "social_media_manager_agent": (
        "את NOA — מנהלת הסושיאל של AutoSpareFinder, מדברת עם *חליל, הבעלים*. "
        "כשהוא מבקש פוסט — כתבי את הפוסט המוכן לפרסום בלבד (פתיח קולע, גוף קצר, וקריאה "
        "לפעולה), אנושי וחכם, בלי להסביר את התהליך. כשהוא שואל על שיווק — תני תשובה ממוקדת. "
        "כשהוא נותן לך *הוראה* — אשרי מה נקלט ומה ישתנה, אל תכתבי פוסט. "
        "אל תמציאי מחירים או נתונים. "
        "הקריאה לפעולה בפוסט היא תמיד חיפוש לפי מספר רישוי באתר — לא נתיב מוצר מומצא, "
        "ולא מבצע/הנחה שלא קיימים. "
        "לאישור/דחיית פוסטים ממתינים: 'פוסטים' ואז 'אשר'/'דחה'. "
        "כשאתה קורא היסטוריה — ההודעות מסומנות [AVI]/[SHIRA]/[Bone] כדי שתדעי מי אמר מה."
        + _ROSTER + _WA_REPLY_RULES + _HUMAN_VOICE
    ),
    "assistant_agent": (
        "אתה *Bone* — העוזר האישי של חליל, הבעלים של AutoSpareFinder (הוא קורא לך Bone, "
        "בון, בוני, או עוזר). אתה עוזר כללי, חכם ומועיל — עונה על כל שאלה, מסביר, מתכנן, ונותן "
        "עצה טכנית ועסקית על המערכת והעסק. יש לך גישה למצב המערכת החי למטה. אתה עוזר "
        "תפעולי, לא סוכן שירות לקוחות ולא מוכר. אם צריך פעולה מובנית — הפנה לפקודה. "
        "CRITICAL: אסור לך להעביר משימות לסוכנים אחרים (NOA, SHIRA וכו') — אתה עונה ישירות. "
        "אם השאלה מחוץ לתחומך — אמור זאת בפשטות ותמליץ לחליל לפנות ל-@שירה / @נועה / @אבי. "
        "כשאתה קורא היסטוריה — ההודעות מסומנות [AVI]/[NOA]/[SHIRA] כדי שתדע מי אמר מה."
        + _ROSTER + _WA_REPLY_RULES + _HUMAN_VOICE
    ),
    # SHIRA — head of Digital Department, wired into owner console 2026-08-11.
    # Strategic peer: discusses marketing strategy, digital campaigns, department
    # OKRs, budget, ROI, channel mix, SEO/PPC/CRO, B2B leads. NOT a content generator
    # (NOA does that). NOT a customer-facing agent. Speaks directly to Khalil as a
    # CMO-level colleague who also has eyes on the live system data.
    "marketing_agent": (
        "את *SHIRA* — ראש המחלקה הדיגיטלית של AutoSpareFinder, מדברת עם *חליל, הבעלים*. "
        "תפקידך: אסטרטגיית שיווק דיגיטלי — קמפיינים, SEO, PPC, CRO, B2B לידים, "
        "ניתוח ביצועים, תקציב ו-ROI. אתה המנהל הדיגיטלי שלו, לא מוכרת ולא בוטית. "
        "NOA היא הזרוע הביצועית שלך לסושיאל — את מנחה אותה ואחראית על האסטרטגיה. "
        "כשהוא שואל על שיווק — תני ניתוח ממוקד עם המלצה ברורה. "
        "כשהוא נותן הוראה — אשרי מה ייעשה ועל ידי מי. "
        "אל תמציאי נתוני ROI, מכירות, או תנועה — השתמשי רק במה שיש במצב המערכת החי. "
        "כשאתה קורא היסטוריה — ההודעות מסומנות [AVI]/[NOA]/[Bone] כדי שתדעי מי אמר מה."
        + _ROSTER + _WA_REPLY_RULES + _HUMAN_VOICE
    ),
}
_AGENT_TAG = {
    "social_media_manager_agent": "NOA",
    "assistant_agent": "Bone",
    "router_agent": "AVI",
    "marketing_agent": "SHIRA",
}


def _clean_wa_reply(text: str) -> str:
    """Post-process an agent reply for WhatsApp: strip any leaked chain-of-thought, and
    convert markdown the app can't render. Belt-and-braces on top of the prompt rules —
    the fallback model in particular still leaks a numbered 'analysis' when Cerebras 429s."""
    t = (text or "").strip()
    # 1) strip leaked reasoning via the shared customer-flow stripper
    try:
        from BACKEND_AI_AGENTS import _strip_leaked_reasoning
        t = _strip_leaked_reasoning(t) or t
    except Exception:
        pass
    # 2) targeted salvage: if it's still a numbered "analysis dump" (…Constructing the Final
    #    Output / Final Output / Final Response), keep only what comes AFTER that heading
    #    (consuming any trailing markdown/colon/dashes so no "**:" junk remains).
    looks_like_cot = bool(re.search(
        r"(?im)^\s*\d+\.\s|Analyze the Request|Internal Monologue|Drafting the Post|"
        r"Refining the Post|Constructing the Final", t))
    if looks_like_cot:
        m = None
        for mm in re.finditer(r"(?:Constructing the Final Output|Final Output|Final Response|"
                              r"התוצר הסופי|הפוסט הסופי|התשובה הסופית)[\s*:\-.]*", t, re.I):
            m = mm  # take the LAST such marker
        if m:
            t = t[m.end():].strip()
        else:
            # no explicit "final" marker — drop obvious analysis lines, keep the rest
            t = "\n".join(ln for ln in t.splitlines() if not re.match(
                r"\s*(?:\d+\.\s*)?\*{0,2}(?:Analyze|Draft|Refin|Construct|Present|Step|User|"
                r"Request|Role|Tone|Context|Topic|Target|Format|Headline|Body|CTA)\b", ln, re.I)).strip()
    # 3) markdown → WhatsApp: **bold** → *bold*, drop markdown headers/list-star noise
    t = re.sub(r"\*\*+([^*\n]+?)\*\*+", r"*\1*", t)
    t = re.sub(r"(?m)^\s{0,3}#{1,6}\s*", "", t)
    # 4) INVENTED LINKS. NOA produced `https://autosparefinder.co.il/oil-filters-corolla`
    #    — a route that does not exist. A prompt rule alone does not hold under a
    #    fallback model, and an owner who forwards that link sends a customer to a 404,
    #    so the deep path is collapsed to the site root here as well. Only genuinely
    #    routed prefixes survive (checkout, admin, the QR channel picker, search).
    t = re.sub(
        r"(https?://(?:www\.)?autosparefinder\.co\.il)/(?!(?:pay/|admin\b|api/v1/go\b|search\b))"
        r"[^\s)\],.]*",
        r"\1", t)
    t = re.sub(r"\n{3,}", "\n\n", t).strip()
    return t


async def _engagement_inbox(db) -> str:
    """List social comments/DMs NOA has drafted a reply for, awaiting owner approval."""
    from social import engagement as _eng
    try:
        await _eng.ensure_inbox_table(db)
        pend = await _eng.pending_for_owner(db)
    except Exception as e:
        return f"⚠️ שגיאה בקריאת התגובות: {str(e)[:120]}"
    if not pend:
        cfg = _eng.configured_platforms()
        if not cfg:
            return ("אין ערוץ חברתי מחובר לקריאת תגובות עדיין (חסר FACEBOOK_PAGE_TOKEN). "
                    "ברגע שיחובר טוקן, NOA תתחיל לקרוא ולנסח תשובות אוטומטית.")
        return "אין תגובות שממתינות לתשובה כרגע. ✅"
    lines = ["💬 *תגובות ממתינות לתשובתך:*"]
    for p in pend:
        who = p.get("author") or "לקוח"
        msg = (p.get("message") or "")[:90]
        draft = (p.get("reply_text") or "")[:140]
        returning = "⭐ " if p.get("is_returning_engager") else ""
        lines.append(f"\n🆔 {_short(p['id'])} · {p['platform']} · {returning}{who}\n"
                     f"   💬 {msg}\n   ✍️ טיוטת NOA: {draft}")
    lines.append("\nלשליחה: *ענה <מזהה>* (או *ענה <מזהה> טקסט משלך*) · לדילוג: *דלג <מזהה>*")
    return "\n".join(lines)


async def _engagement_reply(db, token: str, override: str = "") -> str:
    """Approve+send NOA's drafted reply (or the owner's own text) to a social comment."""
    from social import engagement as _eng
    item = await _eng.resolve_inbox(db, token)
    if not item:
        return "לא מצאתי תגובה ממתינה. כתוב *תגובות* לרשימה."
    text = (override or item.get("reply_text") or "").strip()
    if not text:
        return "אין טקסט לשליחה. כתוב *ענה <מזהה> הטקסט שלך*."
    from social import noa_ops
    res = await noa_ops.send_page_reply(db, item, text, actor="owner")
    if not res.get("ok"):
        return f"⚠️ שליחה נכשלה: {str(res.get('error'))[:140]}"
    return f"✅ נשלחה תשובה ב-{item['platform']} ({_short(item['id'])})."


async def _engagement_skip(db, token: str) -> str:
    from social import engagement as _eng
    item = await _eng.resolve_inbox(db, token)
    if not item:
        return "לא מצאתי תגובה ממתינה. כתוב *תגובות* לרשימה."
    await _eng.mark_skipped(db, item["id"])
    return f"⏭️ דילגתי על התגובה {_short(item['id'])}."


# ── NIR supplier sourcing (discover sellers → onboard → owner approves) ────────

# ── Category keyword learning (LLM assist) — owner approval gate ─────────────
# One keyword can move thousands of parts ('bolt' matches 16,541), so a token the
# LLM proposed does not go live until the owner approves it here.


async def _embed_phase_report() -> str:
    """Phase-1/2 scorecard: which input types have earned auto-write."""
    from catalog_scraper import scraper_session_factory
    import embed_policy as ep
    import category_input_type as cit
    try:
        async with scraper_session_factory() as db:
            card = await ep.type_scorecard(db)
    except Exception as e:
        return f"⚠️ שגיאה: {str(e)[:120]}"

    lines = ["🧠 *מצב מנוע הסיווג (AI מקומי):*", "", ep.describe_phase(), ""]
    if not card:
        lines.append("עדיין לא נאספו הצעות מהמודל. ההיסטוריה תתחיל להיבנות בסבב הקרוב.")
        lines.append("")
        lines.append(f"תנאי מעבר לשלב 2: לפחות {ep.MIN_DECISIONS} החלטות שלך לכל סוג, "
                     f"ואישור של {ep.MIN_APPROVAL_RATE:.0%} לפחות.")
        return "\n".join(lines)

    lines.append("*לפי סוג טקסט:*")
    for ty, d in sorted(card.items(), key=lambda kv: -(kv[1]["decisions"])):
        rate = f"{d['approval_rate']:.0%}" if d["approval_rate"] is not None else "—"
        mark = "✅ מוכן לשלב 2" if d["meets_bar"] else (
            "⏳ אוסף היסטוריה" if d["eligible"] else "🚫 לא מורשה לכתיבה")
        lines.append(
            f"• *{ty}* — אושרו {d['approved']} · נדחו {d['rejected']} · "
            f"ממתינים {d['pending']}\n   ↳ אחוז אישור {rate} · {mark}")
    lines.append("")
    lines.append(f"תנאי מעבר: ≥{ep.MIN_DECISIONS} החלטות ו-≥{ep.MIN_APPROVAL_RATE:.0%} אישור.")
    lines.append("כרגע: המודל *מציע חוקים בלבד* — שום חלק לא משתנה בלי אישורך (*מילים*).")
    return "\n".join(lines)


# ── learned keywords: the whole backlog in numbered batches (#114) ──────────────────────────────────────
# Owner 2026-10-27: "message all the words till we finish them" (~2,600 waiting). The list showed the same top-15
# forever, one word per command. Now every batch is the next words NOT YET SHOWN, numbered, with batch actions; the
# daily message sends the next batch until every waiting word was shown, then starts a new pass over what is left.
# Each batch has an id so a reply to an older message acts on the words THAT message showed, never on newer ones.
_KW_CUR_KEY = "autospare:owner:kw_batch:current"   # id of the batch shown last
_KW_BATCH_KEY = "autospare:owner:kw_batch:{}"       # JSON list of tokens: what the numbers of batch {id} mean
_KW_SHOWN_KEY = "autospare:owner:kw_shown"          # set: tokens already shown in this pass over the backlog
_KW_TTL_S = 30 * 86400


def _kw_batch_size() -> int:
    try:
        return max(5, min(80, int(os.getenv("OWNER_KEYWORD_BATCH", "40"))))
    except ValueError:
        return 40


def _kw_pick(waiting: list, shown: set, current: list, size: int, advance: bool):
    """(batch, new_pass). Pure. Without `advance` the current batch stays while any of its words still waits
    (its numbers keep their meaning). Otherwise: the next `size` waiting words not shown in this pass; once every
    waiting word was shown, a new pass from the top."""
    wset = set(waiting)
    if not advance and any(t in wset for t in current):
        return list(current), False
    fresh = [t for t in waiting if t not in shown and t not in current]
    if fresh:
        return fresh[:size], False
    return list(waiting[:size]), True


async def _kw_redis():
    try:
        from BACKEND_AUTH_SECURITY import get_redis
        return await get_redis()
    except Exception:
        return None


async def _kw_load_batch(r, batch_id=None):
    """(id, tokens) of the given batch, or of the current one. (None, []) when there is none."""
    if r is None:
        return None, []
    try:
        bid = int(batch_id) if batch_id is not None else int(await r.get(_KW_CUR_KEY) or 0)
        raw = await r.get(_KW_BATCH_KEY.format(bid)) if bid else None
        return (bid, json.loads(raw)) if raw else (None, [])
    except Exception:
        return None, []


async def _kw_waiting():
    from catalog_scraper import scraper_session_factory
    import category_learning as cl
    async with scraper_session_factory() as db:
        return await cl.pending_for_owner(db, limit=20000)


async def _keywords_list(advance: bool = False) -> str:
    from catalog_scraper import scraper_session_factory
    import category_learning as cl
    try:
        pend = await _kw_waiting()
    except Exception as e:
        return f"⚠️ שגיאה בקריאת המילים: {str(e)[:120]}"
    if not pend:
        return ("אין מילות־קטלוג חדשות שממתינות לאישור. ✅\n"
                "המערכת לומדת מילים חדשות רק כשהיא נתקעת על חלק שהיא לא מזהה.")
    by_tok = {p["token"]: p for p in pend}
    waiting = [p["token"] for p in pend]                      # most votes first
    r = await _kw_redis()
    cur_id, current = await _kw_load_batch(r)
    shown = set()
    if r is not None:
        try:
            shown = set(await r.smembers(_KW_SHOWN_KEY))
        except Exception:
            shown = set()
    batch, new_pass = _kw_pick(waiting, shown, current, _kw_batch_size(), advance)
    bid = cur_id if (batch == current and cur_id) else None
    if r is not None and bid is None:
        try:
            bid = int(await r.incr(_KW_CUR_KEY + ":seq"))
            await r.set(_KW_BATCH_KEY.format(bid), json.dumps(batch, ensure_ascii=False), ex=_KW_TTL_S)
            await r.set(_KW_CUR_KEY, bid, ex=_KW_TTL_S)
            if new_pass:
                await r.delete(_KW_SHOWN_KEY)
                shown = set()
            await r.sadd(_KW_SHOWN_KEY, *batch)
            await r.expire(_KW_SHOWN_KEY, _KW_TTL_S)
        except Exception:
            bid = None
    shown |= set(batch)
    # The EVIDENCE next to each word: agreement among votes measures consistency, not correctness
    # (קופסת→gearbox was 98% and wrong). evidence_profile reads parts ALREADY filed in a real category, and it is
    # the same check approve() enforces — ✅ is exactly "approvable without force".
    verdicts = {}
    try:
        async with scraper_session_factory() as db:
            for t in batch:
                if t in by_tok:
                    try:
                        verdicts[t] = await cl.evidence_profile(db, t, proposed=by_tok[t]["category"])
                    except Exception:
                        verdicts[t] = None
    except Exception:
        pass
    open_n = sum(1 for t in batch if t in by_tok)
    ok_n = sum(1 for t in batch if (verdicts.get(t) or {}).get("verdict") == "ok")
    label = f"רשימה {bid}" if bid else "רשימה"
    lines = [f"🔤 *מילות סיווג לאישורך — {label}* ({open_n} כאן · {len(pend):,} ממתינות בסך הכול)", ""]
    for i, t in enumerate(batch, 1):
        if t not in by_tok:
            continue                                          # decided since it was shown: numbers keep meaning
        he = cl.category_map.display_name(by_tok[t]["category"], "he")
        p = verdicts.get(t) or {}
        v = p.get("verdict")
        if v == "ok":
            mark = "✅"
        elif v == "category_mismatch":
            top = cl.category_map.display_name(p["top"], "he") if p.get("top") else "?"
            mark = f"⚠️ לפי הקטלוג: {top}"
        elif v == "ambiguous":
            mark = "⚠️ כללית מדי"
        elif v == "insufficient_evidence":
            mark = "❔ אין מספיק נתונים"
        else:
            mark = ""
        lines.append(f"{i}. *{t}* → {he} {mark}".rstrip())
    left = sum(1 for t in waiting if t not in shown)
    n = f" {bid}" if bid else ""
    lines += ["",
              f"*אשרהכל{n}* — מאשר את {ok_n} המילים המסומנות ✅ ברשימה הזו",
              f"*דחההשאר{n}* — דוחה כל מילה שנשארה ברשימה הזו (לא תוצע שוב) ושולח את הבאות",
              "*אשרמילה 3 7* / *דחהמילה 5* — לפי מספר · *אשרמילה 4 בכוח* — לאשר מילה עם ⚠️/❔",
              "*מילים הבא* — לרשימה הבאה בלי להחליט",
              f"מילה מאושרת מסווגת את *כל* החלקים שמכילים אותה. עוד לא הוצגו: {left:,}"]
    if r is None:
        lines.append("⚠️ Redis לא זמין: פקודות לפי מספר ופקודות לרשימה לא יעבדו כרגע — השתמש בשם המילה.")
    return "\n".join(lines)


_KW_BULK_RE = re.compile(r"^(אשר ?הכל|approve ?all|דחה ?השאר|reject ?rest)(?:\s+(\d+))?\s*$", re.I)
_KW_INDEX_RE = re.compile(r"^[\d\s,]+$")


async def _kw_bulk(approve: bool, batch_id=None) -> str:
    """Approve every ✅ word, or reject every word still waiting, of ONE shown batch. The evidence gate is not
    bypassed: approve() refuses whatever is not ✅, and those words stay for the owner to decide."""
    from catalog_scraper import scraper_session_factory
    import category_learning as cl
    r = await _kw_redis()
    bid, batch = await _kw_load_batch(r, batch_id)
    if not batch:
        return "אין רשימה כזו. כתוב *מילים* כדי לקבל רשימה."
    try:
        waiting = {p["token"] for p in await _kw_waiting()}
        todo = [t for t in batch if t in waiting]
        if not todo:
            return f"כל המילים ברשימה {bid} כבר הוכרעו. כתוב *מילים* לרשימה הבאה."
        async with scraper_session_factory() as db:
            for t in todo:
                await (cl.approve(db, t) if approve else cl.reject(db, t))
            # report the STORED outcome, not the call results (#72)
            rows = (await db.execute(_sql(
                "SELECT token, bool_or(status = 'approved'), bool_and(status = 'rejected') "
                "FROM category_learned_keywords WHERE token = ANY(:t) GROUP BY token"), {"t": todo})).fetchall()
    except Exception as e:
        return f"⚠️ שגיאה: {str(e)[:120]}"
    approved = [t for t, a, _ in rows if a]
    rejected = [t for t, _, rj in rows if rj]
    if approve:
        rest = [t for t in todo if t not in approved]
        out = [f"✅ רשימה {bid}: אושרו {len(approved)}" + (f" — {', '.join(approved)}" if approved else "")]
        if rest:
            out.append(f"נשארו {len(rest)} שהקטלוג לא תומך בהן. *דחההשאר {bid}* לדחות אותן, "
                       "או *אשרמילה <מספר> בכוח* למילה שאתה בטוח בה.")
        return "\n".join(out)
    failed = [t for t in todo if t not in rejected]
    head = f"🚫 רשימה {bid}: נדחו {len(rejected)} — {', '.join(rejected)}"
    if failed:
        head += f"\n⚠️ לא נדחו ({len(failed)}): {', '.join(failed)} — בדוק."
    return head + "\n\n" + await _keywords_list(advance=True)


async def _kw_by_index(arg: str, approve: bool, force: bool) -> str:
    """`אשרמילה 3 7` / `דחהמילה 5`: numbers of the batch shown last. A single word with a digit is never a
    learned keyword (category_learning.is_blocked), so a numbers-only argument cannot name a real token."""
    r = await _kw_redis()
    bid, batch = await _kw_load_batch(r)
    if not batch:
        return "אין רשימה פעילה למספרים. כתוב *מילים* לקבלת רשימה, או כתוב את המילה עצמה."
    nums = [int(x) for x in re.findall(r"\d+", arg)]
    bad = [n for n in nums if not 1 <= n <= len(batch)]
    if bad or not nums:
        return f"מספר לא קיים ברשימה {bid}: {', '.join(map(str, bad)) or arg}. ברשימה יש 1–{len(batch)}."
    replies = []
    for n in dict.fromkeys(nums):
        t = batch[n - 1]
        replies.append(f"{n}. " + (await _keyword_approve(t, force=force) if approve else await _keyword_reject(t)))
    return "\n".join(replies)


_KW_FORCE_RE = re.compile(r"\s+(בכוח|force|בכל מקרה)$", re.I)


def _keyword_args(rest: str):
    """(keyword, force, full_text) from the text after the command; whitespace collapsed."""
    full = " ".join((rest or "").split())
    m = _KW_FORCE_RE.search(full)
    if m:
        return full[:m.start()], True, full
    return full, False, full


async def _not_found_reply(cl, db, token: str, verb: str) -> str:
    sim = await cl.similar_tokens(db, token)
    hint = ("\nאולי התכוונת ל: " + ", ".join(f"*{t}*" for t in sim)) if sim else ""
    return f"לא מצאתי מילה בשם *{cl.norm_token(token)}* — לא {verb} דבר.{hint}\nכתוב *מילים* לרשימה."


async def _keyword_approve(token: str, force: bool = False, full: str = None) -> str:
    from catalog_scraper import scraper_session_factory
    import category_learning as cl
    if not token:
        return "צריך מילה. כתוב *מילים* לרשימה."
    try:
        async with scraper_session_factory() as db:
            if force and full and await cl.token_exists(db, full):
                token, force = full, False          # "<…> בכוח" is itself a stored token
            if not await cl.token_exists(db, token):
                return await _not_found_reply(cl, db, token, "אושר")
            res = await cl.approve(db, token, force=force)
            stored = (await db.execute(_sql(
                "SELECT status FROM category_learned_keywords WHERE token = :t AND category = :c"),
                {"t": res.get("token"), "c": res.get("category")})).scalar() if res.get("ok") else None
    except Exception as e:
        return f"⚠️ שגיאה: {str(e)[:120]}"
    if res.get("ok") and stored != "approved":         # report the STORED outcome (#72)
        return f"⚠️ *{res['token']}*: האישור לא נשמר (מצב במסד: {stored}) — בדוק."
    if not res.get("ok"):
        if res.get("error") == "blocklisted":
            return (f"❌ *{token}* חסומה לצמיתות (שם יצרן / בורג / מיקום) "
                    "ולא תיהפך לכלל סיווג.")
        # The evidence gate refused. Show WHY, with the real numbers, and offer
        # the override — the owner has domain knowledge the catalogue does not.
        ev = res.get("evidence") or {}
        if res.get("error") in ("category_mismatch", "ambiguous", "insufficient_evidence"):
            top_he = (cl.category_map.display_name(ev.get("top"), "he")
                      if ev.get("top") else "—")
            spread = " · ".join(f"{c}:{n:,}" for c, n in (ev.get("spread") or [])[:3])
            why = {
                "category_mismatch": f"נתוני האמת מצביעים על *{top_he}*, לא על מה שהוצע",
                "ambiguous": f"מילה כללית מדי — פי {ev.get('margin')} בלבד מהקטגוריה השנייה",
                "insufficient_evidence": "אין מספיק חלקים מסווגים כדי להחליט",
            }[res["error"]]
            return (f"⛔ *{token}* לא אושרה — {why}.\n"
                    f"פילוח אמיתי: {spread}\n"
                    f"אם את/ה בטוח/ה בכל זאת: *אשרמילה {token} בכוח*")
        return f"לא מצאתי מילה ממתינה בשם *{token}*. כתוב *מילים* לרשימה."
    he = cl.category_map.display_name(res["category"], "he")
    return (f"✅ *{res['token']}* אושרה → {he}.\n"
            "הכלל פעיל עכשיו, וכל החלקים שמכילים את המילה יסווגו בסבב הקרוב.")


async def _keyword_reject(token: str) -> str:
    from catalog_scraper import scraper_session_factory
    import category_learning as cl
    if not token:
        return "צריך מילה. כתוב *מילים* לרשימה."
    try:
        async with scraper_session_factory() as db:
            if not await cl.token_exists(db, token):
                return await _not_found_reply(cl, db, token, "נדחה")
            res = await cl.reject(db, token)
            persisted = (await db.execute(_sql(
                "SELECT count(*) FILTER (WHERE status <> 'rejected') FROM category_learned_keywords WHERE token = :t"),
                {"t": res.get("token")})).scalar() if res.get("ok") else None
    except Exception as e:
        return f"⚠️ שגיאה: {str(e)[:120]}"
    if not res.get("ok"):
        return f"לא מצאתי מילה בשם *{res.get('token')}*."
    if persisted:                                   # report the STORED outcome, not the parse (#72)
        return f"⚠️ *{res['token']}*: {persisted} רשומות לא עודכנו לדחייה — בדוק."
    return f"🚫 *{res['token']}* נדחתה — לא תיטען ולא תוצע שוב."


async def _sourcing_list() -> str:
    from services import supplier_sourcing as ss
    pending = await ss.list_pending()
    if not pending:
        return "אין ספקים חדשים שממתינים לאישור. כתוב *מקורות* כדי ש-NIR יחפש ספקים ברשת."
    cred = [p for p in pending if p.get("status") == "pending_credentials"]
    rev = [p for p in pending if p.get("status") != "pending_credentials"]
    lines = ["🔌 *ספקים שממתינים לאישור (NIR):*"]
    if rev:
        lines.append("\n*מוכנים להפעלה:*")
        for p in rev[:10]:
            lines.append(f"🆔 {p['id'][:8]} · {p['name'][:30]} · {p.get('website','')} · ציון {p['reliability_score']}")
    if cred:
        lines.append("\n*ממתינים לפרטי חשבון/טוקן ממך:*")
        for p in cred[:10]:
            lines.append(f"🆔 {p['id'][:8]} · {p['name'][:30]}\n   ↳ {(p.get('needs') or '')[:150]}")
    lines.append("\nלהפעלה: *אשרספק <מזהה>* · לדחייה: *דחהספק <מזהה>*")
    return "\n".join(lines)


async def _sourcing_run() -> str:
    from services import supplier_sourcing as ss
    res = await ss.run_sourcing_cycle()
    ob = res.get("onboarded", [])
    head = f"🔎 NIR סרק את הרשת ({len(res.get('queries',[]))} חיפושים): נמצאו {res.get('discovered',0)} מועמדים, צורפו {len(ob)} חדשים לאישור."
    if ob:
        head += "\n" + "\n".join(f"• {o['name'][:34]} ({o['domain']}) ציון {o['score']}" for o in ob[:8])
    head += "\n\nכתוב *ספקים* לרשימה ואישור."
    return head


async def _sourcing_approve(token: str) -> str:
    from services import supplier_sourcing as ss
    if not token:
        return "ציין מזהה ספק: *אשרספק <מזהה>*"
    r = await ss.approve_supplier(token)
    if r.get("ok"):
        try:                                   # NIR -> BOAZ handoff: onboarding prerequisites (never fatal)
            import boaz_tasks as _bt
            await _bt.file_supplier_handoff(r["supplier_id"], r["name"], "owner_whatsapp")
        except Exception:
            pass
    if not r.get("ok"):
        return {"short": "כתוב לפחות 4 תווים של מזהה הספק.",
                "ambiguous": "המזהה מתאים ליותר מספק אחד — כתוב עוד תווים."}.get(
            r.get("error"), "לא מצאתי ספק ממתין עם המזהה הזה. כתוב *ספקים* לרשימה.")
    q = r.get("qualification")
    warn = "" if q in (None, "integration_ready") else f"\n⚠️ סטטוס בדיקה: {q} — לא כל הדרישות אומתו."
    ds = r.get("dropshipping")
    if ds and ds != "DROPSHIPPING-READY":
        warn += f"\n⚠️ דרופשיפינג: {ds} — לא תישלח הזמנה ישירות ללקוח עד שזה יאומת."
    return (f"✅ הופעל הספק *{r['name']}* — יופיע בהשוואת המחירים ברגע שיהיו לו מחירים.{warn}\n"
            "ההפעלה לא מאשרת פנייה מסחרית, הזמנה או תשלום לספק.")


async def _sourcing_reject(token: str) -> str:
    from services import supplier_sourcing as ss
    if not token:
        return "ציין מזהה ספק: *דחהספק <מזהה>*"
    r = await ss.reject_supplier(token)
    if not r.get("ok"):
        return {"short": "כתוב לפחות 4 תווים של מזהה הספק.",
                "ambiguous": "המזהה מתאים ליותר מספק אחד — כתוב עוד תווים."}.get(
            r.get("error"), "לא מצאתי ספק ממתין (לא פעיל) עם המזהה הזה. כתוב *ספקים* לרשימה.")
    return f"🗑️ נדחה הספק *{r['name']}*."


async def _fb_groups_list(db) -> str:
    import sqlalchemy as sa
    res = await db.execute(sa.text("""
        SELECT id::text, group_name, group_url, status, posts_sent
        FROM group_targets WHERE platform='facebook'
        ORDER BY status='approved' DESC, created_at DESC
    """))
    rows = res.fetchall()
    if not rows:
        return "אין קבוצות פייסבוק עדיין. כתוב *סרוק קבוצות* כדי שנגלה את הקבוצות שלך."
    lines = ["📋 *קבוצות פייסבוק:*", ""]
    approved = [r for r in rows if r[3] == "approved"]
    pending = [r for r in rows if r[3] == "pending"]
    if approved:
        lines.append("✅ *מאושרות (פעילות):*")
        for r in approved:
            lines.append(f"🆔 {r[0][:8]} · {r[1][:35]} · פוסטים: {r[4]}")
    if pending:
        lines.append("\n⏳ *ממתינות לאישורך:*")
        for r in pending[:12]:
            lines.append(f"🆔 {r[0][:8]} · {r[1][:40]}")
    lines.append("\nלאישור: *אשרגרופ <מזהה>* · לדחייה: *דחהגרופ <מזהה>*")
    lines.append("לסריקה + ניסוח תגובות: *סרוק קבוצות*")
    return "\n".join(lines)


async def _fb_group_approve(db, token: str) -> str:
    import sqlalchemy as sa
    if not token:
        return "ציין מזהה קבוצה: *אשרגרופ <מזהה>*"
    res = await db.execute(sa.text("""
        SELECT id::text, group_name, group_url FROM group_targets
        WHERE platform='facebook' AND status='pending'
          AND (id::text LIKE :tok OR id::text = :full)
        LIMIT 1
    """), {"tok": f"{token}%", "full": token})
    row = res.fetchone()
    if not row:
        return "לא מצאתי קבוצה ממתינה עם המזהה הזה. כתוב *גרופים* לרשימה."
    gid, name, url = row
    # Enforce partial-unique index: cannot approve if already an approved row for same URL
    try:
        await db.execute(sa.text("""
            UPDATE group_targets SET status='approved' WHERE id=CAST(:id AS uuid)
        """), {"id": gid})
        await db.commit()
    except Exception as exc:
        await db.rollback()
        if "uq_group_targets_platform_url_approved" in str(exc):
            return f"⚠️ יש כבר קבוצה מאושרת עם אותה כתובת ({url[:60]}). לא ניתן לאשר כפילות."
        return f"⚠️ שגיאה: {str(exc)[:120]}"
    return f"✅ הקבוצה *{name}* אושרה — תיכלל בסריקה הבאה.\nכתוב *סרוק קבוצות* להרצה מיידית."


async def _fb_group_reject(db, token: str) -> str:
    import sqlalchemy as sa
    if not token:
        return "ציין מזהה קבוצה: *דחהגרופ <מזהה>*"
    res = await db.execute(sa.text("""
        SELECT id::text, group_name FROM group_targets
        WHERE platform='facebook'
          AND (id::text LIKE :tok OR id::text = :full)
        LIMIT 1
    """), {"tok": f"{token}%", "full": token})
    row = res.fetchone()
    if not row:
        return "לא מצאתי קבוצה עם המזהה הזה."
    await db.execute(sa.text("DELETE FROM group_targets WHERE id=CAST(:id AS uuid)"), {"id": row[0]})
    await db.commit()
    return f"🗑️ הקבוצה *{row[1]}* נמחקה."


async def _fb_comment_drafts_list(db, page: int = 1) -> str:
    """Pending group-comment drafts, best relevance first, GROUP_DRAFT_PAGE_SIZE per page.
    Read-only: paging changes only what is shown, never any draft's status."""
    import sqlalchemy as sa
    from social.noa_ops import GROUP_DRAFT_PAGE_SIZE as _PS
    total = (await db.execute(sa.text(
        "SELECT COUNT(*) FROM group_comment_drafts WHERE status='pending_approval'"))).scalar() or 0
    if not total:
        return "אין תגובות ממתינות לאישור. כתוב *סרוק קבוצות* כדי לנסח תגובות חדשות."
    pages = (total + _PS - 1) // _PS
    page = max(1, min(int(page or 1), pages))
    res = await db.execute(sa.text("""
        SELECT d.id::text, t.group_name, d.post_text, d.draft_comment, d.relevance_score
        FROM group_comment_drafts d
        JOIN group_targets t ON t.id = d.group_target_id
        WHERE d.status='pending_approval'
        ORDER BY d.relevance_score DESC, d.created_at DESC, d.id
        LIMIT :n OFFSET :o
    """), {"n": _PS, "o": (page - 1) * _PS})
    rows = res.fetchall()
    first = (page - 1) * _PS + 1
    lines = [f"✍️ *תגובות שנוסחו ע\"י NOA — ממתינות לאישורך:*",
             f"עמוד {page}/{pages} · מציג {first}–{first + len(rows) - 1} מתוך {total}", ""]
    for r in rows:
        did, gname, post, draft, score = r
        lines.append(f"🆔 {did[:8]} [{gname[:25]}] ציון {score:.2f}")
        lines.append(f"   📝 *פוסט:* {post[:80]}...")
        lines.append(f"   💬 *תגובה:* {draft[:120]}")
        lines.append("")
    if page < pages:
        lines.append(f"לעמוד הבא: *תגובות-גרופ {page + 1}*")
    lines.append("לאישור ושליחה: *אשרתגובה <מזהה>* · לדילוג: *דלגתגובה <מזהה>*")
    return "\n".join(lines)


async def _fb_comment_approve(db, token: str) -> str:
    """Owner approval of a group comment draft. Uses the SAME claim+post path as autonomous mode
    (social/noa_ops.py); only the recorded actor differs. Outcome is audited and reported back."""
    if not token:
        return "ציין מזהה: *אשרתגובה <מזהה>*"
    from social import noa_ops
    claimed = await noa_ops.claim_group_draft(db, token, actor="owner")
    if not claimed:
        return "לא מצאתי תגובה ממתינה עם המזהה הזה. כתוב *תגובות-גרופ* לרשימה."

    async def _post_comment():
        try:
            await noa_ops.post_claimed_group_draft(claimed, actor="owner")
        except Exception as exc:
            log.error("_fb_comment_approve background post failed: %s", exc)
    import asyncio as _aio
    _aio.create_task(_post_comment())
    return f"✅ אישרת את התגובה — NOA שולחת אותה עכשיו ל-Facebook (תקבל הודעה עם התוצאה).\n\n💬 _{claimed['draft'][:150]}_"


async def _fb_comment_skip(db, token: str) -> str:
    import sqlalchemy as sa
    if not token:
        return "ציין מזהה: *דלגתגובה <מזהה>*"
    res = await db.execute(sa.text("""
        SELECT id::text FROM group_comment_drafts
        WHERE status='pending_approval'
          AND (id::text LIKE :tok OR id::text = :full)
        LIMIT 1
    """), {"tok": f"{token}%", "full": token})
    row = res.fetchone()
    if not row:
        return "לא מצאתי תגובה ממתינה."
    await db.execute(sa.text(
        "UPDATE group_comment_drafts SET status='skipped', skipped_at=NOW() WHERE id=CAST(:id AS uuid)"
    ), {"id": row[0]})
    await db.commit()
    return "⏭️ דילגתי על התגובה."


async def _fb_scan_groups_trigger() -> str:
    """Fire group_scanner pipeline in background, return immediate ack."""
    async def _run():
        try:
            from social.facebook_browser.group_scanner import run_group_scanner
            await run_group_scanner()
        except Exception as exc:
            log.error("owner_console: fb_scan_groups_trigger error: %s", exc)
    import asyncio as _aio
    _aio.create_task(_run())
    return (
        "🔍 מתחיל לסרוק את הקבוצות שלך בפייסבוק...\n\n"
        "שלב 1 — גילוי קבוצות מהחשבון\n"
        "שלב 2 — סריקת פוסטים בקבוצות מאושרות\n"
        "שלב 3 — ניסוח תגובות (NOA)\n\n"
        "אשלח לך סיכום בסיום (כ-2-5 דקות). תוכל להמשיך לעבוד."
    )


async def process_owner_message(message: str, source: str = "whatsapp") -> str:
    """Entry point for owner WhatsApp messages. Returns the reply text.

    Opens its own CATALOG-DB session (harvest_queue / parts_catalog / job_registry /
    social_posts all live in the catalog DB — NOT the PII DB the webhook hands us)."""
    from BACKEND_DATABASE_MODELS import async_session_factory
    async with async_session_factory() as db:
        return await _process_owner_message(message, db, source)


async def _process_owner_message(message: str, db, source: str = "whatsapp") -> str:
    msg = (message or "").strip()
    low = msg.lower()

    # ── leave the current agent session → back to neutral console ─────────────
    if low in ("יציאה", "צא", "exit", "quit", "סיום", "חזרה", "back"):
        prev = await _get_active_agent()
        await _clear_active_agent()
        if prev:
            tag = _AGENT_TAG.get(prev, "AVI")
            return f"✅ יצאת משיחה עם *{tag}*. חזרת למרכז הבקרה.\nכתוב *עזרה* לתפריט או *@נועה* / *@אבי* לפנייה לסוכן."
        return _HELP

    # ── plain-language request for data the console has → the real command (#113) ──
    _nl_cmd = _natural_command(msg)
    if _nl_cmd:
        msg, low = _nl_cmd, _nl_cmd

    # ── deterministic commands ────────────────────────────────────────────────
    if low in ("help", "menu", "עזרה", "תפריט", "?", "start", "היי", "hi"):
        await _clear_active_agent()   # opening the menu leaves any agent session
        return _HELP
    if low in ("status", "סטטוס", "review", "סקירה", "מצב"):
        return "📊 *סטטוס מערכת*\n" + await build_status_snapshot(db)
    if low in ("harvester", "שאיבה", "קטלוג", "harvest"):
        snap = await build_status_snapshot(db, brief=True)
        return snap or "אין נתוני שאיבה כרגע."
    if low in ("orders", "הזמנות", "הזמנה"):
        return await _orders_attention()
    # Email Agent commands (מיילים / מייל / שלחמייל / סגורמייל / משימות מייל / סגורמשימה) - 2026-10-27
    try:
        from agents import email_console as _email_console
        _mail_reply = await _email_console.handle(msg)
    except Exception as _mail_exc:
        _mail_reply = f"⚠️ פקודת מייל נכשלה: {str(_mail_exc)[:160]}"
    if _mail_reply is not None:
        return _mail_reply
    # BOAZ / procurement / NIR outreach approvals (רכש / אשררכש / אשרתשלוםספק / משימות בועז ...) - 2026-10-27
    try:
        from agents import supplier_console as _supplier_console
        _sup_reply = await _supplier_console.handle(msg)
    except Exception as _sup_exc:
        _sup_reply = f"⚠️ פקודת ספקים/רכש נכשלה: {str(_sup_exc)[:160]}"
    if _sup_reply is not None:
        return _sup_reply
    if low in ("posts", "פוסטים", "פוסט"):
        pend = await _list_pending_posts(db)
        if not pend:
            return "אין פוסטים שממתינים לאישור. ✅"
        lines = ["📝 *פוסטים ממתינים לאישור:*"]
        for p in pend:
            first = (p["content"].splitlines() or [""])[0][:70]
            lines.append(f"🆔 {_short(p['id'])} [{', '.join(p['platforms'])}]\n   {first}")
        lines.append("\nלאישור: *אשר <מזהה>* · לדחייה: *דחה <מזהה>*")
        return "\n".join(lines)
    # keyword batches (#114) — BEFORE the post commands: "אשר הכל" would otherwise be read as post id "הכל"
    m_kwb = _KW_BULK_RE.match(msg)
    if m_kwb:
        return await _kw_bulk(m_kwb.group(1).lower().replace(" ", "") in ("אשרהכל", "approveall"), m_kwb.group(2))
    if low in ("מילים הבא", "מילים הבאות", "words next", "next words"):
        return await _keywords_list(advance=True)
    m_ap = re.match(r"^(approve|אשר)\b\s*(\S+)?", msg, re.I)
    if m_ap:
        post = await _resolve_post(db, m_ap.group(2) or "")
        if not post:
            return "לא מצאתי פוסט ממתין לאישור. כתוב *פוסטים* לרשימה."
        return await _approve_and_publish(db, post)
    m_rj = re.match(r"^(reject|דחה)\b\s*(\S+)?", msg, re.I)
    if m_rj:
        post = await _resolve_post(db, m_rj.group(2) or "")
        if not post:
            return "לא מצאתי פוסט ממתין. כתוב *פוסטים* לרשימה."
        return await _reject_post(db, post)
    m_camp = re.match(r"^(campaign|קמפיין)\b\s*(.*)$", msg, re.I | re.S)
    if m_camp:
        return await _create_campaign_via_shira(db, (m_camp.group(2) or "").strip())
    m_perf = re.match(r"^(performance|ביצועים)\b\s*(\S+)?", msg, re.I)
    if m_perf:
        return await _evaluate_campaign_via_shira(db, m_perf.group(2) or "")
    if low in ("טוקן טיקטוק", "tiktok auth", "tiktok token", "אישור טיקטוק"):
        return await _tiktok_auth_status(db)
    if low in ("הנחיות", "guidelines", "נהלים", "כללים"):
        g = await _noa_guidelines_get(db)
        return ("📋 *הנחיות NOA (נשמרות ומיושמות):*\n" + g) if g else \
            "אין הנחיות שמורות ל-NOA עדיין. כתוב לה למשל: @נועה תשמרי: 2 פוסטים ביום בשעות שיא."

    # ── NOA social engagement inbox (read + reply to comments/DMs) ────────────
    if low in ("inbox", "תגובות", "תגובה", "comments", "engagement"):
        return await _engagement_inbox(db)
    m_rep = re.match(r"^(reply|ענה|תעני|ענו)\b\s*(\S+)?\s*(.*)?$", msg, re.I | re.S)
    if m_rep:
        return await _engagement_reply(db, m_rep.group(2) or "", (m_rep.group(3) or "").strip())
    m_skip = re.match(r"^(skip|דלג|דלגי)\b\s*(\S+)?", msg, re.I)
    if m_skip:
        return await _engagement_skip(db, m_skip.group(2) or "")

    # ── NIR supplier sourcing (discover sellers on the web → onboard → approve) ─
    m_aps = re.match(r"^(approve[\-_ ]?supplier|אשרספק|אשר ספק)\b\s*(\S+)?", msg, re.I)
    if m_aps:
        return await _sourcing_approve(m_aps.group(2) or "")
    m_rjs = re.match(r"^(reject[\-_ ]?supplier|דחהספק|דחה ספק)\b\s*(\S+)?", msg, re.I)
    if m_rjs:
        return await _sourcing_reject(m_rjs.group(2) or "")
    # ── category keyword learning (approve/reject what the LLM taught) ────────
    # The keyword is the WHOLE rest of the line (#72): `(\S+)` took only the first word, so
    # "דחהמילה brake pad" acted on the different token "brake". A trailing בכוח/force is the
    # evidence-gate override — unless the full text is itself a stored token.
    m_kwa = re.match(r"^(approve[\-_ ]?word|אשרמילה|אשר מילה)(?=\s|$)", msg, re.I)
    if m_kwa:
        _kw_arg, _force, _full = _keyword_args(msg[m_kwa.end():])
        if _kw_arg and _KW_INDEX_RE.match(_kw_arg):
            return await _kw_by_index(_kw_arg, approve=True, force=_force)
        return await _keyword_approve(_kw_arg, force=_force, full=_full)
    m_kwr = re.match(r"^(reject[\-_ ]?word|דחהמילה|דחה מילה)(?=\s|$)", msg, re.I)
    if m_kwr:
        _kw_rarg = " ".join(msg[m_kwr.end():].split())
        if _kw_rarg and _KW_INDEX_RE.match(_kw_rarg):
            return await _kw_by_index(_kw_rarg, approve=False, force=False)
        return await _keyword_reject(_kw_rarg)
    if low in ("ai", "מנוע", "מודל", "embed", "שלב"):
        return await _embed_phase_report()
    if low in ("words", "מילים", "מילה", "keywords", "מילות מפתח"):
        return await _keywords_list()

    # ── job queue: observe, stop, resume ─────────────────────────────────────
    if low in ("queue", "תור", "משימות", "jobs", "pipeline"):
        import job_queue as _jq
        # live=True measures the running step RIGHT NOW (~10-20s) instead of
        # reporting a periodic figure that can be hours old. The owner asked for
        # status; handing back a stale number without saying so is worse than
        # taking twenty seconds.
        return _jq.render_status(await _jq.status(db, live=True))
    if low in ("עצור", "stop", "עצירה"):
        import job_queue as _jq
        ok = await _jq.request_stop(True)
        return ("🛑 בקשת עצירה נשלחה — התור ייעצר בסוף המנה הנוכחית "
                "(לא באמצע כתיבה). להמשך: *המשך*." if ok else
                "⚠️ לא הצלחתי לרשום את בקשת העצירה (Redis לא זמין).")
    if low in ("המשך", "resume", "continue"):
        import job_queue as _jq
        await _jq.request_stop(False)
        return "▶️ בקשת העצירה בוטלה — התור ימשיך מהמקום שבו עצר."

    # ── updates group: list groups / set which one receives system updates ────
    if low in ("groups", "קבוצות", "קבוצה"):
        return await _list_updates_groups()
    m_ug = re.match(r"^(קבוצת עדכונים|updates group|עדכונים לקבוצה)\s*(\S+)?", msg, re.I)
    if m_ug:
        return await _set_updates_group(m_ug.group(2) or "")

    # ── 3 control-panel menus (owner request 2026-08-06) ───────────────────────
    # NOTE: bare "משימות" is already claimed above (job-QUEUE status, a different
    # concept — the heavy background pipeline, not this data-cleaning TASK REGISTRY).
    # Use a distinct multi-word phrase here so the two never collide.
    if low in ("משימות ניקוי", "רשימת משימות", "tasks", "task list"):
        return _menu_tasks_text()
    m_rt = re.match(r"^(הרץ משימה|run task)\s+(\S+)", msg, re.I)
    if m_rt:
        return await _trigger_task(m_rt.group(2))

    if low in ("שאיבות", "harvesters", "שאיבות וייבוא", "importers"):
        return _menu_harvesters_importers_text()
    if low in ("ייבואים הכל", "importers all", "כל הייבואים"):
        return _menu_importers_full_text()
    m_rh = re.match(r"^(הרץ שאיבה|run harvester)\s+(\S+)", msg, re.I)
    if m_rh:
        return await _trigger_harvester(m_rh.group(2))
    m_ri = re.match(r"^(הרץ ייבוא|run importer)\s+(\S+)", msg, re.I)
    if m_ri:
        return await _trigger_importer(m_ri.group(2))

    if low in ("עובדים", "workers", "עובדים אוטומטיים"):
        return await _menu_workers_text()

    if low in ("suppliers", "ספקים", "מקורות ספקים"):
        return await _sourcing_list()
    if low in ("discover", "מקורות", "sourcing", "חפש ספקים"):
        return await _sourcing_run()

    # ── Facebook group targets (approve groups → scan → draft comments) ────────
    if low in ("גרופים", "fb-groups", "fb groups", "קבוצות פייסבוק", "קבוצות-fb"):
        return await _fb_groups_list(db)
    m_ag = re.match(r"^(approve[\-_ ]?group|אשרגרופ|אשר גרופ)\b\s*(\S+)?", msg, re.I)
    if m_ag:
        return await _fb_group_approve(db, m_ag.group(2) or "")
    m_rg = re.match(r"^(reject[\-_ ]?group|דחהגרופ|דחה גרופ)\b\s*(\S+)?", msg, re.I)
    if m_rg:
        return await _fb_group_reject(db, m_rg.group(2) or "")
    m_gd = re.match(r"^(תגובות-גרופ|group-drafts|group drafts|תגובות גרופ|דראפטים)(?:\s+(\d+))?$", low)
    if m_gd:
        return await _fb_comment_drafts_list(db, int(m_gd.group(2) or 1))
    m_acd = re.match(r"^(approve[\-_ ]?comment|אשרתגובה|אשר תגובה)\b\s*(\S+)?", msg, re.I)
    if m_acd:
        return await _fb_comment_approve(db, m_acd.group(2) or "")
    m_scd = re.match(r"^(skip[\-_ ]?comment|דלגתגובה|דלג תגובה)\b\s*(\S+)?", msg, re.I)
    if m_scd:
        return await _fb_comment_skip(db, m_scd.group(2) or "")
    if low in ("סרוק קבוצות", "scan groups", "scan-groups", "סריקת קבוצות"):
        return await _fb_scan_groups_trigger()
    if low in ("מוכנות", "readiness", "noa-readiness", "מוכנות noa"):
        from social import noa_ops
        return noa_ops.format_readiness(await noa_ops.readiness_report(db))
    if low in ("מדדים", "noa-stats", "noa stats", "מדדי noa"):
        from social import noa_ops
        from datetime import datetime, timedelta
        return noa_ops.format_metrics(await noa_ops.daily_metrics(db, datetime.utcnow() - timedelta(hours=24)),
                                      await noa_ops.readiness_report(db))

    # ── conversational path (AVI / NOA in owner mode) ─────────────────────────
    # Call the LLM DIRECTLY (not via get_agent): the router_agent is a JSON classifier
    # and produces garbage on freeform chat. We just need a grounded conversational reply.
    _other_agents_mentioned: list[str] = []
    _connect = _detect_connect_intent(msg)
    if _connect:
        agent_key, _mentioned = _connect
        clean = msg
        explicit = True
        _other_agents_mentioned = _mentioned[1:]  # anyone besides the one we're switching to
    else:
        agent_key, clean, explicit = _pick_agent(msg)

    # STICKY SESSION: an explicit @agent switches AND pins the agent; an unprefixed
    # message continues with whoever you're already talking to (not a forced fall to AVI).
    switched = False
    active = await _get_active_agent()
    if explicit:
        switched = (active != agent_key)
        await _set_active_agent(agent_key)
    elif active:
        agent_key = active                 # keep talking to the current agent
        await _set_active_agent(agent_key)  # refresh idle TTL
    # else: no prefix and no active session → default (AVI), stay unpinned.

    is_noa = agent_key == "social_media_manager_agent"

    # If the owner gives NOA a DIRECTIVE (save/always/from-now/guideline …), persist it so
    # NOA's actual posting loop applies it — not just an ack in chat. (This is the fix for
    # "I told AVI guidelines for NOA — did NOA get them?": now she really does.)
    saved_note = ""
    is_directive = bool(_SAVE_INTENT.search(clean))
    if is_noa and is_directive:
        await _noa_guidelines_save(db, clean)
        saved_note = "\n\n📋 שמרתי את ההנחיה ואפעל לפיה מעכשיו. (לצפייה: כתוב *הנחיות*)"

    try:
        from hf_client import hf_text
        status_block = await build_status_snapshot(db)
        system = _OWNER_SYSTEM[agent_key] + "\n\n--- מצב המערכת החי (עכשיו) ---\n" + status_block
        # A directive is answered with an acknowledgement, by ANY agent — not just NOA.
        if is_directive:
            system += _DIRECTIVE_NOTE
        if is_noa:
            g = await _noa_guidelines_get(db)
            if g:
                system += ("\n\n--- הנחיות קבועות מהבעלים (חובה לפעול לפיהן) ---\n" + g)
        hist = await _load_history()
        def _fmt_turn(m):
            if m["role"] == "assistant":
                atag = _AGENT_TAG.get(m.get("agent", ""), m.get("agent", "AGENT"))
                return f"assistant [{atag}]: {m['content']}"
            return f"user: {m['content']}"
        convo = "\n".join(_fmt_turn(m) for m in hist[-8:])
        prompt = (convo + "\n" if convo else "") + f"user: {clean}"
        # Low temperature so the console agents (AVI / NOA / Bone) write clean, human,
        # idiomatic Hebrew — the same fix proven for NOA (owner request 2026-08-04: "make
        # AVI and Bone talk like NOA"). The console calls hf_text DIRECTLY (not .think()),
        # so it wasn't covered by the earlier think()-layer temperature fix and ran at the
        # Cerebras default ~1.0 → garbled Hebrew. Env-tunable.
        _console_temp = float(os.getenv("OWNER_CONSOLE_TEMPERATURE", "0.4"))
        reply = await hf_text(prompt, system=system, priority=True, max_tokens=600,
                              temperature=_console_temp, reasoning_effort="low")
        reply = _clean_wa_reply(reply) or "בסדר, קיבלתי."
        # Execution integrity gate: conversational path is read-only.
        # Reject any reply claiming to have performed a system action.
        reply = _guard_avi_conversational_reply(reply)
        reply += saved_note
        hist2 = hist + [{"role": "user", "content": clean},
                        {"role": "assistant", "content": reply, "agent": agent_key}]
        await _save_history(hist2)
        tag = _AGENT_TAG.get(agent_key, "AVI")
        # On an explicit switch, confirm who you're now talking to (and how to leave).
        if switched:
            note = ""
            if _other_agents_mentioned:
                _other_tags = ", ".join(
                    "@" + n for n in _other_agents_mentioned
                )
                note = f"\n(גם ל-{_other_tags} — פני אליהם בנפרד באותה שיטה)"
            # ‏ = RLM (RIGHT-TO-LEFT MARK): invisible, forces RTL paragraph direction
            # so the [TAG] prefix doesn't make WhatsApp render the reply LTR.
            return f"🔀 עכשיו בשיחה עם *{tag}* (ליציאה: *יציאה*){note}\n\n‏[{tag}] {reply}"
        return f"‏[{tag}] {reply}"
    except Exception as e:
        return f"⚠️ שגיאה בעיבוד ההודעה: {str(e)[:120]}"
